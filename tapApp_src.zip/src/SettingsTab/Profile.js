//Libraries
import React from 'react'
import { View, Text, StyleSheet, Image, Alert, TextInput, Platform, ImageBackground, Dimensions, TouchableOpacity } from 'react-native';
import { connect } from 'react-redux'
import ImagePicker from 'react-native-image-crop-picker';
import AsyncStorage from '@react-native-community/async-storage';
import { StackActions, NavigationActions } from 'react-navigation';
//Assets
import { Images, Matrics, Colors } from '@Assets'
import { HeaderBackButton, LoadWheel } from '../Components';
import { ListCell } from '../FriendTab/Templates/ListCell';
import { changeProfileRequest, changeUserNameRequest } from '@Redux/Actions/SettingsActions'
import { logOutRequest, getRefreshTokenRequest } from '@Redux/Actions/AuthActions'
import { MASTER_ACCESS_KEY } from '../Config/Constants';
import language from '../Assets/Languages/Language'


const { height, width } = Dimensions.get('window')

//device type to pass with the api requests
let deviceType = Platform.OS == 'ios' ? 1 : 0;
//------------>>>>MAIN CLASS------------->>>>>

class Profile extends React.Component {

    //---------->>>NAVIGATION OPTIONS FOR HEADER---------->
    static navigationOptions = ({ navigation }) => ({
        headerTitle:  language.other.ProfileHeaderText,
        headerTitleStyle: { flex: 1, textAlign: 'center' },
        headerLeft: <HeaderBackButton
            onBackPress={() => navigation.goBack()}
        />,
        headerRight: <View />
    })


    //---------->>>STATE DECLARATION---------->
    state = {
        profileImage: {},
        logoutFlag: true,
        isLoading: false,
        userName: this.props.updatedUserInfo ? this.props.updatedUserInfo.firstname : this.props.userInfo.firstname
    }


    //---------->>>LIFE CYCLE METHODS---------->
    async componentWillReceiveProps(nextProps) {
        //if user already exists when changing profile pic
        if (nextProps.settings.changeProfileSuccess && nextProps.settings.data.status == "3" && this.state.logoutFlag && this.state.isLoading) {
            await this.setState({ logoutFlag: false, isLoading: false })

            console.log('gya--------------', this.state.logoutFlag)
            this.LogoutAlert()
        }
        //change profile pic success
        else if (nextProps.settings.changeProfileSuccess && nextProps.settings.data.status == "1" && this.state.isLoading) {
            await this.setState({ isLoading: false, profileImage: nextProps.settings.data.data.User.image })
            console.log(this.state.profileImage, 'Image profile')
            alert(language.other.ProfileChangeSuccess)
        }
        else if (nextProps.logout.logoutFail) {
            alert(language.auth.SomethingWentWrong1)
        }
        //logout success
        else if (nextProps.logout.logoutSuccess && nextProps.logout.data.status == "1" && !this.state.logoutFlag) {
            console.log('logout func =============', this.state.logoutFlag)
            // await AsyncStorage.removeItem('persist: Auth')
            await AsyncStorage.getAllKeys().then(AsyncStorage.multiRemove)
            await AsyncStorage.removeItem('refreshtoken')
            this.getRefreshToken()
        }

        if (nextProps.auth.refreshTokenSuccess && nextProps.auth.data.status == "1") {

            const resetAction = StackActions.reset({
                index: 0,
                actions: [NavigationActions.navigate({ routeName: 'Auth' })],
            });
            await this.props.navigation.dispatch(resetAction);
        }
        //UserName change success 
        else if (nextProps.settings.changeUserNameSuccess && nextProps.settings.data.status == "1" && this.state.isLoading) {
            await this.setState({ isLoading: false })
            alert(language.other.UsernameChangeSuccess)
        }

        else if (nextProps.settings.changeUserNameSuccess && nextProps.settings.data.status == "3" && this.state.logoutFlag && this.state.isLoading) {
            await this.setState({ logoutFlag: false, isLoading: false })
            console.log('gya--------------', this.state.logoutFlag)
            this.LogoutAlert()
        }
        else if (nextProps.settings.changeUserNameFail) {
            alert(language.auth.SomethingWentWrong1)
        }
    }

    //---------->>>FUNCTIONS DECLARATION---------->

    getRefreshToken() {
        this.props.getRefreshTokenRequest({ access_key: MASTER_ACCESS_KEY })
    }

    //choose profile photo from gallery
    async choosePhoto() {

        ImagePicker.openPicker({
            compressImageQuality: 0.5,
            includeBase64: true
        }).then(async image => {
            console.log(image, 'consoleImage')
            let imgdata = { uri: image.path, type: image.mime, name: image.filename == null ? 'IMG1.jpg' : image.filename, data: image.data }
            await this.setState({ profileImage: imgdata, isLoading: true })


            //CHECK FOR IS_TEST DATA PARAM
            // TO DO - add dynamic device token

            await this.props.changeProfileRequest({
                secret_key: this.props.auth.data.userToken,
                access_key: this.props.encryptedToken,
                profile_image: this.state.profileImage.data,
                device_token: "12345678",
                device_type: deviceType,
                first_name: this.props.userInfo.firstname,
                email_id: this.props.userInfo.email_id,
                "is_testdata": "1",
                user_id: this.props.userInfo.id
            })
        });
    }

    //take a photo from camera
    async takePhoto() {
        ImagePicker.openCamera({
            cropping: true,
            compressImageQuality: 0.5,
            includeBase64: true

        }).then(async image => {
            let imgdata = { uri: image.path, type: image.mime, name: image.filename == null ? 'IMG.jpg' : image.filename }
            console.log(imgdata, 'imageData')


            await this.setState({ profileImage: imgdata, isLoading: true })


            //CHECK FOR IS_TEST DATA PARAM
            // TO DO - add dynamic device token

            await this.props.changeProfileRequest({
                secret_key: this.props.auth.data.userToken,
                access_key: this.props.encryptedToken,
                profile_image: this.state.profileImage.data,
                device_token: "12345678",
                device_type: deviceType,
                first_name: this.props.userInfo.firstname,
                email_id: this.props.userInfo.email_id,
                "is_testdata": "1",
                user_id: this.props.userInfo.id
            })
        });
    }

    async onLogoutPress() {

        // TO DO - add dynamic device token
        await this.props.logOutRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            user_id: this.props.userInfo.id,
            device_token: "123456",
            device_type: deviceType,
            "is_testdata": "1"
        })
    }

    LogoutAlert() {
        Alert.alert(
            'Alert',
            language.common.LogoutText,
            [
                {
                    text: language.common.Logout,
                    onPress: () => this.onLogoutPress(),
                },
            ],
        );
    }

    //alert for camera or gallery
    choosePhotoAlert() {

        Alert.alert(
            language.auth.ProfilePhotoText,
            language.auth.ChoosePhotoText,
            [
                {
                    text: language.auth.CameraText,
                    onPress: () => this.takePhoto(),
                },
                { text: language.auth.GalleryText, onPress: () => this.choosePhoto() },
            ],
        );
    }

    //change username function
    onChangePress() {
        this.setState({ isLoading: true })
        this.props.changeUserNameRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            // image: this.state.profileImage.data,
            device_token: "12345678",
            device_type: deviceType,
            first_name: this.state.userName,
            email_id: this.props.userInfo.email_id,
            "is_testdata": "1",
            user_id: this.props.userInfo.id
        })
        console.log('hi')
    }

    //------------>>>>RENDER METHOD------------->>>>>
    render() {
        const {
            ChangeProfilePictureText,
            ChangeText,
            ChangePasswordText
        } = language.other
        console.log(this.state.profileImage.uri, 'profileImageUri')
        return (
            <View style={styles.container}>
                <ImageBackground source={Images.profileBG} style={styles.imageBackgroundContainer}>
                    {/*  TO DO - check for image on login user data, will be modified after backend changes */}
                    <Image defaultSource={Images.ProfilePlaceHolder} source={this.props.updatedUserInfo ? { uri: this.props.updatedUserInfo.image } : (this.props.userInfo ? { uri: this.props.userInfo.image } : Images.ProfilePlaceHolder)} style={styles.profilePic} />

                    {/* <Image source={{ uri: this.props.settings.data.data.User.image }} style={styles.profilePic} /> */}

                    <TouchableOpacity onPress={() => this.choosePhotoAlert()}>
                        <View style={styles.changePicView}>
                            <Text style={styles.changePicText}>{ChangeProfilePictureText}</Text>
                        </View>
                    </TouchableOpacity>
                </ImageBackground>

                <View>
                    <View>
                        <View style={styles.ListContainer}>
                            <Image source={Images.profile_icon} style={styles.ListIcon} />
                            <View style={styles.subListView}>
                                <View style={styles.inputView}>
                                    <TextInput
                                        value={this.state.userName}
                                        onChangeText={(text) => this.setState({ userName: text })}
                                        style={styles.listName}
                                    />
                                    <TouchableOpacity onPress={() => this.onChangePress()}>
                                        <Text style={styles.changeText}>{ChangeText}</Text>
                                    </TouchableOpacity>
                                </View>
                                <View style={styles.listBorderView} />
                            </View>
                        </View>
                    </View>

                    <ListCell
                        Name={this.props.userInfo ? this.props.userInfo.search_id : undefined}
                        IconSource={Images.IdIcon}
                    // onPress={() => this.props.navigation.navigate('Profile')}
                    />
                    <ListCell
                        Name={language.friend.QRCode}
                        IconSource={Images.QR_icon}
                        onPress={() => this.props.navigation.navigate('QRCodeScreen')}
                    />
                    <ListCell
                        Name={ChangePasswordText}
                        IconSource={Images.editNameIcon}
                        titleStyle={{ marginLeft : Matrics.Scale(17) }}
                        imageStyle={{ height: Matrics.Scale(30), width: Matrics.Scale(50)}}
                        onPress={() => this.props.navigation.navigate('ChangePassword')}
                        borderStyle={{  marginLeft: Matrics.Scale(15) }}
                    />
                </View>
                <LoadWheel isVisible={this.state.isLoading} />
            </View>
        )
    }
}

//Props Connection
const mapStateToProps = (state) => {
    console.log(state, 'state on profile')
    return {
        auth: state.Auth,
        userInfo: state.Auth.data && state.Auth.data.data ? state.Auth.data.data.User : undefined,
        logout: state.Logout,
        encryptedToken: state.Encrypt.data ? state.Encrypt.data.encrypted_value : undefined,
        settings: state.Settings,
        updatedUserInfo: state.Settings.data && state.Settings.data.data ? state.Settings.data.data.User : undefined
    };
}
//Redux Connection  
export default connect(mapStateToProps, { changeProfileRequest, logOutRequest, getRefreshTokenRequest, changeUserNameRequest })(Profile);



//=========STYLES DECLARATION========//
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    profilePic: {
        marginVertical: Matrics.Scale(15),
        height: Matrics.Scale(100),
        width: Matrics.Scale(100),
        borderRadius: Matrics.Scale(50)
    },
    imageBackgroundContainer: {
        height: Platform.OS == 'ios' ? height / 4.8 : height / 4,
        width: width,
        // justifyContent : 'center',
        alignItems: 'center'
    },
    changePicView: {
        backgroundColor: Colors.WHITE,
        borderRadius: Matrics.Scale(20),
        paddingVertical: Matrics.Scale(5),
        paddingHorizontal: Matrics.Scale(18),
        marginHorizontal: Matrics.Scale(30),
    },
    changePicText: {
        fontSize: Matrics.Scale(13)
    },
    ChangeContainer: {
        borderWidth: 1,
        marginRight: Matrics.Scale(15),
        padding: Matrics.Scale(5)
    },
    ListContainer: {
        alignItems: 'center',
        flexDirection: 'row',
        marginVertical: Matrics.Scale(20)
    },
    ListIcon: {
        marginLeft: Matrics.Scale(25),
        height: Matrics.Scale(30),
        width: Matrics.Scale(30)
    },
    subListView: { flex: 1 },
    listName: {
        marginLeft: Matrics.Scale(35),
        flex: 1,
        // fontSize: Matrics.Scale(15),
        borderWidth: 1,
        paddingVertical: Matrics.Scale(5)
    },
    listBorderView: {
        borderColor: Colors.GREY,
        marginTop: Matrics.Scale(13),
        borderWidth: 1,
        marginLeft: Matrics.Scale(35)
    },
    inputView: { flexDirection: 'row' },
    changeText: {
        marginRight: Matrics.Scale(15),
        borderWidth: 1,
        marginLeft: Matrics.Scale(9),
        alignSelf: 'center',
        padding: Matrics.Scale(5),
        marginTop: Platform.OS == 'android' ? 5 : 0

    }

})