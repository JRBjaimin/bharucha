//Libraries
import React from 'react'
import { View, Text, Image, StyleSheet } from 'react-native';
import { RNCamera } from 'react-native-camera';
import BarcodeMask from 'react-native-barcode-mask';
import { connect } from 'react-redux'
import QRCode from 'react-native-qrcode-svg';
//Assets
import { Colors, Images, Matrics } from '@Assets'
import { HeaderBackButton } from '../Components';
import language from '../Assets/Languages/Language'



//MAIN CLASS
class QRCodeScreen extends React.Component {
    //NAVGATION OPTIONS FOR HEADER
    static navigationOptions = ({ navigation }) => ({
        swipeEnabled: false,
        headerTitle: language.friend.QRCode,
        headerTitleStyle: { flex: 1, textAlign: 'center' },
        headerLeft: <HeaderBackButton
            onBackPress={() => navigation.goBack()}
        />,
        headerRight: <View />
    })
    //RENDER METHOD
    render() {
        let arr = { id: this.props.userInfo.id, name: this.props.userInfo.firstname, image: this.props.userInfo.image }
        return (
            <View style={styles.container}>
                <View style={styles.Qrcontainer}>
                    <QRCode
                        value={JSON.stringify(arr)}
                        size={200}
                    />
                </View>
            </View>
        )
    }
}
//Props Connection
const mapStateToProps = (state) => {
    console.log(state, 'state on QRCODE')
    return {
        auth: state.Auth,
        userInfo: state.Auth.data && state.Auth.data.data ? state.Auth.data.data.User : undefined,
        logout: state.Logout,
        encryptedToken: state.Encrypt.data ? state.Encrypt.data.encrypted_value : undefined,
        settings: state.Settings,
        updatedUserInfo: state.Settings.data && state.Settings.data.data ? state.Settings.data.data.User : undefined
    };
}

//Redux Connection  
export default connect(mapStateToProps)(QRCodeScreen);



//STYELS DECLARATION
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    Qrcontainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    }
});
