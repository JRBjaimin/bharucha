import { createStackNavigator } from 'react-navigation'
import Settings from './Settings'
import Profile from './Profile'
import QRCodeScreen from './QRCodeScreen'
import ChangePassword from './ChangePassword'

const SettingsNavigator = createStackNavigator({

    Settings : { screen : Settings },
    Profile : { screen : Profile },
    QRCodeScreen : { screen: QRCodeScreen },
    ChangePassword :  { screen : ChangePassword }
})

export default SettingsNavigator;
