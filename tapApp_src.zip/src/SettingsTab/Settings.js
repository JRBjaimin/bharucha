//Libraries
import React from 'react'
import { connect } from 'react-redux';
import { View, Text, StyleSheet, TouchableOpacity, Alert, Dimensions, Platform } from 'react-native';
import { ListCell } from '../FriendTab/Templates/ListCell';
import AsyncStorage from '@react-native-community/async-storage';
import { logOutRequest, getRefreshTokenRequest } from '@Redux/Actions/AuthActions'
import { StackActions, NavigationActions } from 'react-navigation';
//Assets
import { Images, Matrics, Colors } from '@Assets'
import { LoadWheel, MainButton } from '../Components';
import { MASTER_ACCESS_KEY } from '../Config/Constants';
import language from '../Assets/Languages/Language'

const { height, width } = Dimensions.get('window')
let deviceType = Platform.OS == 'ios' ? 1 : 0;


//------------>>>>MAIN CLASS------------->>>>>

class Settings extends React.Component {

    //---------->>>NAVIGATION OPTIONS FOR HEADER---------->
    static navigationOptions = ({ navigation }) => ({
        headerTitle: language.other.Header,
        headerTitleStyle: { flex: 1, textAlign: 'center' },
    })
    constructor(props) {
        super(props);
        //---------->>>STATE DECLARATION---------->

        this.state = {
            isLoading: false
        }
    }
    //---------->>>LIFE CYCLE METHODS---------->

    async componentWillMount() {

    }

    async componentWillReceiveProps(nextProps) {
        if (nextProps.logout.logoutFail) {
            alert(language.auth.SomethingWentWrong1)
        }
        //logout success
        else if (nextProps.logout.logoutSuccess && nextProps.logout.data.status == "1" && this.state.isLoading) {
            console.log('logout func =============', this.state.logoutFlag)
            // await AsyncStorage.removeItem('persist: Auth')
            this.setState({ isLoading : false })
            await AsyncStorage.getAllKeys().then(AsyncStorage.multiRemove)
            await AsyncStorage.removeItem('refreshtoken')
            this.getRefreshToken()
        }

        if (nextProps.auth.refreshTokenSuccess && nextProps.auth.data.status == "1") {

            const resetAction = StackActions.reset({
                index: 0,
                actions: [NavigationActions.navigate({ routeName: 'Auth' })],
            });
            await this.props.navigation.dispatch(resetAction);
        }
    }

    //---------->>>FUNCTIONS DECLARATION---------->
    getRefreshToken() {
        this.props.getRefreshTokenRequest({ access_key: MASTER_ACCESS_KEY })
    }

    async onLogoutPress() {
        this.setState({ isLoading : true })
        // TO DO - add dynamic device token
        await this.props.logOutRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            user_id: this.props.userInfo.id,
            device_token: "123456",
            device_type: deviceType,
            "is_testdata": "1"
        })
    }



    async setLanguage(lan) {
        await this.setState({ lang: lan })
        console.log('setLanguage')
        // this.setState({ languageModal: false })
        AsyncStorage.setItem('lan', this.state.lang)
        //  language.setLanguage(this.state.lang);
        language.setLanguage(lan)
        this.forceUpdate()
    }

    languageSelectAlert() {

        Alert.alert(
            language.other.ChooseLanguageTitle,
            language.other.SelectLangaugeTitle,
            [
                { text: 'English', onPress: () => this.setLanguage('english') },
                { text: '日本人', onPress: () => this.setLanguage('japanese') },
                {
                    text: language.other.CancelText,
                    onPress: () => console.log('Cancel Pressed'),
                    style: 'cancel',
                },
            ],
            { cancelable: false },
        );
    }
    //------------>>>>RENDER METHOD------------->>>>>  

    render() {
        const { ProfileText, ChangeLanguage } = language.other
        return (
            <View style={styles.container}>
                <ListCell
                    Name={ProfileText}
                    IconSource={Images.profile_icon}
                    onPress={() => this.props.navigation.navigate('Profile')}
                    imageStyle={{ height: Matrics.Scale(35) }}
                />

                <ListCell
                    Name={ChangeLanguage}
                    IconSource={Images.profile_icon}
                    onPress={() => this.languageSelectAlert()}
                    imageStyle={{ height: Matrics.Scale(35) }}
                />

                <MainButton
                    onPress={() => this.onLogoutPress()}
                    Title={language.common.Logout}
                    contentContainer={{ width: width - 60, justifyContent: 'center', alignSelf: 'center' }}
                />


                <LoadWheel isVisible={this.state.isLoading} />

            </View>
        )
    }
}

// export default Settings
// Props Connection
const mapStateToProps = (state) => {
    console.log(state, 'state Schedule==================');

    return {
        auth: state.Auth,
        userInfo: state.Auth.data && state.Auth.data.data ? state.Auth.data.data.User : undefined,
        logout: state.Logout,
        encryptedToken: state.Encrypt.data ? state.Encrypt.data.encrypted_value : undefined,
        settings: state.Settings,
        updatedUserInfo: state.Settings.data && state.Settings.data.data ? state.Settings.data.data.User : undefined
    };
}
//Redux Connection  
export default connect(mapStateToProps, { logOutRequest, getRefreshTokenRequest })(Settings);



//=========STYLES DECLARATION========//
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    lableContainer: {
        flex: 1,
        justifyContent: "center",
        alignContent: "center",
        alignSelf: "center"
    },
    buttonContainer: {
        backgroundColor: Colors.LOGIN,
        height: Matrics.Scale(40),
        marginTop: Matrics.Scale(30),
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "center",
        width: "80%",
    },
})  