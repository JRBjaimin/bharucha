//Libraries
import React from 'react'
import { View, Text, Image, StyleSheet, Dimensions, TextInput, Platform, Alert } from 'react-native';
import { connect } from 'react-redux'
import AsyncStorage from '@react-native-community/async-storage';
import { StackActions, NavigationActions } from 'react-navigation';

//Assets
import { Colors, Images, Matrics } from '@Assets'
import { HeaderBackButton, MainButton, LoadWheel } from '../Components';
import { changePasswordRequest } from '@Redux/Actions/SettingsActions'
import { logOutRequest, getRefreshTokenRequest } from '@Redux/Actions/AuthActions'

import language from '../Assets/Languages/Language'
import { MASTER_ACCESS_KEY } from '../Config/Constants';

const { height, width } = Dimensions.get('window')

let deviceType = Platform.OS == 'ios' ? 1 : 0;

//-------------->>>MAIN CLASS---------------->>>
class ChangePassword extends React.Component {

    //-------------->>>NAVGATION OPTIONS FOR HEADER---------------->>>
    static navigationOptions = ({ navigation }) => ({
        swipeEnabled: false,
        headerTitle: language.other.ChangePasswordHeader,
        headerTitleStyle: { flex: 1, textAlign: 'center' },
        headerLeft: <HeaderBackButton
            onBackPress={() => navigation.goBack()}
        />,
        headerRight: <View />
    })

    //-------------->>>STATE DECLARATION---------------->>>
    state = {
        oldPassword: '',
        newPassword: '',
        confirmPassword: '',
        isLoading: false,
        logoutFlag: true
    }
    //-------------->>>LIFE CYCLE METHODS---------------->>>

    async componentWillReceiveProps(nextProps) {
        //if user already exists when changing profile pic
        if (nextProps.changePassword.changePasswordSuccess && nextProps.changePassword.data.status == "3" && this.state.logoutFlag && this.state.isLoading) {
            await this.setState({ logoutFlag: false, isLoading: false })
            console.log('gya--------------', this.state.logoutFlag)
            this.LogoutAlert()
        }
        //logout success
        else if (nextProps.logout.logoutSuccess && nextProps.logout.data.status == "1" && !this.state.logoutFlag) {
            console.log('logout func =============', this.state.logoutFlag)
            // await AsyncStorage.removeItem('persist: Auth')
            await AsyncStorage.getAllKeys().then(AsyncStorage.multiRemove)
            await AsyncStorage.removeItem('refreshtoken')
            this.getRefreshToken()
        }

        if (nextProps.auth.refreshTokenSuccess && nextProps.auth.data.status == "1") {

            const resetAction = StackActions.reset({
                index: 0,
                actions: [NavigationActions.navigate({ routeName: 'Auth' })],
            });
            await this.props.navigation.dispatch(resetAction);
        }


        //if password is same as old one
        else if (nextProps.changePassword.changePasswordSuccess && nextProps.changePassword.data.status == "0" && this.state.isLoading && nextProps.changePassword.data.message == "Same as old password") {
            this.setState({ isLoading: false })
            alert(language.other.NewPasswordSameText)
        }
        //if password changed successfully
        else if (nextProps.changePassword.changePasswordSuccess && nextProps.changePassword.data.status == "1" && this.state.isLoading) {
            this.setState({ isLoading: false })
            this.PasswordSuccessAlert()
        }

        //if old password is incorect
        else if (nextProps.changePassword.changePasswordSuccess && nextProps.changePassword.data.status == "0" && this.state.isLoading && nextProps.changePassword.data.message == "Incorrect password.") {
            this.setState({ isLoading: false })
            alert(language.other.IncorrectOldPassText)
        }
    }


    //-------------->>>NAVGATION OPTIONS FOR HEADER---------------->>>


    onChangePasswordPress() {

        if (this.state.oldPassword.trim() == "") {
            alert(language.other.OldPasswordValidate);
        }
        else if (this.state.newPassword.trim() == "") {
            alert(language.other.NewPasswordValidate);
        }
        else if (this.state.confirmPassword.trim() == "") {
            alert(language.other.ConfirmPasswordValidate);
        }
        else if (this.state.newPassword.trim() != this.state.confirmPassword.trim()) {
            alert(language.auth.PasswordBlankAlert);
        }

        else {
            //CHECK FOR IS_TEST DATA PARAM
            // TO DO - add dynamic device token
            this.setState({ isLoading: true })
            this.props.changePasswordRequest({
                secret_key: this.props.auth.data.userToken,
                access_key: this.props.encryptedToken,
                device_token: "123456",
                device_type: deviceType,
                user_id: this.props.userInfo.id,
                newpassword: this.state.newPassword,
                oldpassword: this.state.oldPassword,
                is_testdata: "1"
            })
        }
    }



    PasswordSuccessAlert() {
        Alert.alert(
            'Alert',
            language.other.PasswordChangeSuccess,
            [
                {
                    text: 'Ok',
                    onPress: () => this.props.navigation.goBack(),
                },
            ],
        );
    }

    getRefreshToken() {
        this.props.getRefreshTokenRequest({ access_key: MASTER_ACCESS_KEY })
    }

    async onLogoutPress() {

        // TO DO - add dynamic device token
        await this.props.logOutRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            user_id: this.props.userInfo.id,
            device_token: "123456",
            device_type: deviceType,
            "is_testdata": "1"
        })
    }

    LogoutAlert() {
        Alert.alert(
            'Alert',
            language.common.LogoutText,
            [
                {
                    text: language.common.Logout,
                    onPress: () => this.onLogoutPress(),
                },
            ],
        );
    }


    //RENDER METHOD
    render() {
        const { OldPasswordText, NewPasswordText, ConfirmPasswordText, ChangePasswordText } = language.other
        return (
            <View style={styles.container}>
                <View style={[styles.lableContainer, { alignItems: "center", justifyContent: 'center' }]}>
                    <View style={styles.inputContainer}>
                        <View style={{ flex: 1 }}>
                            <TextInput
                                clearButtonMode={'while-editing'}
                                style={styles.inputBoxContainer}
                                secureTextEntry={true}
                                value={this.state.oldPassword}
                                placeholderTextColor={"#ccc"}
                                onChangeText={text => this.setState({ oldPassword: text })}
                                placeholder={OldPasswordText}
                            />
                        </View>
                    </View>
                    <View style={styles.inputContainer}>
                        <View style={{ flex: 1 }}>
                            <TextInput
                                clearButtonMode={'while-editing'}
                                style={styles.inputBoxContainer}
                                secureTextEntry={true}
                                value={this.state.newPassword}
                                placeholderTextColor={"#ccc"}
                                onChangeText={text => this.setState({ newPassword: text })}
                                placeholder={NewPasswordText}
                            />
                        </View>
                    </View>
                    <View style={styles.inputContainer}>
                        <View style={{ flex: 1 }}>
                            <TextInput
                                clearButtonMode={'while-editing'}
                                style={styles.inputBoxContainer}
                                secureTextEntry={true}
                                value={this.state.confirmPassword}
                                placeholderTextColor={"#ccc"}
                                onChangeText={text => this.setState({ confirmPassword: text })}
                                placeholder={ConfirmPasswordText}
                            />
                        </View>
                    </View>
                    <MainButton
                        onPress={() => this.onChangePasswordPress()}
                        Title={ChangePasswordText}
                    />
                </View>
                <LoadWheel isVisible={this.state.isLoading} />

            </View>
        )
    }
}
//Props Connection
const mapStateToProps = (state) => {
    console.log(state, 'state on QRCODE')
    return {
        auth: state.Auth,
        userInfo: state.Auth.data && state.Auth.data.data ? state.Auth.data.data.User : undefined,
        logout: state.Logout,
        encryptedToken: state.Encrypt.data ? state.Encrypt.data.encrypted_value : undefined,
        settings: state.Settings,
        updatedUserInfo: state.Settings.data && state.Settings.data.data ? state.Settings.data.data.User : undefined,
        changePassword: state.changePassword
    };
}

//Redux Connection  
export default connect(mapStateToProps, { changePasswordRequest, logOutRequest, getRefreshTokenRequest })(ChangePassword);



//STYELS DECLARATION
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    inputContainer: {
        marginTop: Matrics.Scale(30),
        marginBottom: Matrics.Scale(5),
        height: Matrics.Scale(35),
        borderWidth: 1,
        flexDirection: "row",
        borderColor: "white",
        alignItems: "center",
        alignContent: "center",
        width: width - Matrics.Scale(20),
        borderRadius: Matrics.Scale(40)
    },
    inputBoxContainer: {
        height: Matrics.Scale(50),
        backgroundColor: Colors.LIGHTER_GREY,
        fontSize: Matrics.Scale(18),
        paddingLeft: Matrics.Scale(10)
    },
});
