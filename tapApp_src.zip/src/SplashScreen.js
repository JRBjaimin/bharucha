import React from 'react'
import { View, Text } from 'react-native';
import { connect } from 'react-redux'
import { getRefreshTokenRequest } from '@Redux/Actions/AuthActions'
import { MASTER_ACCESS_KEY } from './Config/Constants';
import { StackActions, NavigationActions } from 'react-navigation';


class SplashScreen extends React.Component {
    static navigationOptions = ({ navigation }) => ({
        swipeEnabled: false,
        header: null,
        gestureEnabled: false
    })


    async componentDidMount() {
        //  alert('hi')
        console.log(this.props,'props ss');


        if (Object.keys(this.props.auth).length != 0) {

            if ( this.props && this.props.auth && this.props.auth.refreshTokenFail) {
                const resetAction = StackActions.reset({
                    index: 0,
                    actions: [NavigationActions.navigate({ routeName: 'Auth' })],
                });
                await this.props.navigation.dispatch(resetAction);
            }
            // else
            //     if (this.props.auth.loginFail) {
            //         alert('something went wrong.Please try again later.')
            //         this.props.navigation.navigate('Auth')

            //     }
            //     else if (this.props.auth.data.data) {

            //         console.log('first if')
            //         if (this.props.auth.data.data.User.id && this.props.auth.data.userToken) {
            //             this.props.navigation.navigate('Main')
            //         }
            //         else {
            //             console.log('first else')
            //             this.props.navigation.navigate('Auth')
            //         }
            //     }
            //     else {
            //         console.log('first last else')
            //         this.props.navigation.navigate('Auth')
            //     }
            else if( this.props && this.props.auth && this.props.auth.loginFail) {
                alert('something went wrong.Please try again later.')
                const resetAction = StackActions.reset({
                    index: 0,
                    actions: [NavigationActions.navigate({ routeName: 'Auth' })],
                });
                await this.props.navigation.dispatch(resetAction);
            }
            else if (this.props && this.props.auth && this.props.auth.data && this.props.auth.data.data) {
                if(this.props && this.props.auth && !this.props.auth.forgotPasswordSuccess) {
                console.log('first if')
                if (this.props && this.props.auth && this.props.auth.data && this.props.auth.data.data.User && this.props.auth.data.data.User.id && this.props.auth.data.userToken) {
                    const resetAction = StackActions.reset({
                        index: 0,
                        actions: [NavigationActions.navigate({ routeName: 'Main' })],
                    });
                    await this.props.navigation.dispatch(resetAction);
                }
                else {
                    console.log('first else')
                    const resetAction = StackActions.reset({
                        index: 0,
                        actions: [NavigationActions.navigate({ routeName: 'Auth' })],
                    });
                    await this.props.navigation.dispatch(resetAction);
                }
            }
            else {
                console.log('first else')
                const resetAction = StackActions.reset({
                    index: 0,
                    actions: [NavigationActions.navigate({ routeName: 'Auth' })],
                });
                await this.props.navigation.dispatch(resetAction);
            }
            }
            else {  
                console.log('first last else')
                const resetAction = StackActions.reset({
                    index: 0,
                    actions: [NavigationActions.navigate({ routeName: 'Auth' })],
                });
                await this.props.navigation.dispatch(resetAction);
            }
        }
        else {
            console.log('here you go')
            const resetAction = StackActions.reset({
                index: 0,
                actions: [NavigationActions.navigate({ routeName: 'Auth' })],
            });
            await this.props.navigation.dispatch(resetAction);
        }
        // else if (this.props.logout.data.status == "1") {
        //     this.props.navigation.navigate('Auth')
        // }
        // console.log(this.props.auth.data.data.User.id, 'authDat')
    }
    render() {
        return (
            <View />    
        )
    }
}

//Props Connection
const mapStateToProps = (state) => {
    console.log(state, 'splashScreen')
    return {
        auth: state.Auth,
        logout: state.Logout
    };
}
//Redux Connection  
export default connect(mapStateToProps)(SplashScreen);

