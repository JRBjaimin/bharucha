import { createStackNavigator } from 'react-navigation'
import ChatList from './ChatList'
import ChatScreen from './ChatScreen'
import AllFriendsList from './AllFriendsList';


const talkNavigator = createStackNavigator({

    ChatList: { screen: ChatList },
    ChatScreen: { screen: ChatScreen },
    AllFriendsList: { screen: AllFriendsList }
})

export default talkNavigator;