//Libraries
import React from 'react'
import { SafeAreaView, View, Text, Image, TouchableOpacity, StyleSheet, FlatList, Platform, Alert } from 'react-native';
import { NavigationActions,StackActions } from 'react-navigation'
import SocketIOClient from 'socket.io-client'
import { connect } from 'react-redux'
import { getFriendListRequest } from '@Redux/Actions/FriendActions'
import AsyncStorage from '@react-native-community/async-storage';

//Assets
import { Images, Matrics, Colors } from '@Assets'
import language from '../Assets/Languages/Language'
import { LoadWheel, HeaderBackButton } from '../Components'
import { PORT_CONFIG } from '../Config/Constants';
import { logOutRequest, getRefreshTokenRequest } from '@Redux/Actions/AuthActions'
import { MASTER_ACCESS_KEY } from '../Config/Constants';


let deviceType = Platform.OS == 'ios' ? 1 : 0;


//MAIN CLASS DECLARATION
class AllFriendsList extends React.Component {

    //NAVIGATION OPTIONS FOR HEADER
    static navigationOptions = ({ navigation }) => ({
        swipeEnabled: false,
        headerTitle: language.talk.header,
        headerTitleStyle: { flex: 1, textAlign: 'center' },
        headerLeft: <HeaderBackButton
        onBackPress={() => navigation.navigate('ChatList', { tabBarVisible: true })}
    />,
        headerRight: <View />
    })

    constructor(props) {
        super(props)

        //------------------->>>>>STATE DECLARATION------------>>>
        this.state = {
            friendListData: [],
            isLoading: false,
            logoutFlag : true
        }

        this.socket = SocketIOClient(PORT_CONFIG);
    
        this.socket.emit('join_socket', { user_id: this.props.userInfo.id });
        global.socket = this.socket
        console.log(this.socket, "Socket Connected")
    }

    //LIFE CYCLE METHODS
    componentDidMount = async () => {

        let lang = await AsyncStorage.getItem('lan')

        if (lang != null) {
            this.setState({ lang: lang })
        }
         this.setState({ isLoading: true })
        //TO DO - change device token to dynamic one
        this.props.getFriendListRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            device_type: deviceType,
            device_token: "12345678",
            self_user_id: this.props.userInfo.id,
            is_testdata: "1"
        })
    }

    async componentWillReceiveProps(nextProps) {
        // TO DO - Add auto logout functionality

        //Show tabbar when user comes back to List Screen
        if (nextProps.navigation.state.params) {
            const setParamsAction = NavigationActions.setParams({
                params: { tabBarVisible: nextProps.navigation.state.params.tabBarVisible },
                key: 'Talk',
            });
            this.props.navigation.dispatch(setParamsAction)
        }
        //if friend list fetched successfully
        else if (nextProps.myFriendList.getFriendListSuccess && nextProps.myFriendList.data.status == "1" && this.state.isLoading) {
            this.setState({ isLoading: false })
            let len = nextProps.myFriendList.data.data.user_listing.length;
            console.log(nextProps.myFriendList.data.data.user_listing.length, nextProps.myFriendList.data.data.user_listing, '++++++++++++++++++++++++++++++++++++++')
            if (len > 0) {
                await this.setState({
                    friendListData: nextProps.myFriendList.data.data.user_listing,
                    friendListDataBackup: nextProps.myFriendList.data.data.user_listing
                });
            }

            else {
                this.setState({
                    noFriendsFlag: true
                })
            }
        }

        else if (nextProps.myFriendList.getFriendListFail && this.state.isLoading) {
            this.setState({ isLoading: false })
        }

        //if user already exists when changing profile pic
        if (nextProps.myFriendList.getFriendListSuccess && nextProps.myFriendList.data.status == "3" && this.state.logoutFlag && this.state.isLoading) {
            await this.setState({ logoutFlag: false, isLoading: false })

            console.log('gya--------------', this.state.logoutFlag)
            this.LogoutAlert()
        }

         //logout success
         else if (nextProps.logout.logoutSuccess && nextProps.logout.data.status == "1" && !this.state.logoutFlag) {
            console.log('logout func =============', this.state.logoutFlag)
            // await AsyncStorage.removeItem('persist: Auth')
            await AsyncStorage.getAllKeys().then(AsyncStorage.multiRemove)
            await AsyncStorage.removeItem('refreshtoken')
            this.getRefreshToken()
        }

        if (nextProps.auth.refreshTokenSuccess && nextProps.auth.data.status == "1") {

            const resetAction = StackActions.reset({
                index: 0,
                actions: [NavigationActions.navigate({ routeName: 'Auth' })],
            });
            await this.props.navigation.dispatch(resetAction);
        }

    }
    //------------->>>Controllers/Functions------------>>>>

    getRefreshToken() {
        this.props.getRefreshTokenRequest({ access_key: MASTER_ACCESS_KEY })
    }


    async onLogoutPress() {

        // TO DO - add dynamic device token
        await this.props.logOutRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            user_id: this.props.userInfo.id,
            device_token: "123456",
            device_type: deviceType,
            "is_testdata": "1"
        })
    }

    LogoutAlert() {
        Alert.alert(
            'Alert',
            language.common.LogoutText,
            [
                {
                    text: language.common.Logout,
                    onPress: () => this.onLogoutPress(),
                },
            ],
        );
    }

    renderUsersList = ({ item, index }) => {
        console.log(item, '1234567890===========')
        console.log(index, 'itemIndex')
        // console.log(item.thumbnail_url)
        return (
            <TouchableOpacity onPress={() => this.onUserPress(item)} >
                <View style={styles.usersItemView}>
                    <Image defaultSource={Images.ProfilePlaceHolder} source={item.image != "" ? { uri: item.image } : Images.ProfilePlaceHolder} style={styles.usersImage} />
                    <View style={styles.contentView}>
                        <Text style={styles.userNameText}>{item.alias_name ? item.alias_name : item.firstname}</Text>
                        <Text style={styles.messageText}>{language.talk.chatListMessage}</Text>
                    </View>
                </View>
            </TouchableOpacity>
        )
    }

    //TO DO - change item index to dynamic user id
    async onUserPress(item) {
        // await this.socket.emit("join_socket", dataObj);

        //Hide tabbar when user comes back to List Screen
        const setParamsAction = NavigationActions.setParams({
            params: { tabBarVisible: false },
            key: 'Talk',
        });
        this.props.navigation.dispatch(setParamsAction)

        this.props.navigation.navigate('ChatScreen', { friendInfo: item })
    }


    //----------SOCKET FUNCTIONS END---------------//


    render() {
        const { header } = language.talk
        return (
            <View style={styles.container}>


                <FlatList
                    data={this.state.friendListData}
                    extraData={this.state}
                    renderItem={this.renderUsersList}
                    // contentContainerStyle = { styles.FlatListStyle }
                    ItemSeparatorComponent={() => <View style={styles.ItemSeparatorComponent} />}
                />

                <LoadWheel isVisible={this.state.isLoading} />

            </View>

        )
    }
}


//Props Connection
const mapStateToProps = (state) => {
    console.log(state, 'dataallishere=============')
    return {
        auth: state.Auth,
        userInfo: state.Auth.data && state.Auth.data.data ? state.Auth.data.data.User : undefined,
        logout: state.Logout,
        encryptedToken: state.Encrypt.data ? state.Encrypt.data.encrypted_value : undefined,
        myFriendList: state.myFriendList,
        settings: state.Settings,
        updatedUserInfo: state.Settings.data && state.Settings.data.data ? state.Settings.data.data.User : undefined,
        friend: state.Friend,
        friendRequest: state.FriendRequest,
    };
}
//Redux Connection  
export default connect(mapStateToProps, { getFriendListRequest, logOutRequest, getRefreshTokenRequest  })(AllFriendsList);


//======STYLES DECLARATION======//
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.WHITE
    },
    usersImage: {
        height: Matrics.Scale(50),
        width: Matrics.Scale(50),
        borderWidth: Matrics.Scale(1),
        borderRadius: Matrics.Scale(25),
    },
    usersItemView: {
        marginHorizontal: Matrics.Scale(10),
        marginVertical: Matrics.Scale(5),
        // justifyContent:'center',
        flexDirection: 'row'
    },
    ItemSeparatorComponent: {
        borderBottomWidth: Matrics.Scale(1),
        marginTop: Matrics.Scale(1),
        borderColor: Colors.GREY
    },
    contentView: {
        marginHorizontal: Matrics.Scale(10),
        marginVertical: Matrics.Scale(5),
    },
    userNameText: {
        marginBottom: Matrics.Scale(5),
    },
    messageText: {
        color: Colors.GREY
    },
    headerRightView: {
        borderWidth: 1,
        marginRight: Matrics.Scale(15),
        borderRadius: Matrics.Scale(2),
        borderColor: Colors.GREY
    },
    headerRightText: {
        color: Colors.TEXT,
        paddingHorizontal: Matrics.Scale(10),
        paddingVertical: Matrics.Scale(5)
    }
})