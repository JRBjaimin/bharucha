//Libraries
import React from 'react'
import { View, Text, Image, Keyboard, TouchableOpacity, StyleSheet, Platform, FlatList, TextInput, Dimensions } from 'react-native';
import SocketIOClient from 'socket.io-client'
import AsyncStorage from '@react-native-community/async-storage';
import Icon from 'react-native-vector-icons/Feather'
import LinearGradient from 'react-native-linear-gradient';
import ImagePicker from 'react-native-image-crop-picker';
import moment from 'moment'
import { connect } from 'react-redux'

//Assets
import { Images, Matrics, Colors } from '@Assets'
import language from '../Assets/Languages/Language'
import { HeaderBackButton, HeaderEditButton } from '../Components';
import { addMediaRequest } from '@Redux/Actions/TalkActions'


const { height, width } = Dimensions.get('window')

//MAIN CLASS DECLARATION
class ChatScreen extends React.Component {

    //NAVGATION OPTIONS FOR HEADER
    static navigationOptions = ({ navigation }) => ({
        swipeEnabled: false,
        headerTitle: <View style={styles.headerTitleView}>
            <Image defaultSource={Images.ProfilePlaceHolder} source={navigation.state.params.friendInfo && navigation.state.params.friendInfo.image ? { uri: navigation.state.params.friendInfo.image } : Images.ProfilePlaceHolder} style={styles.headerTitleImage} />
            <Text style={styles.headerTitleText}>{navigation.state.params.friendInfo && navigation.state.params.friendInfo.alias_name ? navigation.state.params.friendInfo.alias_name : navigation.state.params.friendInfo.firstname}</Text>
        </View>,
        headerLeft: <HeaderBackButton
            onBackPress={() => navigation.navigate('ChatList', { tabBarVisible: true })}
        />,
        headerRight: <HeaderEditButton
        // onEditPress
        />
    })




    constructor(props) {
        super(props)

        //STATE DECLARATION
        this.state = {
            text: '',
            messageList: [],
            messageText: '',
            padding: 0,
            ImagetoSend: {},
            friendInfo: props.navigation.state.params && props.navigation.state.params.friendInfo
        }

        // this.socket = SocketIOClient('http://localhost:4885');
        // console.log(this.socket, "Socket Connected")
        this.socket = global.socket
        console.log(global.socket, 'socket---------------------------')
        this.socket.on("get_new_message", (data) => {
            console.log(data, 'messageDATAAAAAAA')
            let arr = this.state.messageList.reverse()
            arr.push(data.message[0])
            // data.message.map(res => {
            //  console.log(res, 'response')
            // })
            this.setState({ messageList: arr.reverse() })
            console.log(this.state.messageList, "Message Received")
            // this.setState({ chatListData: data.conversations })
        })
        console.log(this.props.navigation.state.params.friendInfo, "><><")
        const dataObj = {
            conversation_id: this.props.navigation.state.params.friendInfo.id
        }
        this.socket.emit("fetch_participants_conversation", dataObj, (data) => {
            console.log(data, "Socket Data+++++++++++++++++")
            // this.setState({ chatListData: data.conversations })
        })

        const dataObj1 = {
            user_id: this.props.userInfo.id,
            message_id: 0
        }
        this.socket.emit("fetch_message", dataObj1, (data) => {
            console.log(data, "Message Data---------------")
            let arr = data.message
            this.setState({ messageList: arr != undefined ? arr.reverse() : [] })
            console.log(this.state.messageList, "message here nigga*************")
            // this.setState({ chatListData: data.conversations })
        })
    }

    //------------->>>LIFE CYCLE METHODS----------->>
    componentDidMount() {
        this.keyboardDidShowListener = Keyboard.addListener("keyboardDidShow", this._keyboardDidShow);
        this.keyboardDidShowListener = Keyboard.addListener("keyboardDidChangeFrame", this._keyboardDidShow);
        this.keyboardDidHideListener = Keyboard.addListener("keyboardDidHide", this._keyboardDidHide);
        console.log(this.props.navigation.state.params.friendInfo, '********************************')
    }

    getDerivedStateFromProps(nextProps) {
        //Show tabbar when user comes back to List Screen

    }


    componentWillUnmount() {

        //  this.socket.emit("disconnect")
        Keyboard.removeListener("keyboardDidShow", this._keyboardDidShow);
    }


    //---------------------->>>Controllers/Functions-------------------->>>>

    _keyboardDidShow = e => {
        console.log(e, 'mil rhi h event')
        var keyboardHeight = e.endCoordinates.height;
        this.setState({ padding: keyboardHeight });
    };
    _keyboardDidHide = e => {
        this.setState({ padding: 0 });
    };


    //choose profile photo from gallery
    async choosePhoto() {
        ImagePicker.openPicker({
            compressImageQuality: 0.5,
            includeBase64: true
        }).then(async image => {
            console.log(image, 'consoleImage')
            let imgdata = { uri: image.path, type: image.mime, name: image.filename == null ? 'IMG1.jpg' : image.filename, data: image.data }
            await this.setState({ ImagetoSend: imgdata })
            console.log(this.state.ImagetoSend, '*---------------++')
        });

        this.onSend('1', this.state.ImagetoSend.data)
        let media = [];
        await media.push(this.state.ImagetoSend)
        console.log(media, 'yha to media h bhaiya')
        this.props.addMediaRequest({
            mediaGroupMessage : media
        })
        // this.setState({ messageList: arr.reverse(), messageText: '' })
    }

    //take a photo from camera
    async takePhoto() {
        ImagePicker.openCamera({
            cropping: true,
            compressImageQuality: 0.5,
            includeBase64: true

        }).then(async image => {
            let imgdata = { uri: image.path, type: image.mime, name: image.filename == null ? 'IMG.jpg' : image.filename }
            console.log(imgdata, 'imageData')
            await this.setState({ ImagetoSend: imgdata })


            //CHECK FOR IS_TEST DATA PARAM
            // TO DO - add dynamic device token
        });
    }

    //----------SOCKET FUNCTIONS START---------------//

    joinSocket(id) {
        const dataObj = {
            user_id: id
            // is_online : id
        };
        this.socket.emit("join_socket", dataObj);
    }

    onSend(messageType, messageBody) {
        // console.log(id, 'THIS IS ID')
        const dataObj = {
            conversation_id: 0,
            sender_id: this.props.userInfo.id,
            message: messageBody,
            message_type: messageType,
            unique_message_id: 800,
            parent_message_id: 60,
            receiver_id: this.state.friendInfo.id,
            forwarded_message_id: 10,
            is_edited: '0',
            created_date: new Date(),
            is_online: 1,
            modified_date: new Date()
        };
        // console.log(dataObj, 'DataObj')
        // this.socket.emit("send_new_message", dataObj);
        this.socket.emit("send_new_message", dataObj, (data) => {
            console.log(data, "onsendresponse")
            let arr = this.state.messageList.reverse()
            arr.push(dataObj)
            this.setState({ messageList: arr.reverse(), messageText: '' })

        });
    }

    //-----------------------------Group message send start------------------//
    // sendNewGroupMessage() {

    //     var dataObj = {
    //         conversation_id: 1,
    //         is_group_chat: 1,
    //         sender_id: 1,
    //         message: 'New group message',
    //         message_type: '0',
    //         unique_message_id: 70,
    //         parent_message_id: 80,
    //         // receiver_id: id == 1 ? 2 : 1,
    //         forwarded_message_id: 11,
    //         is_edited: '0',
    //         created_date: new Date(),
    //         //  is_online: 1,
    //         modified_date: new Date()
    //     };

    //     this.socket.emit("send_new_group_message", dataObj);
    // }

    //-----------------------------Group message send end------------------//


    //----------SOCKET FUNCTIONS END---------------//

    //--------------------------render messages on screen---------------//
    renderMessages = ({ item }) => {
        const date = moment().format('HH:mm')
        console.log(item, "item11111111111111")
        return (
            <View style={styles.pd12}>
                {
                    this.props.userInfo.id != item.sender_id ?
                        <View style={styles.rowDir}>
                            <View style={styles.userImageView}>
                                <Image style={styles.userImage} source={Images.fakeDp} />
                            </View>
                            <LinearGradient colors={['#bdc3c7', '#bdc3c7']} style={styles.gradientView}>
                                <View style={{ width: '85%' }}>
                                    <Text style={styles.messageText}>{item ? item.message : ''}</Text>
                                    <Text style={styles.timeText}>{date}</Text>
                                </View>
                            </LinearGradient>
                        </View>
                        :
                        <View>
                            <LinearGradient colors={['#fde7c2', '#fde7c2']} style={styles.senderView}>
                                <View style={{ width: '95%' }}>
                                    <Text style={styles.messageText}>{item ? item.message : ''}</Text>
                                    <Text style={styles.senderTimeText}>{date}</Text>
                                </View>
                            </LinearGradient>
                        </View>
                }
            </View>
        )
    }


    //--------------------------render messages end---------------//

    //RENDER METHOD
    render() {
        const { userId } = this.props.navigation.state.params


        return (

            <View style={{ flex: 1, marginBottom: Platform.OS === "ios" ? Matrics.Scale(this.state.padding) : 0 }}>
                <View style={{ flex: 1 }}>
                    <FlatList
                        ref={this.setRef}
                        data={this.state.messageList ? this.state.messageList : []}
                        extraData={this.state}
                        keyExtractor={this._keyExtractor}
                        inverted={true}
                        renderItem={this.renderMessages}
                    />
                </View>


                {/* <TouchableOpacity onPress={() => this.joinSocket(1)}><Text>1 Join</Text></TouchableOpacity>
                <TouchableOpacity onPress={() => this.joinSocket(2)}><Text>2 Join</Text></TouchableOpacity>

                <TouchableOpacity onPress={() => this.sendNewGroupMessage()}><Text>Send group message</Text></TouchableOpacity> */}
                <View style={styles.UxView}>

                    {/* <View style = {{ alignItems : 'space-between', flexDirection : 'row' }}> */}
                    <TouchableOpacity>
                        <View style={{ justifyContent: 'center' }}>
                            {/* <Image source={ Images.gallery} style = {{ height: Matrics.Scale(20), width: Matrics.Scale(40) }}/> */}
                            <Icon name={'camera'} size={25} />
                            <Text style={{ fontSize: 10 }}>photo</Text>
                        </View>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={() => this.choosePhoto()}>
                        <View style={{ justifyContent: 'center', marginHorizontal: Matrics.Scale(15) }}>
                            {/* <Image source={ Images.gallery} style = {{ height: Matrics.Scale(20), width: Matrics.Scale(40) }}/> */}
                            <Icon name={'image'} size={25} />
                            <Text style={{ fontSize: 10 }}>image</Text>
                        </View>
                    </TouchableOpacity>

                    <TouchableOpacity>
                        <View style={{ justifyContent: 'center', marginRight: Matrics.Scale(10) }}>
                            {/* <Image source={ Images.gallery} style = {{ height: Matrics.Scale(20), width: Matrics.Scale(40) }}/> */}
                            <Icon name={'map-pin'} size={25} />
                            <Text style={{ fontSize: 10 }}>location</Text>
                        </View>
                    </TouchableOpacity>
                    {/* </View> */}
                    <View style={styles.TextInputView}>
                        <TextInput
                            onChangeText={(text) => this.setState({ messageText: text })}
                            value={this.state.messageText}
                            style={{ flex: 1, height: Matrics.Scale(40) }}
                            multiline={true}
                            placeholder={'Aa'}
                        />
                        <TouchableOpacity onPress={() => this.onSend('0', this.state.messageText)}>
                            <View style={styles.sendButton}>
                                <Text style={{ color: Colors.WHITE }}>送</Text>
                                {/* TO DO - Add Text/symbol in send button*/}
                            </View>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        )
    }
}

//Props Connection
const mapStateToProps = (state) => {
    console.log(state, 'dataallishere=============')
    return {
        auth: state.Auth,
        userInfo: state.Auth.data && state.Auth.data.data ? state.Auth.data.data.User : undefined,
        logout: state.Logout,
        encryptedToken: state.Encrypt.data ? state.Encrypt.data.encrypted_value : undefined,
        myFriendList: state.myFriendList,
        Talk : state.TalkReducer
        // settings: state.Settings,
        // updatedUserInfo: state.Settings.data && state.Settings.data.data ? state.Settings.data.data.User : undefined,
        // friend: state.Friend,
        // friendRequest: state.FriendRequest,
    };
}
//Redux Connection  
export default connect(mapStateToProps, { addMediaRequest })(ChatScreen);

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    TextInputView: {
        borderWidth: 1,
        borderRadius: Matrics.Scale(20),
        // backgroundColor : Colors.LIGHT_GREY,
        padding: Matrics.Scale(5),
        borderColor: Colors.GREY,
        width: width / 1.7,
        alignSelf: 'flex-end',
        height: Platform.OS == 'android' ? Matrics.Scale(40) : undefined,
        flexDirection: 'row',
        marginRight: Matrics.Scale(5)
    },
    headerTitleView: {
        flexDirection: 'row',
        alignSelf: 'center',
        // flex:1,
        flex: 1, textAlign: 'center',
        justifyContent: 'center'
    },
    headerTitleImage: {
        borderRadius: Matrics.Scale(12.5),
        height: Matrics.Scale(25),
        width: Matrics.Scale(25)
    },
    headerTitleText: {
        marginTop: Matrics.Scale(5),
        marginLeft: Matrics.Scale(10)
    },
    UxView: {
        //flex: 1,
        flexDirection: 'row',
        paddingTop: Matrics.Scale(7),
        borderTopWidth: 1,
        borderTopColor: Colors.GREY,
        marginBottom: Matrics.Scale(30),
        justifyContent: 'flex-end',
    },
    sendButton: {
        backgroundColor: Colors.TEXT,
        height: Matrics.Scale(25),
        width: Matrics.Scale(25),
        borderRadius: Matrics.Scale(12.5),
        alignSelf: 'flex-end',
        alignItems: 'center',
    },
    pd12: {
        padding: Matrics.Scale(12)
    },
    rowDir: {
        flexDirection: 'row'
    },
    userImageView: {
        flex: 0.1,
        justifyContent: 'flex-end',
        alignItems: 'center'
    },
    userImage: {
        height: Matrics.Scale(30),
        width: Matrics.Scale(30),
        borderRadius: Matrics.Scale(25)
    },
    gradientView: {
        flex: 0.9,
        borderTopLeftRadius: Matrics.Scale(15),
        borderTopRightRadius: Matrics.Scale(15),
        borderBottomRightRadius: Matrics.Scale(15),
        marginLeft: Matrics.Scale(15)
    },
    messageText: {
        paddingLeft: Matrics.Scale(15),
        paddingTop: Matrics.Scale(10),
        color: Colors.BLACK
    },
    timeText: {
        paddingLeft: Matrics.Scale(15),
        paddingVertical: Matrics.Scale(10),
        fontSize: Matrics.Scale(11),
        color: Colors.SIMPLEGRAY
    },
    senderView: {
        marginTop: Matrics.Scale(15),
        width: '70%',
        borderTopLeftRadius: Matrics.Scale(15),
        borderBottomLeftRadius: Matrics.Scale(15),
        alignSelf: 'flex-end',
        borderTopRightRadius: Matrics.Scale(15)
    },
    senderTimeText: {
        paddingLeft: Matrics.Scale(15),
        paddingVertical: Matrics.Scale(10),
        fontSize: Matrics.Scale(11),
        color: Colors.BLACK,
        textAlign: 'right'
    },

})

