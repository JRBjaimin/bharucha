//Libraries
import React from 'react'
import { SafeAreaView, View, Text, Image, TouchableOpacity, StyleSheet, FlatList, Platform } from 'react-native';
import { NavigationActions } from 'react-navigation'
import SocketIOClient from 'socket.io-client'
import AsyncStorage from '@react-native-community/async-storage';
import { connect } from 'react-redux'
import { getFriendListRequest } from '@Redux/Actions/FriendActions'

//Assets
import { Images, Matrics, Colors } from '@Assets'
import language from '../Assets/Languages/Language'
import { LoadWheel } from '../Components'
import { PORT_CONFIG } from '../Config/Constants';

let self;
let deviceType = Platform.OS == 'ios' ? 1 : 0;


//MAIN CLASS DECLARATION
class ChatList extends React.Component {

    //NAVIGATION OPTIONS FOR HEADER
    static navigationOptions = ({ navigation }) => ({
        swipeEnabled: false,
        headerTitle: language.talk.header,
        headerTitleStyle: { flex: 1, textAlign: 'center' },
        headerRight: <TouchableOpacity onPress={() => self.onNewPress()}>
            <View style={styles.headerRightView}>
                <Text style={styles.headerRightText}>{language.new}</Text>
            </View>
        </TouchableOpacity>,
    })

    constructor(props) {
        super(props)

        //------------------->>>>>STATE DECLARATION------------>>>
        this.state = {
            lang: 'japenese',
            UserList: [],
            Receivedmessages: [],
            chatListData: [],
            isLoading: false,
        }

        this.socket = SocketIOClient(PORT_CONFIG);
        // this.socket = SocketIOClient('http://clientapp.narola.online:9522')
        this.socket.emit('join_socket', { user_id: this.props.userInfo.id });
        global.socket = this.socket
        console.log(this.socket, "Socket Connected")
        const dataObj = {
            user_id: this.props.userInfo.id
        }
        
        this.socket.emit("fetch_initial_conversation", dataObj, (data) => {
            console.log(data, "Socket Data")
            this.setState({ chatListData: data.conversations })
        })
    }



    //LIFE CYCLE METHODS
    componentDidMount = async () => {
        self = this
        let lang = await AsyncStorage.getItem('lan')

        if (lang != null) {
            this.setState({ lang: lang })
        }
    }

    async componentWillReceiveProps(nextProps) {
        //Show tabbar when user comes back to List Screen
        if (nextProps.navigation.state.params) {
            const setParamsAction = NavigationActions.setParams({
                params: { tabBarVisible: nextProps.navigation.state.params.tabBarVisible },
                key: 'Talk',
            });
            this.props.navigation.dispatch(setParamsAction)
        }
    }
    //------------->>>Controllers/Functions------------>>>>

    onNewPress() {
        this.props.navigation.navigate('AllFriendsList')
    }


    renderUsersList = ({ item, index }) => {
        let userId = this.props && this.props.userInfo && this.props.userInfo.id
        console.log(item.created_by, item.receiver_first_name,item.creater_first_name, '1234567890===========')
        console.log(index, 'itemIndex')
        // console.log(item.thumbnail_url)
        return (
            <TouchableOpacity onPress={() => this.onUserPress(item)} >
                <View style={styles.usersItemView}>
                    <Image defaultSource={Images.ProfilePlaceHolder} source={item.image != "" ? { uri: item.image } : Images.ProfilePlaceHolder} style={styles.usersImage} />
                    <View style={styles.contentView}>
                        <Text style={styles.userNameText}>{ item.created_by == userId ? item.receiver_first_name : item.creater_first_name}</Text>
                        <Text style={styles.messageText}>{language.talk.chatListMessage}</Text>
                    </View>
                </View>
            </TouchableOpacity>
        )
    }

    //TO DO - change item index to dynamic user id
    async onUserPress(item) {
        // await this.socket.emit("join_socket", dataObj);
        //Hide tabbar when user comes back to List Screen
        const setParamsAction = NavigationActions.setParams({
            params: { tabBarVisible: false },
            key: 'Talk',
        });
        this.props.navigation.dispatch(setParamsAction)

        this.props.navigation.navigate('ChatScreen', { friendInfo: item })
    }


    //----------SOCKET FUNCTIONS END---------------//

    render() {
        const { header } = language.talk
        return (
            <View style={styles.container}>
                <FlatList
                    data={this.state.chatListData}
                    extraData={this.state}
                    renderItem={this.renderUsersList}
                    // contentContainerStyle = { styles.FlatListStyle }
                    ItemSeparatorComponent={() => <View style={styles.ItemSeparatorComponent} />}
                />
                <LoadWheel isVisible={this.state.isLoading} />
            </View>
        )
    }
}


//Props Connection
const mapStateToProps = (state) => {
    console.log(state, 'dataallishere=============')
    return {
        auth: state.Auth,
        userInfo: state.Auth.data && state.Auth.data.data ? state.Auth.data.data.User : undefined,
        logout: state.Logout,
        encryptedToken: state.Encrypt.data ? state.Encrypt.data.encrypted_value : undefined,
        myFriendList: state.myFriendList
        // settings: state.Settings,
        // updatedUserInfo: state.Settings.data && state.Settings.data.data ? state.Settings.data.data.User : undefined,
        // friend: state.Friend,
        // friendRequest: state.FriendRequest,
    };
}
//Redux Connection  
export default connect(mapStateToProps, { getFriendListRequest })(ChatList);


//======STYLES DECLARATION======//
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: Colors.WHITE
    },
    usersImage: {
        height: Matrics.Scale(50),
        width: Matrics.Scale(50),
        borderWidth: Matrics.Scale(1),
        borderRadius: Matrics.Scale(25),
    },
    usersItemView: {
        marginHorizontal: Matrics.Scale(10),
        marginVertical: Matrics.Scale(5),
        // justifyContent:'center',
        flexDirection: 'row'
    },
    ItemSeparatorComponent: {
        borderBottomWidth: Matrics.Scale(1),
        marginTop: Matrics.Scale(1),
        borderColor: Colors.GREY
    },
    contentView: {
        marginHorizontal: Matrics.Scale(10),
        marginVertical: Matrics.Scale(5),
    },
    userNameText: {
        marginBottom: Matrics.Scale(5),
    },
    messageText: {
        color: Colors.GREY
    },
    headerRightView: {
        borderWidth: 1,
        marginRight: Matrics.Scale(15),
        borderRadius: Matrics.Scale(2),
        borderColor: Colors.GREY
    },
    headerRightText: {
        color: Colors.TEXT,
        paddingHorizontal: Matrics.Scale(10),
        paddingVertical: Matrics.Scale(5)
    }

})