export const TWILIO_API_KEY = 'QcmmMCQnqbEINtATkYWvouFqFCEaRFU8'
export const MASTER_ACCESS_KEY = "nousername"
  export const PORT_CONFIG = 'http://localhost:8000'
//  'http://192.168.1.202:9522'
  // export const PORT_CONFIG = 'http://clientapp.narola.online:9522'

export const MEDIA_THUMBNAIL_IMAGE_URL = 'http://clientapp.narola.online/pg/EmployeeManagementApp/API/chat_thumbnail/'
export const MEDIA_IMAGE_URL = 'http://clientapp.narola.online/pg/EmployeeManagementApp/API/chat_image/'
