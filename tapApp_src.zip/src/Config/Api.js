//LIBRARIES
import { AsyncStorage, Platform } from 'react-native';
import { TWILIO_API_KEY } from './Constants'


const LIVE = 'http://clientapp.narola.online/pg/EmployeeManagementApp/API/EmployeeManagementApp.php?Service='  //main url endpoint
// const STAGING =  


const TWILIO = 'https://api.authy.com/protected/json/phones/verification/'

const ENVIRONMENT = LIVE   //set to LIVE to go Live

//var headers = new Headers();
//headers.append("Authorization", "Basic " + base64.encode("MyTownTVAdmin:@6e6HtN5"));

module.exports = {

    //====================REFRESH TOKEN==================//

    getRefreshToken(params) {
        console.log(params, 'params FOR TOKEN')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}RefreshToken`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },


    //====================ENCRYPT TOKEN==================//

    encryptToken(params) {
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}TestEncryption`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })

    },


    //====================TWILIO PHONE VERIFICATION==================//



    registerPhoneNumber(params) {

        return fetch(`${TWILIO}/start`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Authy-API-Key': TWILIO_API_KEY
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })

    },

    //====================TWILIO OTP VERIFICATION FOR ENTERED NUMBER==================//


    verifyOTPNumber(params) {
        console.log(params)
        return fetch(`${TWILIO}/check?country_code=` + Number(params.country_code) + '&phone_number=' + Number(params.phone_number) + '&verification_code=' + Number(params.verification_code), {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-Authy-API-Key': TWILIO_API_KEY
            },

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })

    },

    phoneNumberCheck(params) {
        console.log(params, 'api params for phone')
        //First name in Api is userName for app
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}CheckPhoneNumber`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })

    },

    //====================USER LOGIN API==================//

    userLogin(params) {

        console.log(params, 'params on api')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"
        return fetch(`${ENVIRONMENT}Login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },
            body: JSON.stringify(params)
        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })

    },


    //====================FORGOT PASSWORD==================//

    forgotPassword(params) {

        console.log(params, 'params on api')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"
        return fetch(`${ENVIRONMENT}ForgotPassword`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },
            body: JSON.stringify(params)
        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })

    },


    //====================CHANGE PASSWORD==================//

    changePassword(params) {

        console.log(params, 'params on api')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"
        return fetch(`${ENVIRONMENT}ChangePassword`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },
            body: JSON.stringify(params)
        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })

    },







    //====================USER REGISTER API==================//

    userRegister(params) {
        console.log(params, 'api params')
        //First name in Api is userName for app
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}Register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })

    },


    //====================CHANGE PROFILE PICTURE API==================//

    changeProfilePic(params) {
        console.log(params, 'api params')
        //First name in Api is userName for app
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}ManageProfile`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })

    },

    //====================LOGOUT USER API==================//

    logoutUser(params) {
        console.log(params, 'api params logout>>>>>>>>>>>>>>>>>>>>>>>>')
        //First name in Api is userName for app
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}Logout`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //====================CHANGE USERNAME API==================//

    changeUserName(params) {
        console.log(params, 'api params')
        //First name in Api is userName for app
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}ManageProfile`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })

    },

    //====================SEARCH EMPLOYEE API==================//

    searchUsers(params) {
        console.log(params, 'api params')
        //First name in Api is userName for app
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}SearchUsers`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })

    },
    //====================ADD FRIEND API==================//

    addFriend(params) {
        console.log(params, 'api params')
        //First name in Api is userName for app
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}FollowUnfollowUser`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })

    },

    //====================GET MY FRIENDs API==================//

    getFriendList(params) {
        console.log(params, 'api params')
        //First name in Api is userName for app
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}ListOfFriends`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })

    },

    //====================CREATE FRIEND ALIAS==================//

    createFriendAlias(params) {
        console.log(params, 'api params')
        //First name in Api is userName for app
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}CreateUserAlias`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })

    },


    //====================............by j............==================//
    //====================CREATE CALENDAR API==================//
    CreateCalender(params) {
        console.log(params, 'api params CreateCalender>>>>>>>>>>>>>>>>>>>>>>>>')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}CreateCalender`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })

            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //====================ALL CALENDAR LIST API==================//
    GetAllCalender(params) {
        console.log(params, 'api params GetAllCalender>>>>>>>>>>>>>>>>>>>>>>>>')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}GetAllCalender`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //====================ALL List Of Todo Message API==================//
    ListOfTodoMessageList(params) {
        console.log(params, 'api params ListOfTodoMessageList>>>>>>>>>>>>>>>>>>>>>>>>')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}ListOfTodoMessageList`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //====================LIST OF MESSAGE API==================//
    ListOfMessages(params) {
        console.log(params, 'api params ListOfMessages>>>>>>>>>>>>>>>>>>>>>>>>')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}ListOfMessages`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })

            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //====================LIST OF TODO API==================//
    ListOfTodoList(params) {
        console.log(params, 'api params ListOfTodoList>>>>>>>>>>>>>>>>>>>>>>>>')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}ListOfTodoList`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })

            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //====================CREATE TODO API==================//
    CreateTodoListForStore(params) {
        console.log(params, 'api params CreateTodoListForStore>>>>>>>>>>>>>>>>>>>>>>>>')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}CreateTodoListForStore`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })

            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //====================EDIT TODO API==================//
    EditTodoList(params) {
        console.log(params, 'api params EditTodoList>>>>>>>>>>>>>>>>>>>>>>>>')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}EditTodoList`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //==================== AcceptRejectMessage API==================//
    AcceptRejectMessage(params) {
        console.log(params, 'api params AcceptRejectMessage>>>>>>>>>>>>>>>>>>>>>>>>')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}AcceptRejectMessage`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })

            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //==================== TaskApprovalManager API==================//
    TaskApprovalManager(params) {
        console.log(params, 'api params TaskApprovalManager>>>>>>>>>>>>>>>>>>>>>>>>')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}TaskApprovalManager`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })

            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //==================== ListRequestedUser API==================//
    ListRequestedUser(params) {
        console.log(params, 'api params ListRequestedUser>>>>>>>>>>>>>>>>>>>>>>>>')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}ListRequestedUser`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })

            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //==================== CreateMessageForStore API==================//
    CreateMessageForStore(params) {
        console.log(params, 'api params CreateMessageForStore>>>>>>>>>>>>>>>>>>>>>>>>')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}CreateMessageForStore`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })

            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //==================== GetEmployeeStores API==================//
    GetEmployeeStores(params) {
        console.log(params, 'api params GetEmployeeStores>>>>>>>>>>>>>>>>>>>>>>>>')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}GetEmployeeStores`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })

            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },


    //====================REMOVE FRIEND==================//

    removeSingleFriend(params) {
        console.log(params, 'api params')
        //First name in Api is userName for app
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}RemoveSingleFriends`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })

    },


    //===================GetStoreEmployee===================//
    GetStoreEmployee(params) {
        console.log(params, 'api params')
        //First name in Api is userName for app
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}GetStoreEmployee`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })
            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //==================== Delete Calendar API==================//
    DeleteCalender(params) {
        console.log(params, 'api params DeleteCalender>>>>>>>>>>>>>>>>>>>>>>>>')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}DeleteCalender`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })

            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //==================== Copy Calendar API==================//
    CopyCalender(params) {
        console.log(params, 'api params CopyCalender>>>>>>>>>>>>>>>>>>>>>>>>')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}CopyCalender`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },
            body: JSON.stringify(params)
        })

            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //==================== Edit Calendar API==================//
    EditCalender(params) {
        console.log(params, 'api params EditCalender>>>>>>>>>>>>>>>>>>>>>>>>')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}EditCalender`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })

            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //==================== Share Calendar API==================//
    ShareCalender(params) {
        console.log(params, 'api params ShareCalender>>>>>>>>>>>>>>>>>>>>>>>>')
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}ShareCalender`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: JSON.stringify(params)

        })

            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

    //====================ADD MEDIA API==================//
    addMedia(params) {
        console.log(params, 'api params UploadMediaForGroupMessage>>>>>>>>>>>>>>>>>>>>>>>>')

        var formData = new FormData();

        // formData.append("user_id", user_id);

        for (i = 0; i < params.mediaGroupMessage.length; i++) {
            console.log('ja rhi h loop me')
            formData.append(`mediaGroupMessage[${i}]`, params.mediaGroupMessage[i]);
        }
        if (Platform.OS == 'ios')
            userAgent = "iOS"
        else
            userAgent = "Android"

        return fetch(`${ENVIRONMENT}UploadMediaForGroupMessage`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': userAgent
            },

            body: formData

        })

            .then((response) => { setTimeout(() => null, 0); return response.json() })
    },

}  
