import React, { Component } from "react";
import { connect } from 'react-redux';
import {
    Text,
    View,
    Image,
    ScrollView,
    AsyncStorage,
    SafeAreaView,
    TouchableOpacity,
    FlatList,
    Picker,
    TextInput,
    Platform,
    ImageBackground
} from "react-native";
import _ from 'lodash';
//Assets
import { allCalendarList } from '@Redux/Actions/ScheduleAction'
// import { getEmployeeStore, getStorEemployee } from '../Redux/Actions/MessageTabActions';
import { HeaderBackButton } from '../Components'
import { profilePath } from "../Components/Common/imagePath";
import { LoadWheel } from "../Components/Common/LoadWheel";
import { Colors, Matrics, Images } from "../Assets";


let StoreUser_id = []
let selectedId = []
global.selectedUserList = []
let deviceType = Platform.OS == 'ios' ? 1 : 0;
class ChooseToUser extends React.Component {
    //NAVGATION OPTIONS FOR HEADER
    static navigationOptions = ({ navigation }) => ({
        headerTitle: 'Choose To User',
        headerTitleStyle: { flex: 1, textAlign: 'center' },
        headerLeft: <HeaderBackButton
            onBackPress={() => navigation.goBack()}
        />,
        headerRight: <View />
    })

    constructor(props) {
        super(props);
        this.state = {
            calendarListShowLoader: false,
            showLoader2: false,
            StoreEmployeeList: [],
            filterStoreEmployeeList: [],
            searchText: "",
            profileImage: '',
            user: {},
            pickerOn: false,
            selectedUser: [],
            StoreName: "Choose Store",
            CalendarList: [],
            StoreId: ''
        };
    }

    async componentWillMount() {
        console.log(this.props.navigation.state.params, 'this.props.navigation.state.params...')
        await this.GetAllCalenderList();
        // this.GetEmployeeStores();
        //this.GetStoreEmployee()
    }

    async componentWillReceiveProps(nextProps) {
        console.log(nextProps, 'nextProps');

        const nextPropsData = nextProps.calendarListDetail;
        console.log(nextPropsData, 'nextPropsData');

        // console.log(nextProps.EmployeeStoreDetail, 'nextProps.EmployeeStoreDetail');
        // console.log(nextProps.StoreEmployeeDetail, 'nextProps.StoreEmployeeDetail');

        // const nextPropGetEmployeeStore = nextProps.EmployeeStoreDetail;
        // console.log(nextPropGetEmployeeStore, 'nextPropGetEmployeeStore');

        // const nextPropGetStoreEmployee = nextProps.StoreEmployeeDetail;
        // console.log(nextPropGetStoreEmployee, 'nextPropGetStoreEmployee');


        // .....................calendar list.....................
        console.log(this.state.calendarListShowLoader, 'this.state.showLoader1');
        console.log(nextPropsData.data.status, '===================>>>>>>>>>>>>')
        if (nextPropsData.calendarListSuccess && nextPropsData.data.status == 1 && this.state.calendarListShowLoader) {
            await this.setState({ CalendarList: nextPropsData.data.StoreDetail, calendarListShowLoader: false });
            console.log(this.state.CalendarList, 'CalendarList');
            console.log('first if');

        }
        else if (nextPropsData.calendarListSuccess && nextPropsData.data.status == 0 && this.state.calendarListShowLoader) {
            this.setState({ calendarListShowLoader: false })
            alert(nextPropsData.data.message)
        }
        //if api doesn't get called
        else if (nextPropsData.calendarListFail) {
            this.setState({ calendarListShowLoader: false })
            alert('Something went wrong.Please try again later in calendar list.')
        }

        console.log(this.state.CalendarArrayList, '<<<<<<CalendarArrayList>>>>');

        // // .....................employee store.....................
        // console.log(this.state.showLoader1, 'this.state.showLoader1');
        // console.log(nextPropGetEmployeeStore.data.status, '===================>>>>>>>>>>>>')

        // if (nextPropGetEmployeeStore.getemployeeStoreSuccess && nextPropGetEmployeeStore.data.status == 1 && this.state.showLoader1) {
        //     this.setState({ StoreList: nextPropGetEmployeeStore.StoreDetail })
        //     this.setState({ showLoader1: false });
        // }
        // else if (nextPropGetEmployeeStore.getemployeeStoreSuccess && nextPropGetEmployeeStore.data.status == 0 && this.state.showLoader1) {
        //     this.setState({ showLoader1: false })
        //     alert(nextPropGetEmployeeStore.data.message)
        // }
        // //if api doesn't get called
        // else if (nextPropGetEmployeeStore.getemployeeStoreFail) {
        //     this.setState({ showLoader1: false })
        //     alert('Something went wrong.Please try again later.')
        // }

        // ..................... store employee .....................
        console.log(this.state.showLoader2, 'this.state.showLoader1');
        // console.log(nextPropGetStoreEmployee.data.status, '===================>>>>>>>>>>>>')

        // if (nextPropGetStoreEmployee.getStoreEmployeeSuccess && nextPropGetStoreEmployee.data.status == 1 && this.state.showLoader2) {

        //     this.setState({ StoreEmployeeList: json.EmployeeDetail });
        //     this.setState({ filterStoreEmployeeList: json.EmployeeDetail });

        //     this.setState({ showLoader2: false });
        //     console.log('first if');
        // }
        // else if (nextPropGetStoreEmployee.getStoreEmployeeSuccess && nextPropGetStoreEmployee.data.status == 0 && this.state.showLoader2) {
        //     this.setState({ showLoader2: false })
        //     alert(nextPropGetStoreEmployee.data.message)
        // }
        // //if api doesn't get called
        // else if (nextPropGetStoreEmployee.getStoreEmployeeFail) {
        //     this.setState({ showLoader2: false })
        //     alert('Something went wrong.Please try again later.')
        // }
    }

    //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< calendar list api Start  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    async GetAllCalenderList() {

        console.log(this.props, '<<<<<props GetAllCalenderList>>>>>>');

        await this.setState({ calendarListShowLoader: true })

        console.log('access_key:', this.props.encryptedToken)
        console.log('secret_key:', this.props.userDetail.data.userToken);

        this.props.allCalendarList({
            secret_key: this.props.userDetail.data.userToken,
            access_key: this.props.encryptedToken,
            device_token: "12345678",
            device_type: deviceType,
            user_id: this.props.userInfo.id,
            is_testdata: "1"
        })
    }
    // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< calendar list api End  >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    // GetStoreEmployee(itemid) {

    //     this.setState({ showLoader2: true });
    //     let endPoint = 'GetStoreEmployee';
    //     let body = '';

    //     this.props.getStorEemployee({
    //         secret_key: this.props.userDetail.data.userToken,
    //         access_key: this.props.encryptedToken,
    //         device_token: "12345678",
    //         device_type: deviceType,
    //         user_id: this.props.userInfo.id,
    //         store_id: itemid,
    //         is_testdata: "1"
    //     })

    // APICaller(endPoint, 'post', body).then(async (json) => {
    //     console.log(json, 'GetStoreEmployee json response');

    //     if (json.status == 1) {
    //         // alert(json.message);
    //         // this.props.navigation.navigate('friendScreen')

    //         this.setState({ StoreEmployeeList: json.EmployeeDetail });
    //         this.setState({ filterStoreEmployeeList: json.EmployeeDetail });
    // }


    renderItem = (item) => (
        <TouchableOpacity
            onPress={async () => {
                console.log(item, '...item...');

                let arr = this.state.StoreEmployeeList;
                console.log(arr, item, 'arr....');

                if (!item.item.isSelected) {
                    arr[item.index]['isSelected'] = true
                    console.log(item.item.isSelected, 'isSelected')
                    await this.setState({ selectedUser: [...this.state.selectedUser, item.item.main_user_id] })
                    console.log(this.state.selectedUser, 'selectedUser');

                    StoreUser_id = this.state.selectedUser
                    console.log(StoreUser_id, 'StoreUser_id');

                } else {
                    arr[item.index]['isSelected'] = false
                    let arr1 = this.state.selectedUser
                    var indx = arr1.indexOf(item.item.main_user_id)
                    console.log(indx, "indx")
                    if (indx !== -1) {
                        arr1.splice(indx, 1);
                        console.log(arr1, 'arr1')
                        this.setState({ selectedUser: arr1, StoreEmployeeList: arr });
                    }
                }

                this.setState({ StoreEmployeeList: arr })
                console.log(this.state.StoreEmployeeList, 'StoreEmployeeList..............');
                console.log(this.state.selectedUser, 'selectedUser..............');

            }}>

            <View style={{ flexDirection: 'row', height: Matrics.Scale(60), }}>
                <View style={{
                    flex: 0.1,
                    // backgroundColor:'red',
                    alignItems: 'center',
                    marginLeft: Matrics.Scale(10),
                    marginRight: Matrics.Scale(10),
                    justifyContent: 'center',
                }}>
                    <Image
                        // source={Images.unselectStoreUser}
                        source={item.item.isSelected ? Images.selsctStoreUser : Images.unselectStoreUser}
                        resizeMode='stretch'
                        style={{
                            borderRadius: Platform.OS === 'ios' ? Matrics.Scale(12.5) : Matrics.Scale(105),
                            height: Matrics.Scale(25),
                            width: Matrics.Scale(25),
                        }} />
                </View>

                <View style={{
                    flex: 0.1,
                    // backgroundColor: 'red',
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginLeft: Matrics.Scale(5),
                }}> 
                    <ImageBackground
                        source={Images.friendIcon}
                        resizeMode='stretch'
                        style={{
                            borderRadius: Matrics.Scale(105),
                            height: Matrics.Scale(35),
                            width: Matrics.Scale(35),
                        }}>

                        <Image
                            source={Images.friendIcon}
                            source={item.item.image ? { uri: profilePath + item.item.image } : Images.friendIcon}

                            resizeMode='stretch'
                            style={{
                                borderRadius: Matrics.Scale(105),
                                height: Matrics.Scale(45),
                                width: Matrics.Scale(45),
                            }} />
                    </ImageBackground>
                </View>


                <View style={{
                    flex: 0.8,
                    // backgroundColor: 'yellow',
                    borderColor: Colors.TAB_BG,
                    alignContent: 'center',
                    justifyContent: 'center',
                    borderBottomWidth: 1,
                    marginLeft: Matrics.Scale(15),
                }}>
                    <Text style={{
                        justifyContent: 'center',
                        fontSize: 18
                    }}>
                        {item.item.firstname}
                    </Text>
                </View>

            </View>
        </TouchableOpacity>
    );


    searchUser(text) {
        let arr = this.state.filterStoreEmployeeList.filter(item => {
            return (item.firstname.toLowerCase().match(text.toLowerCase()))
        })
        this.setState({ StoreEmployeeList: arr })
        console.log(arr, 'arr');
    }

    // GetEmployeeStores() {
    //     this.setState({ showLoader1: true });

    //     this.props.getEmployeeStore({
    //         secret_key: this.props.userDetail.data.userToken,
    //         access_key: this.props.encryptedToken,
    //         device_token: "12345678",
    //         device_type: deviceType,
    //         user_id: this.props.userInfo.id,
    //         is_testdata: "1"
    //     })
    // }

    render() {
        return (
            <SafeAreaView style={{ flex: 1 }}>

                <View style={{ flex: 1, }}>

                    {/* ----------------- Store Select Sart --------------------- */}
                    <View style={{
                        borderWidth: 1,
                        borderColor: 'gray',
                        height: Matrics.Scale(50),
                        justifyContent: 'center',
                        borderColor: 'gray',
                        borderRadius: Matrics.Scale(2),
                        margin: Matrics.Scale(5)
                    }}>
                        <TouchableOpacity
                            onPress={() => {
                                if (!this.state.pickerOn) {
                                    this.setState({ pickerOn: true })

                                } else {
                                    this.setState({ pickerOn: false })
                                }
                                // this.setState({ enterButtonOn: true })
                            }}
                            style={{
                                height: Matrics.Scale(50),
                                justifyContent: 'center'
                            }}>

                            <View style={{
                                flex: 1, flexDirection: 'row',
                                alignItems: 'center'
                            }}>
                                <View style={{ flex: 0.9, }}>
                                    <Text style={Styles.tabText}>
                                        {this.state.StoreName}
                                    </Text>
                                </View>

                                <View style={{ flex: 0.1, alignItems: 'center' }}>
                                    <Image
                                        style={{
                                            height: Matrics.Scale(5),
                                            width: Matrics.Scale(10)
                                        }}
                                        source={Images.DowonArrow}
                                        resizeMode='stretch' />
                                </View>
                            </View>

                        </TouchableOpacity>
                    </View>
                    {
                        this.state.pickerOn &&
                        <Picker
                            style={{
                                width: '100%',
                            }}
                            itemStyle={{
                                borderWidth: 1,
                                height: Matrics.Scale(120),
                                width: '100%', borderColor: 'gray'
                            }}
                            selectedValue={this.state.StoreName}
                            onValueChange={(item) => {
                                console.log(item, 'item.......');

                                if (item.id != 0 && item.id != null) {
                                    // this.GetStoreEmployee(item.id)
                                    selectedId = [item.user_id]
                                    console.log(selectedId, '....selectedId......');
                                } else {
                                    alert('Please choose store')
                                    this.setState({ StoreEmployeeList: '' });
                                }
                                this.setState({
                                    StoreName: item.title ? item.title : 'Select Store', choosenIndex: item.Position, pickerOn: false
                                })

                            }}>
                            <Picker.Item label={"Choose store"} value={'Choose store'} />
                            {this.state.CalendarList.map(item => {
                                // console.log(this.state.CalendarList, '<<<<<StateCalendarList>>>>>');
                                return <Picker.Item label={item.title} value={item} />
                            })
                            }
                        </Picker>
                    }

                    {/* ----------------- Store Select End --------------------- */}

                    <ScrollView style={{ flex: 1 }}>
                        <View style={{
                            backgroundColor: Colors.STATUS_BAR_COLOR,
                            paddingLeft: Matrics.Scale(5),
                            alignItems: 'center', flexDirection: 'row',
                            borderRadius: Matrics.Scale(5),
                            margin: Matrics.Scale(5),
                            borderColor: '#FFFFFF',
                            borderWidth: 1
                        }}>
                            <Image
                                source={Images.search_icon}
                                // resizeMode='cover'
                                resizeMode='stretch'
                                style={{
                                    width: Matrics.Scale(13), height: Matrics.Scale(15),
                                    marginLeft: Matrics.Scale(10)
                                }}
                            />

                            <TextInput
                                style={{
                                    fontSize: Matrics.Scale(18), padding: Matrics.Scale(10),
                                    height: Matrics.Scale(40), width: '90%',
                                }}
                                onChangeText={val => this.searchUser(val)}
                                placeholder={"Search Id"}
                            />

                        </View>
                        < FlatList
                            contentContainerStyle={{ flex: 1, }}
                            data={this.state.StoreEmployeeList}
                            extraData={this.state}
                            renderItem={this.renderItem} />

                    </ScrollView>

                    <View style={{
                        backgroundColor: Colors.LIGHTYELLOW,
                        position: 'absolute', alignItems: 'center',
                        justifyContent: "flex-end", bottom: 0, width: '100%'
                    }}>
                        <TouchableOpacity
                            onPress={() => {
                                // this.props.navigation.state.params.addItem(this.state.selectedUser)

                                // console.log(StoreUser_id, 'save button StoreUser_id');
                                // console.log(selectedId, 'save button selectedId');
                                global.AllUserList = selectedId.concat(StoreUser_id)
                                console.log(global.AllUserList, 'save button AllUserList : Store User_id + selected id');

                                this.props.navigation.navigate('EditSchedule')
                            }}

                            style={Styles.buttonContainer}>
                            <Text style={{
                                fontWeight: '600',
                                fontSize: Matrics.Scale(18),
                                color: Colors.LOGIN,
                            }}>SAVE</Text>
                        </TouchableOpacity>
                    </View>

                    <LoadWheel isVisible={this.state.calendarListShowLoader || this.state.showLoader2} />
                </View >
            </SafeAreaView>
        );
    }
}

const Styles = {
    buttonContainer: {
        backgroundColor: 'white',
        height: Matrics.Scale(40),
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "center",
        borderWidth: 1.5,
        width: '60%',
        borderColor: Colors.LOGIN,
        margin: Matrics.Scale(20),
        borderRadius: Matrics.Scale(5)
    },
    tabManiView: {
        borderBottomColor: '#B6B4B6',
        borderBottomWidth: 1,
        borderTopColor: '#B6B4B6',
        borderTopWidth: 1,
        flex: 0.33,
    },
    tabLayoutView: {
        borderWidth: 1,
        marginBottom: Matrics.Scale(7),
        borderColor: 'gray',
        height: Matrics.Scale(50),
        justifyContent: 'center'
    },
    tabText: {
        marginLeft: Matrics.Scale(10)
    },
}

//Props Connection
const mapStateToProps = (state) => {
    console.log(state, 'state==================');

    return {
        calendarListDetail: state.Schedule,
        // EmployeeStoreDetail: state.GetEmployeeStore,
        // StoreEmployeeDetail: state.GetStoreEmployee,
        userDetail: state.Auth,
        encryptedToken: state.Encrypt.data ? state.Encrypt.data.encrypted_value : undefined,
        userInfo: state.Auth.data && state.Auth.data.data ? state.Auth.data.data.User : undefined,
    };
}
//Redux Connection  
export default connect(mapStateToProps, { allCalendarList })(ChooseToUser);