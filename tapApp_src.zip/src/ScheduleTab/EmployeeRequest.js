//LIBRARIES
import React, { Component } from "react";
import { connect } from 'react-redux';
import { Text, View, Image, Platform, FlatList, ImageBackground } from "react-native";
//Assets
import { listRequestedUser } from '@Redux/Actions/AcceptRejecrMessageActions'
import { logOutRequest } from '@Redux/Actions/AuthActions'
import { Colors, Matrics, Images } from "../Assets";
import { LoadWheel } from "../Components/Common/LoadWheel";
import { HeaderBackButton } from '../Components'
import { profilePath } from "../Components/Common/imagePath";
import language from '../Assets/Languages/Language'

let Nodata = true
let deviceType = Platform.OS == 'ios' ? 1 : 0;
class EmployeeRequest extends React.Component {
    //NAVGATION OPTIONS FOR HEADER
    static navigationOptions = ({ navigation }) => ({
        headerTitle: language.editschedule.header,
        headerTitleStyle: { flex: 1, textAlign: 'center' },
        headerLeft: <HeaderBackButton
            onBackPress={() => {
                navigation.goBack()
                console.log('goBack')
            }}
        />,
        headerRight: <View />
    })
    constructor(props) {
        super(props);
        this.state = {
            logoutFlag: true,
            loading: false,
            RequestedUsershowLoader: false,
            RequestedUserList: [],
            calendarId: '',
        };
    }

    async componentWillMount() {
        this.offset = 0;
        if (this.props.navigation.state.params) {
            console.log(this.props.navigation.state.params, 'employee Request navigation params')
            await this.setState({ calendarId: this.props.navigation.state.params.data.calendar_id })
            console.log(this.state.calendarId, 'calendart task id');

        }
        await this.ListRequestedUser(this.offset)
    }

    async componentWillReceiveProps(nextProps) {

        console.log(nextProps, 'nextProps');
        console.log(nextProps.ListRequestedUserDetail, 'nextProps.ListRequestedUserDetail');

        const nextListRequesteduser = nextProps.ListRequestedUserDetail;
        console.log(nextListRequesteduser, 'nextListRequesteduser');

        // .....................ListRequestedUser.....................
        if (nextListRequesteduser.listRequestedUserSuccess && nextListRequesteduser.data.status == 1 && this.state.RequestedUsershowLoader) {
            if (this.state.RequestedUserList.length == 0) {
                await this.setState({ RequestedUserList: nextListRequesteduser.data.RequestedUser });
                console.log(this.state.RequestedUserList, 'RequestedUserList');
                await this.setState({ RequestedUsershowLoader: false })
            }
            else {
                this.setState({ RequestedUserList: [...this.state.RequestedUserList, ...nextListRequesteduser.data.RequestedUser] });
            }
            this.setState({ RequestedUsershowLoader: false });

        }
        else if (nextListRequesteduser.listRequestedUserSuccess && nextListRequesteduser.data.status == 0 && this.state.RequestedUsershowLoader) {
            this.setState({ RequestedUsershowLoader: false })
            alert(nextListRequesteduser.data.message)
        }
        else if (nextListRequesteduser.listRequestedUserSuccess && nextListRequesteduser.data.status == 3 && this.state.logoutFlag && this.state.showLoader1) {
            await this.setState({ logoutFlag: false, RequestedUsershowLoader: false })
            console.log("Logout calendar list");
            this.LogoutAlert()
        }
        //if api doesn't get called
        else if (nextListRequesteduser.listRequestedUserFail) {
            this.setState({ RequestedUsershowLoader: false })
            alert('Something went wrong.Please try again later.')
        }
        // .....................Logout .............................
        else if (nextProps.logout.logoutFail) {
            alert('something went wrong.Please try again')
        }
        //logout success
        else if (nextProps.logout.logoutSuccess && nextProps.logout.data.status == 1 && !this.state.logoutFlag) {
            await AsyncStorage.getAllKeys().then(AsyncStorage.multiRemove)
            await AsyncStorage.removeItem('refreshtoken')
            this.getRefreshToken()
        }



    }

    // logOut............
    async onLogoutPress() {
        // TO DO - add dynamic device token
        await this.props.logOutRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            user_id: this.props.userInfo.id,
            device_token: "123456",
            device_type: deviceType,
            "is_testdata": "1"
        })
    }

    LogoutAlert() {
        Alert.alert(
            'Alert',
            'There is login detected for this user in another device. so, please logout and login again',
            [
                {
                    text: 'Logout',
                    onPress: () => this.onLogoutPress(),
                },
            ],
        );
    }

    loadMoreData = () => {
        console.log(this.offset, 'loadMoreData');

        if (this.state.RequestedUserList.length != 0 && Nodata) {
            this.offset = this.offset + 1;
            setTimeout(() => { this.ListRequestedUser(this.offset) }, 500)
        }
    }

    loadEmptyView = () => {
        console.log('hello');

        return (
            <View style={Styles.emptyListView}>
                <Text
                    // numberOfLines={1}
                    style={Styles.emptyText}>
                    No Data Found
                        </Text>
            </View>
        );
    }

    async ListRequestedUser(offset) {

        console.log(this.props, '<<<<<props listRequestedUser>>>>>>');
        await this.setState({ RequestedUsershowLoader: true })
        console.log('access_key:', this.props.encryptedToken)
        console.log('secret_key:', this.props.userDetail.data.userToken);
        console.log('userInfo:', this.props.userInfo);

        this.props.listRequestedUser({
            secret_key: this.props.userDetail.data.userToken,
            access_key: this.props.encryptedToken,
            device_token: "12345678",
            user_id: this.props.userInfo.id,
            calendar_task_id: this.state.calendarId,
            device_type: deviceType,
            is_testdata: "1",
            offset: this.offset
        })
    }
    // for static testing...
    // user_id: "1",
    // calendar_task_id: "76",

    render() {
        // console.log(this.state.RequestedUserList, '=======RequestedUserList=========');

        return (
            <View style={{ flex: 1, }}>
                {
                    this.state.RequestedUserList.length > 0 ?
                        <FlatList
                            data={this.state.RequestedUserList}
                            extraData={this.state}
                            renderItem={(item) => {
                                console.log(item, 'Message item');

                                return (
                                    <View style={{ flex: 1, flexDirection: 'row' }}>

                                        <View style={Styles.FlatListmain}>

                                            <ImageBackground
                                                source={Images.friendIcon}
                                                resizeMode='stretch'
                                                style={Styles.ImageBackground}>

                                                <Image
                                                    source={item.image ? { uri: profilePath + item.image } : Images.friendIcon}
                                                    resizeMode='stretch'
                                                    style={Styles.imageStyle} />
                                            </ImageBackground>

                                        </View>


                                        <View style={Styles.FlatListView}>
                                            <View>
                                                <Text style={{ justifyContent: 'center', fontSize: 18 }}>
                                                    {item.item.firstname}
                                                </Text>
                                            </View>
                                            <View>
                                                <Text style={{ justifyContent: 'center', fontSize: 12 }}>
                                                    {item.item.user_comment}
                                                </Text>
                                            </View>

                                        </View>

                                        <View style={Styles.view}>
                                            {
                                                item.item.status == 0 &&
                                                <Text style={{ color: 'orange' }}>
                                                    Pending
                                        </Text>
                                            }
                                            {
                                                item.item.status == 1 &&
                                                <Text style={{ color: 'green' }}>
                                                    Accepted
                                        </Text>
                                            }
                                            {
                                                item.item.status == 2 &&
                                                <Text style={{ color: 'red' }}>
                                                    Rejected
                                        </Text>
                                            }

                                        </View>
                                    </View>
                                )
                            }}
                            ListEmptyComponent={() => this.loadEmptyView()}
                            onEndReached={() => this.loadMoreData()}
                            onEndReachedThreshold={0.5}
                            showsVerticalScrollIndicator={false}
                        />
                        :
                        this.loadEmptyView()
                }
                <LoadWheel isVisible={this.state.RequestedUsershowLoader} />
            </View>
        )
    }
}
const Styles = {
    emptyListView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    emptyText: {
        color: 'red',
        textAlign: 'center',
        fontSize: Matrics.Scale(17),
    },
    ImageBackground: {
        marginLeft: Matrics.Scale(10),
        height: Matrics.Scale(35),
        width: Matrics.Scale(35),
    },
    imageStyle: {
        // marginLeft: Matrics.Scale(10),
        height: Matrics.Scale(35),
        width: Matrics.Scale(35),
    },
    FlatListmain: {
        height: Matrics.Scale(60),
        flex: 0.2,
        justifyContent: 'center',
        marginLeft: Matrics.Scale(10)
    },
    FlatListView: {
        flex: 0.6,
        height: Matrics.Scale(60),
        alignContent: 'center',
        justifyContent: 'center',
        borderColor: Colors.TAB_BG,
        borderBottomWidth: 1,
    },
    view: {
        flex: 0.2,
        height: Matrics.Scale(60),
        alignItems: 'center',
        justifyContent: 'center',
        borderColor: Colors.TAB_BG,
        borderBottomWidth: 1,
        marginRight: Matrics.Scale(10)
    }
}

//Props Connection
const mapStateToProps = (state) => {
    console.log(state, 'state EmployeeRequest==================');

    return {
        ListRequestedUserDetail: state.ListOfRequestedUser,
        logout: state.Logout,
        userDetail: state.Auth,
        encryptedToken: state.Encrypt.data ? state.Encrypt.data.encrypted_value : undefined,
        userInfo: state.Auth.data && state.Auth.data.data ? state.Auth.data.data.User : undefined,
    };
}

//Redux Connection
export default connect(mapStateToProps, { listRequestedUser, logOutRequest })(EmployeeRequest);