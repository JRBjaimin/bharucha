//Libraries
import React from 'react'
import { connect } from 'react-redux';
import { Text, View, Image, ScrollView, SafeAreaView,
     Alert, TouchableOpacity, FlatList, Platform } from "react-native";
import { Calendar, CalendarList, Agenda } from 'react-native-calendars';
import { EventRegister } from 'react-native-event-listeners';
import AsyncStorage from '@react-native-community/async-storage';
import moment from 'moment';
//Assets
import { allCalendarList, listOfMessage, listOfTodoList, listOfTodoMessageList } from '@Redux/Actions/ScheduleAction'
import { logOutRequest } from '@Redux/Actions/AuthActions'
import { HeaderEditLeftButton } from '../Components'
import { Images, Colors, Matrics } from '../../src/Assets';
import { LoadWheel } from "../Components/Common/LoadWheel";
import language from '../Assets/Languages/Language'

let Nodata = false
let NodataToDO = false
let deviceType = Platform.OS == 'ios' ? 1 : 0;
const vacation = { key: 'vacation', color: 'red', selectedDotColor: 'blue' };
const massage = { key: 'massage', color: 'blue', selectedDotColor: 'blue' };
const workout = { key: 'workout', color: 'green' };
//MAIN CLASS
class Schedule extends React.Component {

    //NAVGATION OPTIONS FOR HEADER
    static navigationOptions = ({ navigation }) => ({
        headerTitle: language.schedule.header,
        headerTitleStyle: { flex: 1, textAlign: 'center' },
        headerLeft: <HeaderEditLeftButton
            onEditLeftPress={() => { navigation.navigate('EditSchedule', { CalendarTab: true }) }}
        />,
        headerRight: <View />
    })

    constructor(props) {
        super(props);
        this.currentDate = new Date;
        this.state = {
            logoutFlag: true,
            showLoader1: false,
            ListMessageShowLoader: false,
            ListTodoShowLoader: false,
            AllmessageTodoShowLoader: false,
            refresh_token: '',
            TodoColorDate: {},
            MessageColorDate: {},
            AllColorDate: {},

            demo2: {},
            // userId: props.userDetail && props.userDetail.data && props.userDetail.data.data && props.userDetail.data.data.User.id,

            isDateTimePickerVisible: false,
            time: "Select Time",
            messageTab: true,
            todoTab: false,
            MessageButton: true,
            TodoButton: false,
            MessageList: [],
            TodoList: [],
            LoadData: true,
            startTime: '',
            endTime: '',
            dateSelected: '',
            dateselectedList: [],
            CalendarArrayList: [],
            StaticCalendarlistdata: [
                // {
                //     // created_date: "2019-07-24 12:22:09",
                //     // description: "test calendar",
                //     // id: "0",
                //     // isMember_stroe: 0,
                //     // is_delete: "0",
                //     // is_testdata: "1",
                //     // modified_date: "2019-07-24 17:52:09",
                //     // store_id: 0,
                //     // title: "All",
                //     // user_id: this.props.userInfo.id,
                // }
            ],

            SelectedCalander: false,
            SelectedCalendarIndex: '',
            SelectedCalendarID: '1',
            SelectedCalendarTitle: '',
            AllSelected: true,
        }
    }

    async componentWillMount() {
        this.offset = 0;
        this.offsetTodo = 0;
        this.offsetAll = 0;

        await this.AllListOfTodoMessageList(this.offsetAll);
        await this.GetAllCalenderList();
    }

    async componentWillReceiveProps(nextProps) {

        console.log(nextProps, '..nextProps..');

        const nextPropsData = nextProps.calendarListDetail;
        const nextPropListOfMessage = nextProps.listOfMessageDetail
        // console.log(nextPropListOfMessage, 'nextPropListOfMessage.....');

        const nextPropListOfTodo = nextProps.listOfTodoDetail
        const nextPropAllList = nextProps.AllTodoMessageListDetail

        // .....................calendar list.....................
        // console.log(this.state.showLoader1, 'this.state.showLoader1');
        if (nextPropsData.calendarListSuccess && nextPropsData.data.status == 3 && this.state.logoutFlag && this.state.showLoader1) {
            await this.setState({ logoutFlag: false, showLoader1: false, ListMessageShowLoader: false, ListTodoShowLoader: false, AllmessageTodoShowLoader: false })
            // alert(nextPropsData.data.message)
            console.log("Logout calendar list");
            this.LogoutAlert()
        }
        else if (nextPropsData.calendarListSuccess && nextPropsData.data.status == 1 && this.state.showLoader1) {
            await this.setState({ showLoader1: false, CalendarArrayList: [...this.state.StaticCalendarlistdata, ...this.state.CalendarArrayList, ...nextPropsData.data.StoreDetail] });
            console.log('first if-----------');
        }
        else if (nextPropsData.calendarListSuccess && nextPropsData.data.status == 0 && this.state.showLoader1) {
            await this.setState({ showLoader1: false })
            alert(nextPropsData.data.message)
        }
        //if api doesn't get called
        else if (nextPropsData.calendarListFail) {
            this.setState({ showLoader1: false })
            alert('Something went wrong.Please try again later.')
        }
        // console.log(this.state.CalendarArrayList, '<<<<<<CalendarArrayList>>>>');

        // .....................Logout .............................
        else if (nextProps.logout.logoutFail) {
            alert('something went wrong.Please try again')
        }
        //logout success
        else if (nextProps.logout.logoutSuccess && nextProps.logout.data.status == 1 && !this.state.logoutFlag) {
            await AsyncStorage.getAllKeys().then(AsyncStorage.multiRemove)
            await AsyncStorage.removeItem('refreshtoken')
            this.getRefreshToken()
        }


        // .....................All Message and Todo list.....................
        console.log(this.state.AllmessageTodoShowLoader, 'this.state.AllmessageTodoShowLoader');
        console.log(this.state.ListMessageShowLoader, 'All.....ListMessageShowLoader');
        if (nextPropAllList.allTodoMessageListSuccess && nextPropAllList.data.status == 3 && this.state.logoutFlag && this.state.AllmessageTodoShowLoader) {
            await this.setState({ logoutFlag: false, AllmessageTodoShowLoader: false, ListMessageShowLoader: false, ListTodoShowLoader: false, AllmessageTodoShowLoader: false })
            console.log("Logout All Message and Todo list");
            this.LogoutAlert()
        }
        else if (nextPropAllList.allTodoMessageListSuccess && nextPropAllList.data.status == 1 && this.state.AllmessageTodoShowLoader) {
            await this.setState({
                MessageList: nextPropAllList.data.MessageDetail,
                TodoList: nextPropAllList.data.ToDoDetail,
            })
            await this.DisplayCalendarDate();
            await this.setState({ AllmessageTodoShowLoader: false })
            console.log("All MessageList:", this.state.MessageList);
            console.log("All TodoList:", this.state.TodoList)
            console.log("first if All Message and Todo list-----------")
        }
        else if (nextPropAllList.allTodoMessageListSuccess && nextPropAllList.data.status == 0 && this.state.AllmessageTodoShowLoader) {
            await this.setState({ AllmessageTodoShowLoader: false })
            alert(nextPropAllList.data.message)
        }
        //if api doesn't get called
        else if (nextPropAllList.allTodoMessageListFail) {
            this.setState({ AllmessageTodoShowLoader: false })
            alert('Something went wrong.Please try again later.')
        }

        // .....................List of message.....................

        console.log(nextProps.listOfMessageDetail.messageListSuccess, "nextProps.listOfMessageDetail.messageListSuccess");
        console.log(nextProps.listOfMessageDetail.data.status == 1, "nextProps.listOfMessageDetail.data.status == 1");
        console.log(this.state.ListMessageShowLoader, "befor condition ListMessageShowLoader");

        if (nextProps.listOfMessageDetail.messageListSuccess && nextProps.listOfMessageDetail.data.status == 1 && this.state.ListMessageShowLoader) {
            console.log(this.state.MessageList.length, "...this.state.MessageList.length");
            console.log(nextProps.listOfMessageDetail.data.MessageDetail.length, "...nextProps.listOfMessageDetail.data.MessageDetail");


            // if (this.state.MessageList.length == 0) {
            if (nextProps.listOfMessageDetail.data.MessageDetail.length == 0) {
                console.log(this.state.MessageList, 'Before...list')
                console.log(nextProps.listOfMessageDetail.data.MessageDetail, 'nextProps.listOfMessageDetail.data.MessageDetail')

                await this.setState({ MessageList: nextProps.listOfMessageDetail.data.MessageDetail });
                await this.DisplayCalendarDate();
                await this.setState({ ListMessageShowLoader: false })
                console.log(this.state.MessageList, 'if:::::::MessageList:::::::');
            }
            else {
                console.log(this.state.MessageList, 'Before listelse:::::::MessageList:::::::');
                await this.setState({ MessageList: nextProps.listOfMessageDetail.data.MessageDetail });
                console.log(this.state.MessageList, 'else:::::::MessageList:::::::');
                await this.DisplayCalendarDate()
                console.log('after dote display');

                await this.setState({ ListMessageShowLoader: false })
            }
            this.setState({ ListMessageShowLoader: false })
            console.log("if.....");

        }
        else if (nextProps.listOfMessageDetail.messageListSuccess && nextProps.listOfMessageDetail.data.status == 0 && this.state.ListMessageShowLoader) {
            await this.setState({ ListMessageShowLoader: false })
            alert(nextProps.listOfMessageDetail.data.message)
        } else if (nextProps.listOfMessageDetail.messageListSuccess && nextProps.listOfMessageDetail.data.status == 3 && this.state.logoutFlag && this.state.ListMessageShowLoader) {
            await this.setState({ logoutFlag: false, showLoader1: false, ListMessageShowLoader: false, ListTodoShowLoader: false, AllmessageTodoShowLoader: false })
            this.LogoutAlert()
        }
        //if api doesn't get called
        else if (nextProps.listOfMessageDetail.messageListFail) {
            await this.setState({ ListMessageShowLoader: false })
            alert('Something went wrong.Please try again later.')
        }

        // this.setState({ ListMessageShowLoader: false })
        console.log(this.state.MessageList, '<<<<<<MessageList>>>>');


        // .....................List of Todo.....................
        // console.log(this.state.ListTodoShowLoader, nextPropListOfTodo.data.status, nextPropListOfTodo.todoListSuccess, '...ListTodoShowLoader...');

        if (nextPropListOfTodo.todoListSuccess && nextPropListOfTodo.data.status == 1 && this.state.ListTodoShowLoader) {
            if (this.state.TodoList.length == 0) {
                await this.setState({ TodoList: nextPropListOfTodo.data.ToDoDetail });
                // await this.DisplayCalendarDate()
                await this.setState({ ListTodoShowLoader: false })
                console.log(this.state.TodoList, 'if:::::::TodoList:::::::');
            }
            else {
                await this.setState({ TodoList: [...this.state.TodoList, ...nextPropListOfTodo.data.ToDoDetail] });
                console.log(this.state.TodoList, 'else:::::::TodoList:::::::');
                // await this.DisplayCalendarDate()
                this.setState({ ListTodoShowLoader: false })
            }
            // this.setState({ ListTodoShowLoader: false })

            await this.ListOfMessages(this.offset);
        }
        else if (nextPropListOfTodo.todoListSuccess && nextPropListOfTodo.data.status == 0 && this.state.ListTodoShowLoader) {
            this.setState({ ListTodoShowLoader: false })
            alert(nextPropListOfTodo.data.message)
        }
        //if api doesn't get called
        else if (nextPropListOfTodo.todoListFail) {
            this.setState({ ListTodoShowLoader: false })
            alert('Something went wrong.Please try again later.')
        }
        else if (nextPropListOfTodo.todoListSuccess && nextPropListOfTodo.data.status == 3 && this.state.logoutFlag && this.state.ListTodoShowLoader) {
            await this.setState({ logoutFlag: false, showLoader1: false, ListMessageShowLoader: false, ListTodoShowLoader: false, AllmessageTodoShowLoader: false })
            this.LogoutAlert()
        }
        // this.setState({ ListTodoShowLoader: false })
        console.log(this.state.TodoList, '<<<<<<TodoList>>>>');

    }

    async componentDidMount() {
        EventRegister.addEventListener('reloadCalandarList', async (response) => {
            console.log(response, 'reloadCalandarList');
            await this.setState({ CalendarArrayList: [] })
            await this.GetAllCalenderList();
        });
        EventRegister.addEventListener('deleteCalandar', async (response) => {
            console.log(response, 'deleteCalandar');
            await this.setState({ CalendarArrayList: [] })
            await this.GetAllCalenderList();
        });
        EventRegister.addEventListener('CopyCalandar', async (response) => {
            console.log(response, 'CopyCalandar');
            await this.setState({ TodoList: [] })
            await this.setState({ MessageList: [] })
            await this.ListOfTodoList(this.offsetTodo);
            await this.ListOfMessages(this.offset);
        });
        EventRegister.addEventListener('createMessage', async (response) => {
            console.log(response, '...createMessage...');
            this.offset = response.offset
            await this.setState({ MessageList: [] })
            await this.ListOfMessages(this.offset);
        });
        EventRegister.addEventListener('createTodo', async (response) => {
            console.log(response, '...createTodo...');
            console.log(response.offsetTodo, '...response.offsetTodo...');
            this.offsetTodo = response.offsetTodo
            await this.setState({ TodoList: [] })
            console.log(this.state.TodoList, "========TodoList======");
            await this.ListOfTodoList(this.offsetTodo);
            await this.DisplayCalendarDate();
            console.log("create Done");
        });
        EventRegister.addEventListener('editTodo', async (response) => {
            console.log(response, '...editTodo...');
            console.log(response.offsetTodo, '...response.offsetTodo...');
            this.offsetTodo = response.offsetTodo
            await this.setState({ TodoList: [], AllColorDate: {} })
            console.log(this.state.TodoList, "========TodoList======");
            await this.ListOfTodoList(this.offsetTodo);
            await this.DisplayCalendarDate();
            console.log("edit Done");

        });

    }

    // logOut............
    async onLogoutPress() {

        // TO DO - add dynamic device token
        await this.props.logOutRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            user_id: this.props.userInfo.id,
            device_token: "123456",
            device_type: deviceType,
            "is_testdata": "1"
        })
    }

    LogoutAlert() {
        Alert.alert(
            'Alert',
            'There is login detected for this user in another device. so, please logout and login again',
            [
                {
                    text: 'Logout',
                    onPress: () => this.onLogoutPress(),
                },
            ],
        );
    }
    //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< calendar list start api >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    async GetAllCalenderList() {

        console.log(this.props, '<<<<<props GetAllCalenderList>>>>>>');

        await this.setState({ showLoader1: true })

        console.log('access_key:', this.props.encryptedToken)
        console.log('secret_key:', this.props.userDetail.data.userToken);

        this.props.allCalendarList({
            secret_key: this.props.userDetail.data.userToken,
            access_key: this.props.encryptedToken,
            device_token: "12345678",
            device_type: deviceType,
            user_id: this.props.userInfo.id,
            is_testdata: "1"
        })
    }
    // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< calendar list end api >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


    //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< list Of Todo Message List api >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    async AllListOfTodoMessageList(offsetAll) {

        console.log(this.props, '<<<<<props AllListOfTodoMessageList>>>>>>');

        await this.setState({ AllmessageTodoShowLoader: true })

        console.log('ListMessageShowLoader:', this.props.ListMessageShowLoader, "ListTodoShowLoader:", this.props.ListTodoShowLoader)

        this.props.listOfTodoMessageList({
            secret_key: this.props.userDetail.data.userToken,
            access_key: this.props.encryptedToken,
            device_token: "12345678",
            device_type: deviceType,
            user_id: this.props.userInfo.id,
            is_testdata: "1",
            offset: this.offsetAll
        })
    }
    // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< calendar list end api >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>



    // when flatelist is empty the display "NO DATA FOUND">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    loadEmptyView = () => {
        return (
            <View style={Styles.emptyListView}>
                <Text
                    // numberOfLines={1}
                    style={Styles.emptyText}>
                    No Data Found
                        </Text>
            </View>
        );
    }

    // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Message Tab Start >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    // loadMoreData = () => {
    //     // console.log(this.offset, 'loadMoreData');

    //     if (this.state.MessageList.length >= 10 && Nodata) {
    //         this.offset = this.offset + 1;
    //         setTimeout(() => { this.ListOfMessages(this.offset) }, 500)
    //     }
    // }


    async ListOfMessages(offset) {

        console.log(this.state.MessageList, '<<<<<api calling ListOfMessages>>>>>>');

        await this.setState({ ListMessageShowLoader: true })
        console.log("ListMessageShowLoader::::::::", this.state.ListMessageShowLoader, this.state.MessageList, '<<<<<api ListOfMessages 2>>>>>>');
        this.props.listOfMessage({
            secret_key: this.props.userDetail.data.userToken,
            access_key: this.props.encryptedToken,
            device_token: "12345678",
            device_type: deviceType,
            user_id: this.props.userInfo.id,
            calendar_id: this.state.SelectedCalendarID == null || this.state.SelectedCalendarID == undefined ? "1" : this.state.SelectedCalendarID,
            is_testdata: "1",
            offset: this.offset,
        })
    }

    // calendar_id: this.props.userInfo.calender_id == null || this.props.userInfo.calender_id == undefined ? "1" : this.props.userInfo.calender_id,
    // calendar_id:this.state.SelectedCalendarID,

    MessageTab = () => {
        console.log(this.state.MessageList, 'MessageList from Tab........');
        return (
            <View style={{ flex: 1 }}>
                {
                    this.state.MessageList.length > 0 ?
                        <FlatList
                            data={this.state.MessageList}
                            extraData={this.state}
                            renderItem={(item) => {
                                return (
                                    <TouchableOpacity
                                        onPress={() => {
                                            // this.props.navigation.navigate('AcceptRejectMessage', { data: item.item })
                                        }}>
                                        <View style={{ flexDirection: 'row', flex: 1 }}>
                                            <View style={Styles.messageTabView}>
                                                <Image
                                                    source={Images.MessageListIcon}
                                                    resizeMode='stretch'
                                                    style={{ marginLeft: Matrics.Scale(10), height: Matrics.Scale(25), width: Matrics.Scale(25), }} />
                                            </View>

                                            <View style={{ flex: 0.75, borderBottomWidth: 1, borderColor: Colors.TAB_BG, alignContent: 'center', }}>

                                                <View style={{ flexDirection: 'row', }}>
                                                    <View style={{ alignItems: 'center', justifyContent: 'center', }}>
                                                        <Text style={{ justifyContent: 'center', fontSize: Matrics.Scale(18) }}>
                                                            {item.item.firstname}
                                                        </Text>
                                                    </View>


                                                    <View style={{ alignItems: 'center', justifyContent: 'center', marginLeft: Matrics.Scale(5) }}>
                                                        <Text style={{ justifyContent: 'center', fontSize: Matrics.Scale(12) }}>
                                                            Created New Schedule Request
                        </Text>
                                                    </View>

                                                </View>

                                                <View style={{ flexDirection: 'row', }}>

                                                    <View style={{ alignItems: 'center', justifyContent: 'center', }}>

                                                        {item.item.is_approved == 0 &&
                                                            <Text style={{ color: 'orange' }}>
                                                                Pending
                          </Text>
                                                        }
                                                        {item.item.is_approved == 1 &&
                                                            <Text style={{ color: 'green' }}>
                                                                Accepted
                          </Text>
                                                        }
                                                        {item.item.is_approved == 2 &&
                                                            <Text style={{ color: 'red' }}>
                                                                Rejected
                          </Text>
                                                        }
                                                    </View>


                                                    <View style={{
                                                        alignItems: 'center', justifyContent: 'center', marginLeft: Matrics.Scale(5)
                                                    }}>
                                                        <Text style={{ justifyContent: 'center', fontSize: Matrics.Scale(12) }}>
                                                            By Store Owner
                        </Text>
                                                    </View>

                                                </View>

                                            </View>

                                            <View style={Styles.messageTabView2}>
                                                <Image
                                                    style={{ height: Matrics.Scale(12), width: Matrics.Scale(8) }}
                                                    source={Images.graterthen}
                                                    resizeMode='stretch' />
                                            </View>

                                        </View>
                                    </TouchableOpacity>
                                )
                            }}
                            ListEmptyComponent={() => this.loadEmptyView()}
                            // onEndReached={() => this.loadMoreData()}
                            onEndReachedThreshold={0.5}
                            showsVerticalScrollIndicator={false}
                        />
                        :
                        this.loadEmptyView()
                }
            </View>
        );
    }
    // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Message Tab End >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


    // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Todo Tab Start >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    // loadMoreDataToDo = () => {
    //     // console.log(this.offsetTodo, 'loadMoreData');
    //     // console.log(NodataToDO, 'NodataToDO');
    //     if (this.state.TodoList.length >= 0 && NodataToDO) {
    //         this.offsetTodo = this.offsetTodo + 1;
    //         setTimeout(() => { this.ListOfTodoList(this.offsetTodo) }, 500)
    //         console.log('loadMoreDataToDo');
    //     }
    // }

    async ListOfTodoList(offsetTodo) {

        console.log(this.state.TodoList, '<<<<<props ListOfMessages>>>>>>');

        await this.setState({ ListTodoShowLoader: true })
        this.props.listOfTodoList({
            secret_key: this.props.userDetail.data.userToken,
            access_key: this.props.encryptedToken,
            device_token: "12345678",
            device_type: deviceType,
            user_id: this.props.userInfo.id,
            calendar_id: this.state.SelectedCalendarID == null || this.state.SelectedCalendarID == undefined ? "1" : this.state.SelectedCalendarID,
            is_testdata: "1",
            offset: this.offsetTodo,
        })
    }
    // calendar_id: this.props.userInfo.calender_id == null || this.props.userInfo.calender_id == undefined ? "1" : this.props.userInfo.calender_id,
    // calendar_id:this.state.SelectedCalendarID,

    TodoTab() {
        console.log(this.state.TodoList, 'TodoList from Tab........');
        return (
            <View style={{ flex: 1 }}>
                {
                    this.state.TodoList.length > 0 ?
                        <FlatList
                            data={this.state.TodoList}
                            extraData={this.state}
                            renderItem={(item) => {
                                console.log(item, 'TODO item');

                                var s_date = item.item.start_date
                                var e_date = item.item.end_date

                                var StartDate = s_date.split(' ')[1]
                                let arr = StartDate.split(':')
                                let S_hour = parseInt(arr[0]);
                                let S_min = parseInt(arr[1]);
                                // console.log('::::S_hour', S_hour, '::::S_min', S_min);

                                var EndDate = e_date.split(' ')[1]
                                let arr2 = EndDate.split(':')
                                let E_hour = parseInt(arr2[0]);
                                let E_min = parseInt(arr2[1]);
                                // console.log('::::E_hour', E_hour, '::::E_min', E_min);

                                return (
                                    <TouchableOpacity
                                        onPress={() => {
                                            this.props.navigation.navigate('EditSchedule', { editPlan: true, data: item.item, PlanTab: true })
                                        }}>
                                        <View style={Styles.todoMainView}>
                                            <View style={Styles.todoView}>
                                                <Text style={{ color: 'black' }}>
                                                    {S_hour} : {S_min}
                                                </Text>
                                                <View>
                                                    <Text>
                                                        {E_hour} : {E_min}
                                                    </Text>
                                                </View>

                                            </View>

                                            <View style={Styles.todoView2}>

                                            </View>

                                            <View style={Styles.todoView3}>
                                                <Text style={{ justifyContent: 'center', fontSize: 18 }}>
                                                    {item.item.comments}
                                                </Text>
                                            </View>

                                            <View style={Styles.todoView4}>
                                                <Image
                                                    style={{ height: Matrics.Scale(12), width: Matrics.Scale(8) }}
                                                    source={Images.graterthen}
                                                    resizeMode='stretch' />

                                            </View>
                                        </View>
                                    </TouchableOpacity>
                                )
                            }}
                            ListEmptyComponent={() => this.loadEmptyView()}
                            // onEndReached={() => this.loadMoreDataToDo()}
                            onEndReachedThreshold={0.5}
                            showsVerticalScrollIndicator={false}
                        />
                        :
                        this.loadEmptyView()
                }
            </View>
        );
    }
    // <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< Todo Tab End >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    //multiple dots display in calendar.................
    async DisplayCalendarDate() {

        this.setState({ AllColorDate: {} })
        console.log(vacation, '////vacation////');
        console.log(this.state.TodoList, '////TodoList////');
        console.log(this.state.MessageList, '////MessageList////');
        let endDate = [];
        let endDate2 = [];

        console.log(endDate, 'endDate');
        let arr = {}
        let current = []
        var dots = []
        var numbersObj = {}

        // split date from state...........
        this.state.TodoList.map(item => {
            const extractedDate = item.end_date.split(' ')[0];
            endDate.push(extractedDate);
            console.log(extractedDate, '..extractedDate..');
        })
        console.log(endDate, '..endDate..');

        // dots = [vacation, vacation, vacation]
        // console.log(dots, "dots:::::::");


        // -----------------------------endDate
        const centreDetails = endDate

        
        
        
        
        endDate.map((item, index, value) => {
            console.log(item.toString(), 'todo item of endDate');
            console.log(index, 'index');
            console.log(item, 'item');
            
            // centreValues = Object.entries(centreDetails).map(value => value)
            // console.log(centreValues, 'centreValues')

            // const result = endDate.find(item => item === arr[item]);
            // console.log(result,'result..') 


            console.log(endDate.indexOf(item), 'item.toString() == index');
            if (item == item) {
                console.log(item, "..item of dots..");
                dots.push(vacation);
            }
            console.log(dots, "..dots..");
            // -----------------------------




            arr[item] = { dots }
            console.log(arr, '....arr...');
        })
        this.setState({ TodoColorDate: arr })
        console.log(this.state.TodoColorDate, '..TodoColorDate[item]..');


        // need following format.......
        // markedDates={{
        // '2019-08-17': { dots: [vacation, vacation, vacation], selected: true, selectedColor: Colors.LOGIN },
        //     '2019-08-18': { dots: [massage, workout], disabled: true }
        // }}


        // for message listOfMessage.................
        // this.state.MessageList.map(item => {
        //     const extractedDate2 = item.end_date.split(' ')[0];
        //     endDate2.push(extractedDate2);
        // })
        // let arr2 = {}
        // endDate2.map(item => {
        //     arr2[item] = { marked: true, dotColor: 'blue', activeOpacity: 0 }
        // })
        // this.setState({ MessageColorDate: arr2 })
        // console.log(this.state.MessageColorDate, 'MessageColorDate[item]');


        // for All Date..........
        await this.setState({ AllColorDate: { ...this.state.TodoColorDate, ...this.state.MessageColorDate } })

        // let demo = {
        //     '2019-08-17': { dots: [vacation, vacation, vacation] },
        //     '2019-08-19': { dots: [vacation, vacation, vacation, vacation, vacation] }
        // }
        // this.setState({ AllColorDate: demo });

        console.log(this.state.AllColorDate, 'AllColorDate');
    }

    // // display single selection on date..............
    // async DisplayCalendarDate() {
    //     this.setState({ AllColorDate: {} })
    //     console.log(this.state.TodoList, '////TodoList////');
    //     console.log(this.state.MessageList, '////MessageList////');
    //     let endDate = [];
    //     let endDate2 = [];

    //     // for todo listOfMessage.................
    //     this.state.TodoList.map(item => {
    //         const extractedDate = item.end_date.split(' ')[0];
    //         endDate.push(extractedDate);
    //     })

    //     console.log(endDate, 'endDate');
    //     let arr = {}
    //     endDate.map(item => {
    //         console.log(item.toString(), 'todo item of endDate');
    //         arr[item] = { selected: true, selectedColor: Colors.LOGIN }
    //         console.log(arr, 'TodoColorDate[item]');
    //     })
    //     this.setState({ TodoColorDate: arr })
    //     console.log(this.state.TodoColorDate, 'TodoColorDate[item]');

    //     // for message listOfMessage.................
    //     this.state.MessageList.map(item => {
    //         const extractedDate2 = item.end_date.split(' ')[0];
    //         endDate2.push(extractedDate2);
    //     })
    //     let arr2 = {}
    //     endDate2.map(item => {
    //         arr2[item] = { selected: true, selectedColor: Colors.LOGIN }
    //     })
    //     this.setState({ MessageColorDate: arr2 })
    //     console.log(this.state.MessageColorDate, 'MessageColorDate[item]');

    //     // for All Date..........
    //     await this.setState({ AllColorDate: { ...this.state.TodoColorDate, ...this.state.MessageColorDate } })
    //     console.log(this.state.AllColorDate, '..AllColorDate..');
    // }


    render() {
        return (
            <SafeAreaView style={{ flex: 1 }}>

                <View style={{ flex: 1, }}>

                    {/* calendars.................. */}
                    {/* <ScrollView style={{ flex: 0.1 }}> */}

                    <View style={{
                        // flex: 1,
                        borderBottomColor: Colors.GREYCOLOR,
                        borderWidth: 1,
                        justifyContent: 'flex-start',
                        flexDirection: 'row',
                        // backgroundColor: 'red'
                    }}>
                        <View style={{
                            borderBottomColor: Colors.GREYCOLOR,
                            justifyContent: 'center',
                            alignItems: 'center',
                            flexDirection: 'row',
                            // backgroundColor: 'yellow',
                            borderBottomColor: this.state.AllSelected ? Colors.LOGIN : 'white',
                            borderBottomWidth: 1,
                        }} >
                            <TouchableOpacity onPress={() => {
                                this.setState({ AllColorDate: {}, AllSelected: true, SelectedCalendarIndex: '' })
                                this.AllListOfTodoMessageList()
                                this.DisplayCalendarDate()
                            }}>
                                <Text style={{
                                    fontSize: Matrics.Scale(18), marginLeft: Matrics.Scale(15),
                                    marginRight: Matrics.Scale(15),
                                }}>
                                    All
                                        </Text>
                            </TouchableOpacity>
                        </View>
                        <View style={{ flex: 0.9 }}>

                            <FlatList
                                data={this.state.CalendarArrayList}
                                ItemSeparatorComponent={this.space}
                                horizontal={true}
                                extraData={this.state}
                                renderItem={(item, index) => {
                                    return (
                                        <View style={{ flexDirection: 'row' }}>

                                            <TouchableOpacity
                                                onPress={async () => {
                                                    await this.setState({
                                                        AllSelected: false,
                                                        SelectedCalendarID: item.item.id,
                                                        SelectedCalendarIndex: item.index,
                                                        SelectedCalendarTitle: item.item.title,
                                                    })
                                                    // console.log(item, '.......item........');
                                                    global.globalSelectedCalendarId = item.item.id;
                                                    global.globalSelectedCalendarTitle = item.item.title;
                                                    console.log(global.globalSelectedCalendarId, '<<<< SelectedCalendarID >>>>');
                                                    // console.log(global.globalSelectedCalendarTitle, '<<<< globalSelectedCalendarTitle >>>>');

                                                    await this.setState({ MessageList: [], TodoList: [] })

                                                    console.log("ListMessageShowLoader:", this.state.ListMessageShowLoader);
                                                    await this.ListOfTodoList(this.offsetTodo);

                                                }}>

                                                <View style={{
                                                    borderBottomColor: this.state.SelectedCalendarIndex === item.index ? Colors.LOGIN : 'white',
                                                    borderBottomWidth: 1,
                                                }}>
                                                    <Text style={Styles.AddCalendarList}>
                                                        {item.item.title}
                                                    </Text>

                                                </View>
                                            </TouchableOpacity>

                                        </View>
                                    )
                                }}
                                ListEmptyComponent={() => this.loadEmptyView()}
                            />
                        </View>

                        <TouchableOpacity
                            onPress={() => {
                                console.log(global.globalSelectedCalendarId, "global")
                                this.props.navigation.navigate('EditSchedule', { CalendarTab: true })
                            }}

                            style={{ flex: 0.1, alignItems: 'center', justifyContent: 'center' }}>
                            <Image
                                source={Images.Addicon}
                                resizeMode='stretch'
                                style={{ height: Matrics.Scale(25), width: Matrics.Scale(25) }}
                            />
                        </TouchableOpacity>
                    </View>


                    {/* </ScrollView> */}

                    <Calendar
                        theme={{
                            textSectionTitleColor: 'black',
                            selectedDayBackgroundColor: Colors.LOGIN,
                            todayTextColor: Colors.LOGIN,
                            dayTextColor: 'black',
                            textDisabledColor: 'grey',
                            dotColor: Colors.LOGIN,
                            selectedDotColor: '#ffffff',
                            arrowColor: Colors.LOGIN,
                            monthTextColor: 'black',
                            textDayFontWeight: '300',
                            textMonthFontWeight: 'bold',
                            textDayHeaderFontWeight: '300',
                            textDayFontSize: 16,
                            textMonthFontSize: 16,
                            textDayHeaderFontSize: 16
                        }}
                        style={Styles.calendar}
                        // minDate={'2019-07-10'}
                        onDayPress={(day) => {
                            console.log({ [day.dateString]: { selected: true, selectedColor: Colors.LOGIN } }, 'selected');
                        }}
                        // markedDates={this.state.AllColorDate}
                        markedDates={this.state.TodoColorDate}
                        firstDay={1}
                        // markedDates={{
                        //     '2019-08-16': { selected: true, selectedColor: Colors.LOGIN },
                        //     '2019-08-17': { marked: true },
                        //     '2019-08-18': { marked: true, dotColor: 'red', activeOpacity: 0 },
                        //     '2019-08-18': { marked: true, dotColor: 'green', activeOpacity: 0 },
                        //     '2019-08-19': { disabled: true, disableTouchEvent: true }
                        // }}

                        // markedDates={{
                        //     '2019-08-17': { dots: [vacation, vacation] },
                        //     '2019-08-18': { dots: [vacation, vacation, vacation, vacation, vacation] },
                        //     '2019-08-19': { dots: [], selected: true, selectedColor: Colors.LOGIN }
                        // }}
                        markingType={'multi-dot'}

                        hideArrows={false}
                    />

                    <View style={{ flexDirection: 'row' }}>
                        <View style={Styles.tabHeaderMainView}>
                            <TouchableOpacity
                                onPress={() => {
                                    this.setState({ messageTab: true, MessageButton: true, TodoButton: false })
                                    this.setState({ todoTab: false })
                                }}>
                                <View style={{
                                    borderBottomColor: this.state.messageTab ? Colors.LOGIN : 'white',
                                    borderBottomWidth: 1, height: Matrics.Scale(48), alignItems: 'center', justifyContent: 'center'
                                }}>
                                    <Text>
                                        {/* MESSAGE */}
                                        {language.schedule.Message}
                                    </Text>
                                </View>
                            </TouchableOpacity>
                        </View>

                        <View style={{
                            borderBottomColor: '#B6B4B6',
                            borderBottomWidth: 1, borderTopWidth: 1, flex: 1,
                        }}>
                            <TouchableOpacity
                                onPress={() => {
                                    this.setState({ messageTab: false })
                                    this.setState({ todoTab: true, MessageButton: false, TodoButton: true })

                                }}>
                                <View style={{
                                    borderBottomColor: this.state.todoTab ? Colors.LOGIN : 'white',
                                    borderBottomWidth: 1.5, height: Matrics.Scale(48), alignItems: 'center', justifyContent: 'center'
                                }}>
                                    <Text>
                                        {/* TODO/PLAN */}
                                        {language.schedule.Plan}
                                    </Text>
                                </View>
                            </TouchableOpacity>
                        </View>

                    </View>

                    {
                        this.state.messageTab &&
                        this.MessageTab()
                    }
                    {
                        this.state.todoTab &&
                        this.TodoTab()
                    }

                    {
                        this.state.MessageButton && this.state.CalendarArrayList.length > 1 ?
                            <View style={Styles.buttonView}>
                                <TouchableOpacity
                                    onPress={() => this.props.navigation.navigate('EditSchedule')}
                                    style={Styles.buttonContainer}>
                                    <Text style={Styles.buttonText}>
                                        {/* + New Message */}
                                        {language.schedule.AddMessage}
                                    </Text>
                                </TouchableOpacity>
                            </View>
                            :
                            <View></View>
                    }
                    {
                        this.state.TodoButton && this.state.CalendarArrayList.length > 1 ?
                            <View style={Styles.buttonView}>
                                <TouchableOpacity
                                    onPress={() => this.props.navigation.navigate('EditSchedule', { SelectedCalendarID: this.state.SelectedCalendarID, SelectedCalendarIndex: this.state.SelectedCalendarIndex, SelectedCalendarTitle: this.state.SelectedCalendarTitle, PlanTab: true })}
                                    style={Styles.buttonContainer}>
                                    <Text style={Styles.buttonText}>
                                        {/* + Add Plan */}
                                        {language.schedule.AddPlan}
                                    </Text>
                                </TouchableOpacity>
                            </View>
                            :
                            <View></View>
                    }
                    <LoadWheel isVisible={this.state.showLoader1 || this.state.AllmessageTodoShowLoader || this.state.ListMessageShowLoader || this.state.ListTodoShowLoader} />
                </View >
            </SafeAreaView >
        )
    }
}

const Styles = {
    messageTabView: {
        flex: 0.15,
        justifyContent: 'center',
        borderColor: Colors.TAB_BG,
        borderBottomWidth: 1,
        marginLeft: Matrics.Scale(10),
    },
    messageTabView2: {
        flex: 0.1,
        height: Matrics.Scale(60), marginRight: Matrics.Scale(10),
        alignItems: 'center', justifyContent: 'center',
        borderColor: Colors.TAB_BG, borderBottomWidth: 1
    },
    todoMainView: {
        height: Matrics.Scale(50),
        flexDirection: 'row',
        flex: 1
    },
    todoView: {
        flex: 0.2,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        borderColor: Colors.TAB_BG,
        borderBottomWidth: 1,
        marginLeft: Matrics.Scale(10)
    },
    todoView2: {
        marginRight: Matrics.Scale(10),
        marginTop: Matrics.Scale(4),
        marginBottom: Matrics.Scale(4),
        borderWidth: 1,
        borderColor: Colors.LOGIN
    },
    todoView3: {
        flex: 0.7,
        borderColor: Colors.TAB_BG,
        alignContent: 'center',
        justifyContent: 'center',
        borderBottomWidth: 1,
    },
    todoView4: {
        flex: 0.1,
        alignItems: 'center',
        justifyContent: 'center',
        borderColor: Colors.TAB_BG,
        borderBottomWidth: 1,
        marginRight: Matrics.Scale(10)
    },
    buttonContainer: {
        backgroundColor: 'white',
        height: Matrics.Scale(30),
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "center",
        borderWidth: 1.5,
        width: '60%',
        borderColor: Colors.LOGIN,
        margin: Matrics.Scale(12),
        borderRadius: Matrics.Scale(5)
    },
    AddCalendarList: {
        fontSize: Matrics.Scale(18),
        marginTop: Matrics.Scale(7),
        marginBottom: Matrics.Scale(7),
        marginLeft: Matrics.Scale(15),
        marginRight: Matrics.Scale(15),
    },
    buttonView: {
        backgroundColor: Colors.LightYellow,
        position: 'absolute',
        alignItems: 'center',
        justifyContent: "center",
        bottom: 0,
        width: '100%',
    },
    buttonText: {
        fontWeight: '600',
        fontSize: Matrics.Scale(18),
        color: Colors.LOGIN,
    },
    tabHeaderMainView: {
        borderBottomColor: '#B6B4B6',
        borderBottomWidth: 1,
        borderTopWidth: 1,
        flex: 1,
    },
    calendar: {
        borderTopWidth: 1,
        paddingBottom: 5,
        borderBottomWidth: 1,
        borderColor: '#eee',
        // height: Matrics.Scale(350),
    },
    emptyListView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    emptyText: {
        color: 'red',
        textAlign: 'center',
        fontSize: Matrics.Scale(17),
    }

}

//Props Connection
const mapStateToProps = (state) => {
    // console.log(state, 'state Schedule==================');

    return {
        calendarListDetail: state.Schedule,
        listOfMessageDetail: state.ListOfMesage,
        listOfTodoDetail: state.ListOfTodoList,
        AllTodoMessageListDetail: state.ListOfMesageAndTodoList,
        logout: state.Logout,
        userDetail: state.Auth,
        encryptedToken: state.Encrypt.data ? state.Encrypt.data.encrypted_value : undefined,
        userInfo: state.Auth.data && state.Auth.data.data ? state.Auth.data.data.User : undefined,

    };
}
//Redux Connection  
export default connect(mapStateToProps, { allCalendarList, listOfMessage, listOfTodoList, listOfTodoMessageList, logOutRequest })(Schedule);

