import React, { Component } from "react";
import { connect } from 'react-redux';
import {
    Text,
    View,
    KeyboardAvoidingView,
    SafeAreaView,
    Image,
    TextInput,
    ScrollView,
    TouchableOpacity,
    Platform,
    Alert,
    Picker,
    ImageBackground
} from "react-native";
import DateTimePicker from "react-native-modal-datetime-picker";
import { Calendar, CalendarList, Agenda } from 'react-native-calendars';
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import moment from 'moment';
import _ from 'lodash';
import { EventRegister } from 'react-native-event-listeners';
import AsyncStorage from '@react-native-community/async-storage';
//Assets
import { logOutRequest } from '@Redux/Actions/AuthActions'
import { createCalendar, deleteCalendar, copyCalendar } from '@Redux/Actions/CalendarTabActions'
import { allCalendarList } from '@Redux/Actions/ScheduleAction'
import { createMessage } from '@Redux/Actions/MessageTabActions'
import { createTodo, editTodo } from '@Redux/Actions/PlanTabActions'
import { HeaderBackButton } from '../Components'
import { Images, Colors, Matrics } from '../../src/Assets';
import { LoadWheel } from "../Components/Common/LoadWheel";
import { MASTER_ACCESS_KEY } from '../Config/Constants';
import language from '../Assets/Languages/Language'

let obj = {}
currentDate = '';
let selectedId = [];
let temparr = [];
let deviceType = Platform.OS == 'ios' ? 1 : 0;
let EditDateSelected = '';
class EditSchedule extends React.Component {

    //NAVGATION OPTIONS FOR HEADER
    static navigationOptions = ({ navigation }) => ({
        headerTitle: language.editschedule.header,
        headerTitleStyle: { flex: 1, textAlign: 'center' },
        headerLeft: <HeaderBackButton
            onBackPress={() => {
                navigation.goBack()
                console.log('goBack')
            }}
        />,
        headerRight: <View />
    })

    //INITIAL STATE DECLARATION
    constructor(props) {
        // this.onDayPress = this.onDayPress.bind(this);
        super(props);
        this.currentDate = new Date;
        this.state = {
            name: '',
            logoutFlag: true,
            showLoader: false,
            calendarListShowLoader: false,
            createCalendarShowLoader: false,
            deleteCalendarShowLoader: false,
            copyCalendarShowLoader: false,
            // editCalendarShowLoader: false,
            // shareCalendarShowLoader: false,

            CreateTodShowLoader: false,
            EditTodoShowLoader: false,
            // userId: props.userDetail && props.userDetail.data && props.userDetail.data.data && props.userDetail.data.data.User.id,
            // userCalendar_Id: props.userDetail && props.userDetail.data && props.userDetail.data.data && props.userDetail.data.data.User.calender_id,

            markedDates: {},
            editPlan: false,
            PlanTab: false,
            MessageTab: true,
            CalendarTab: false,
            choosenIndex: 0,
            onCalendar: false,
            isDateTimePickerVisible: false,
            isDateEndTimePickerVisible: false,

            isStartDatePicker: false,
            isEndDatePicker: false,
            StartDate: 'Date',
            EndDate: 'Date',
            StartTime: "Time",
            EndTime: "Time",
            editTodoId: '',

            pickerOn: false,
            PlanJobType: "Choose Calendar",
            Selected_CalendarId: global.globalSelectedCalendarId == undefined || global.globalSelectedCalendarId == "" || global.globalSelectedCalendarId == null ? "0" : global.globalSelectedCalendarId,
            isMessageStartDatePicker: false,
            isMessageEndDatePicker: false,
            MessageStartDate: 'Date',
            MessageEndDate: 'Date',
            isMessageStartTimePickerVisible: false,
            isMessageEndTimePickerVisible: false,
            MessageStartTime: "Time",
            MessageEndTime: "Time",

            Comment_messageTab: '',
            Comment_PlanTab: '',
            PlanTab_CalendarList: [],
            DisplayDate: {},
            PlanColorDate: {},
            AllColorDate: {},

            selectedStoreUserList: [],
            dateselectedList: [],
            ChooseToUser: "Choose To User",
            dateSelected: {},
            selectDays: [],

            NewCalendarName: '',
            EditCalenderName: '',
            EditCalendarTitle: '',
            EditCalendarDescription: '',

            CalendarPickerOn: false,
            isDeleteCalenderPicker: false,
            isCopyCalendarPicker: false,
            isShareCalendarPicker: false,
            jobType: "Choose Calendar",
            SelectCalendar: "Select Calendar",
            SelectCopyCalendar: "Select Calendar",
            SelectShareCalendar: "Choose user",
            SelectedCalendareId: '',
            store_id: '',
            copyFromCalendarId: global.globalSelectedCalendarId,
            copyFromCalendarTitle: global.globalSelectedCalendarTitle,
            // userCalendar_Id: global.UserData.calender_id,

            addCalendarTab: false,
            deleteCalenderTab: false,
            copyCalendarTab: false,
            editeCalendar: false,
            shareCalendar: false,

            isCalendarTitleEdit: false,
            isCalendarDesEdit: false,

        };
    }

    //------LIFE CYCLE METHODS--------->>>>
    async componentWillMount() {
        console.log(global.globalSelectedCalendarId, 'globalSelectedCalendarId');
        console.log(this.state.Selected_CalendarId, 'Selected_CalendarId');
        console.log(this.state.PlanJobType, 'PlanJobType');

        if (this.props.navigation.state.params) {
            console.log(this.props.navigation.state.params, 'this.props.navigation.state.params...')
            await this.setState({ PlanJobType: global.globalSelectedCalendarTitle == "" || global.globalSelectedCalendarTitle == undefined ? "Choose Calendar" : global.globalSelectedCalendarTitle })
            // await this.setState({ Selected_CalendarId: this.props.navigation.state.params.SelectedCalendarID })


            if (this.props.navigation.state.params.editPlan) {
                await this.setState({ editPlan: true, editTodoId: this.props.navigation.state.params.data.id })
                await this.setState({ StartTime: this.props.navigation.state.params.data.start_date, EndTime: this.props.navigation.state.params.data.end_date })
                await this.setState({ Comment_PlanTab: this.props.navigation.state.params.data.comments })
                console.log(this.state.StartTime, '<<<<<<StartTime>>>>>');
                console.log(this.state.EndTime, '<<<<<<EndTime>>>>>');
                console.log(this.state.editTodoId, '<<<<<<editTodoId>>>>>');
                console.log(this.state.Comment_PlanTab, '<<<<<<Comment_PlanTab>>>>>');
                console.log(this.state.DisplayDate, '<<<<<<DisplayDate>>>>>');
                this.setState({ DisplayDate: this.props.navigation.state.params.data.start_date })
                this.DisplayCalendarDate()
            }
            if (this.props.navigation.state.params.PlanTab) {
                await this.setState({ PlanTab: true, MessageTab: false, CalendarTab: false })
            }
            if (this.props.navigation.state.params.CalendarTab) {
                await this.setState({ PlanTab: false, MessageTab: false, CalendarTab: true })
            }

        }
        // await this.setState({ store_id: global.UserData.store_id })
        // console.log('....calender_id....', global.UserData.calender_id);

        this.GetAllCalender()
        // await this.DisplayCalendarDate()
    }

    async componentWillReceiveProps(nextProps) {

        console.log(nextProps, 'nextProps.CreateCalendar');
        console.log(nextProps.calendarListDetail, 'nextProps.calendarListDetail');
        console.log(nextProps.createTodoDetail, 'nextProps.createTodoDetail');
        console.log(nextProps.editTodoDetail, 'nextProps.editTodoDetail');
        console.log(nextProps.createMessageDetail, 'nextProps.createMessageDetail');
        console.log(nextProps.deleteCalendarDetail, 'nextProps.deleteCalendarDetail');
        console.log(nextProps.copyCalendarDetail, 'nextProps.copyCalendarDetail');

        const nextPropsData = nextProps.calendarListDetail;
        console.log(nextPropsData, 'nextPropsData');

        const nextPropsCreateTodo = nextProps.createTodoDetail;
        console.log(nextPropsCreateTodo, 'nextPropsCreateTodo');

        const nextPropsEditTodo = nextProps.editTodoDetail;
        console.log(nextPropsEditTodo, 'nextPropsEditTodo');

        const nextPropsCreateMessage = nextProps.createMessageDetail;
        console.log(nextPropsCreateMessage, 'nextPropsCreateMessage');

        const nextPropsDeleteCalendar = nextProps.deleteCalendarDetail;
        console.log(nextPropsDeleteCalendar, 'nextPropsDeleteCalendar');

        const nextPropsCopyCalendar = nextProps.copyCalendarDetail;
        console.log(nextPropsCopyCalendar, 'nextPropsCopyCalendar');

        // .....................calendar list.....................
        console.log(this.state.calendarListShowLoader, 'this.state.showLoader1');
        console.log(nextPropsData.data.status, '===================>>>>>>>>>>>>')
        if (nextPropsData.calendarListSuccess && nextPropsData.data.status == "3" && this.state.logoutFlag && this.state.calendarListShowLoader) {
            await this.setState({ logoutFlag: false, showLoader: false, EditTodoShowLoader: false, calendarListShowLoader: false, createCalendarShowLoader: false, deleteCalendarShowLoader: false, copyCalendarShowLoader: false, })
            console.log("Logout calendar list");
            this.LogoutAlert()
        }
        else if (nextPropsData.calendarListSuccess && nextPropsData.data.status == "1" && this.state.calendarListShowLoader) {
            await this.setState({ PlanTab_CalendarList: nextPropsData.data.StoreDetail, calendarListShowLoader: false });
            console.log(this.state.PlanTab_CalendarList, 'PlanTab_CalendarList');
            console.log('first if');
        }
        else if (nextPropsData.calendarListSuccess && nextPropsData.data.status == "0" && this.state.calendarListShowLoader) {
            this.setState({ calendarListShowLoader: false })
            alert(nextPropsData.data.message)
        }
        //if api doesn't get called
        else if (nextPropsData.calendarListFail) {
            this.setState({ calendarListShowLoader: false })
            alert('Something went wrong.Please try again later in calendar list.')
        }

        // .....................Logout .............................
        else if (nextProps.logout.logoutFail) {
            alert('something went wrong.Please try again')
        }
        //logout success
        else if (nextProps.logout.logoutSuccess && nextProps.logout.data.status == "1" && !this.state.logoutFlag) {
            await AsyncStorage.getAllKeys().then(AsyncStorage.multiRemove)
            await AsyncStorage.removeItem('refreshtoken')
            this.getRefreshToken()
        }


        // .....................create calendar.....................
        if (nextProps.createdCalendarDetail.calendarSuccess && nextProps.createdCalendarDetail.data.status == "1" && this.state.createCalendarShowLoader) {
            this.setState({ createCalendarShowLoader: false })
            await EventRegister.emit('reloadCalandarList', 'add calendar is working');
            this.props.navigation.navigate('Schedule')
            console.log('create calendar');
        }
        else if (nextProps.createdCalendarDetail.calendarSuccess && nextProps.createdCalendarDetail.data.status == "0" && this.state.createCalendarShowLoader) {
            this.setState({ createCalendarShowLoader: false })
            alert(nextProps.createdCalendarDetail.data.message)
        }
        else if (nextProps.createdCalendarDetail.calendarSuccess && nextProps.createdCalendarDetail.data.status == "3" && this.state.logoutFlag && this.state.createCalendarShowLoader) {
            await this.setState({ logoutFlag: false, showLoader: false, EditTodoShowLoader: false, calendarListShowLoader: false, createCalendarShowLoader: false, deleteCalendarShowLoader: false, copyCalendarShowLoader: false, })
            console.log("Logout create calendar");
            this.LogoutAlert()
        }
        //if api doesn't get called
        else if (nextProps.createdCalendarDetail.calendarFail) {
            this.setState({ createCalendarShowLoader: false })
            alert('Something went wrong.Please try again later create calendar.')
        }

        // .....................Delete calendar.....................
        console.log(this.state.deleteCalendarShowLoader, "deleteCalendarShowLoader");

        if (nextPropsDeleteCalendar.deleteSuccess && nextPropsDeleteCalendar.data.status == "1" && this.state.deleteCalendarShowLoader) {
            await EventRegister.emit('deleteCalandar', 'delete calendar is working');
            this.setState({ deleteCalendarShowLoader: false })
            this.props.navigation.navigate('Schedule')
            console.log('Delete calendar');
        }
        else if (nextPropsDeleteCalendar.deleteSuccess && nextPropsDeleteCalendar.data.status == "0" && this.state.deleteCalendarShowLoader) {
            this.setState({ deleteCalendarShowLoader: false })
            alert(nextPropsDeleteCalendar.data.message)
        }
        else if (nextPropsDeleteCalendar.deleteSuccess && nextPropsDeleteCalendar.data.status == "3" && this.state.logoutFlag && this.state.deleteCalendarShowLoader) {
            await this.setState({ logoutFlag: false, showLoader: false, EditTodoShowLoader: false, calendarListShowLoader: false, createCalendarShowLoader: false, deleteCalendarShowLoader: false, copyCalendarShowLoader: false, })
            console.log("Logout Delete calendar");
            this.LogoutAlert()
        }
        //if api doesn't get called
        else if (nextPropsDeleteCalendar.deleteFail) {
            this.setState({ deleteCalendarShowLoader: false })
            alert('Something went wrong.Please try again later Delete calendar.')
        }

        // .....................Copy calendar.....................
        console.log(this.state.copyCalendarShowLoader, "copyCalendarShowLoader");

        if (nextPropsCopyCalendar.copySuccess && nextPropsCopyCalendar.data.status == "1" && this.state.copyCalendarShowLoader) {
            this.setState({ copyCalendarShowLoader: false })
            await EventRegister.emit('CopyCalandar', 'Copy calendar is working');
            this.props.navigation.navigate('Schedule')
            console.log('Copy calendar');
        }
        else if (nextPropsCopyCalendar.copySuccess && nextPropsCopyCalendar.data.status == "0" && this.state.copyCalendarShowLoader) {
            this.setState({ copyCalendarShowLoader: false })
            alert(nextPropsCopyCalendar.data.message)
        }
        else if (nextPropsCopyCalendar.copySuccess && nextPropsCopyCalendar.data.status == "3" && this.state.logoutFlag && this.state.copyCalendarShowLoader) {
            await this.setState({ logoutFlag: false, showLoader: false, EditTodoShowLoader: false, calendarListShowLoader: false, createCalendarShowLoader: false, deleteCalendarShowLoader: false, copyCalendarShowLoader: false, })
            console.log("Logout Copy calendar");
            this.LogoutAlert()
        }
        //if api doesn't get called
        else if (nextPropsCopyCalendar.copyFail) {
            this.setState({ copyCalendarShowLoader: false })
            alert('Something went wrong.Please try again later Delete calendar.')
        }

        // .....................create todo/plan ....................
        console.log(this.state.CreateTodShowLoader, 'todo....showLoader.....');

        if (nextPropsCreateTodo.createTodoSuccess && nextPropsCreateTodo.data.status == "1" && this.state.CreateTodShowLoader) {
            await EventRegister.emit('createTodo', { offsetTodo: 0 });
            this.props.navigation.navigate('Schedule')
            console.log('crate Todo');
            this.setState({ CreateTodShowLoader: false });
            console.log("first if...");

        }
        else if (nextPropsCreateTodo.createTodoSuccess && nextPropsCreateTodo.data.status == "0" && this.state.CreateTodShowLoader) {
            this.setState({ CreateTodShowLoader: false })
            alert(nextPropsCreateTodo.data.message)
        }
        else if (nextPropsCreateTodo.createTodoSuccess && nextPropsCreateTodo.data.status == "3" && this.state.logoutFlag && this.state.CreateTodShowLoader) {
            await this.setState({ logoutFlag: false, showLoader: false, EditTodoShowLoader: false, calendarListShowLoader: false, createCalendarShowLoader: false, deleteCalendarShowLoader: false, copyCalendarShowLoader: false, })
            console.log("Logout Create todo");
            this.LogoutAlert()
        }
        //if api doesn't get called
        else if (nextPropsCreateTodo.createTodoFail) {
            this.setState({ CreateTodShowLoader: false })
            alert('Something went wrong.Please try again later create todo.')
        }


        // .....................Edit todo/plan ....................
        console.log(this.state.EditTodoShowLoader, 'edit todo....EditTodoShowLoader.....');

        if (nextPropsEditTodo.editTodoSuccess && nextPropsEditTodo.data.status == "1" && this.state.EditTodoShowLoader) {
            await EventRegister.emit('editTodo', { offsetTodo: 0 });
            this.props.navigation.navigate('Schedule')
            console.log('edit Todo');
            await this.setState({ EditTodoShowLoader: false });
            console.log("first if...");

        }
        else if (nextPropsEditTodo.editTodoSuccess && nextPropsEditTodo.data.status == "0" && this.state.EditTodoShowLoader) {
            this.setState({ EditTodoShowLoader: false })
            alert(nextPropsEditTodo.data.message)
        }
        else if (nextPropsEditTodo.editTodoSuccess && nextPropsEditTodo.data.status == "3" && this.state.logoutFlag && this.state.EditTodoShowLoader) {
            await this.setState({ logoutFlag: false, showLoader: false, EditTodoShowLoader: false, calendarListShowLoader: false, createCalendarShowLoader: false, deleteCalendarShowLoader: false, copyCalendarShowLoader: false, })
            console.log("Logout edit todo");
            this.LogoutAlert()
        }
        //if api doesn't get called
        else if (nextPropsEditTodo.editTodoFail) {
            this.setState({ EditTodoShowLoader: false })
            alert('Something went wrong.Please try again later create todo.')
        }

        // .....................create message ....................
        // console.log(this.state.showLoader, 'todo....showLoader.....');

        // if (nextPropsCreateMessage.createMessageSuccess && nextPropsCreateMessage.data.status == "1") {
        //     await EventRegister.emit('createMessage', { offset: 0 });
        //     this.props.navigation.navigate('Schedule')
        //     this.setState({ showLoader: false });
        // }
        // else if (nextPropsCreateMessage.createMessageSuccess && nextPropsCreateMessage.data.status == "0") {
        //     this.setState({ showLoader: false })
        //     alert(nextPropsCreateMessage.data.message)
        // }
        // //if api doesn't get called
        // else if (nextProps.nextPropsCreateMessage.creataMessageFail) {
        //     this.setState({ showLoader: false })
        //     alert('Something went wrong.Please try again later.')
        // }
    }



    //------FUNCTIONS DECLARATION--------->>>>
    showDateTimePicker = () => {
        this.setState({ isDateTimePickerVisible: true });
    };
    showEndDateTimePicker = () => {
        this.setState({ isDateEndTimePickerVisible: true });
    };
    // ---------------------------message start
    showMessageDateTimePicker = () => {
        this.setState({ isMessageStartTimePickerVisible: true });
    };
    showMessageEndDateTimePicker = () => {
        this.setState({ isMessageEndTimePickerVisible: true });
    };
    handleMessageStartTimePicked = async (date) => {
        await this.setState({ MessageStartTime: date.toString() })
        console.log("A date has been picked: ", date);

        this.hideDateTimePicker();
    };
    handleMessageEndTimePicked = async (date) => {
        await this.setState({ MessageEndTime: date.toString() })
        console.log("A date has been picked.....: ", date);
        this.hideDateTimePicker();
    };

    showMessageStartDatePicker = () => {
        this.setState({ isMessageStartDatePicker: true });
    };

    showMessageEndDatePicker = () => {
        this.setState({ isMessageEndDatePicker: true });
    };
    handleMessageDatePicked = async (date) => {
        await this.setState({ MessageStartDate: date.toString() })
        console.log("A date has been picked: ", date);
        this.hideDateTimePicker();
    };
    handleMessageEndDatePicked = async (date) => {
        await this.setState({ MessageStartDate: date.toString() })
        // await this.setState({ MessageEndDate: date.toString() })
        console.log("A date has been pickevsvdfsvbdfsbvdfvdf: ", date);
        this.hideDateTimePicker();
    };
    // --------------------------- message end

    showStartDatePicker = () => {
        this.setState({ isStartDatePicker: true });
    };

    showEndDatePicker = () => {
        this.setState({ isEndDatePicker: true });
    };

    hideDateTimePicker = () => {
        this.setState({
            isDateTimePickerVisible: false, isDateEndTimePickerVisible: false,
            isStartDatePicker: false, isEndDatePicker: false,

            isMessageStartDatePicker: false, isMessageEndDatePicker: false,
            isMessageStartTimePickerVisible: false, isMessageEndTimePickerVisible: false
        });
    };

    handleDatePicked = async (date) => {
        await this.setState({ StartDate: date.toString() })
        console.log("A date has been picked: ", date);
        this.hideDateTimePicker();
    };
    handleEndDatePicked = async (date) => {
        await this.setState({ EndDate: date.toString() })
        console.log("A date has been pickevsvdfsvbdfsbvdfvdf: ", date);
        this.hideDateTimePicker();
    };
    handleTimePicked = async (date) => {
        await this.setState({ StartTime: date.toString() })
        console.log("A time has been picked: ", date);
        this.hideDateTimePicker();
    };

    handleEndTimePicked = async (date) => {
        await this.setState({ EndTime: date.toString() })
        console.log("A time has been picked......", date);
        this.hideDateTimePicker();
    };


    // from schedule screen date selected that date display in calendar in plan tab...........
    async DisplayCalendarDate() {
        console.log(this.state.DisplayDate, '////DisplayDate////');
        let endDate = [];
        let arr = {};

        let extractedDate = this.state.DisplayDate.split(' ')[0];
        // obj = extractedDate + { selected: true, selectedColor: Colors.LOGIN }
        endDate.push(extractedDate);
        // console.log(endDate, '<<<endDate>>>');

        endDate.map(item => {
            arr[item] = { selected: true, selectedColor: Colors.LOGIN }
            console.log(arr, '_______arr');
        })

        await this.setState({ dateSelected: arr })
        console.log(this.state.dateSelected, '.....dateSelected.....');
    }

    // .......................................... plan Tab Start..............................

    dateTimeSelected() {
        let obj;
        let datearr = this.state.dateSelected
        console.log(this.state.StartTime, 'this.state.StartTime.....');

        for (let k in datearr) {
            obj = { "start_date": k + ' ' + moment(this.state.StartTime).format('HH:mm'), "end_date": k + ' ' + moment(this.state.EndTime).format('HH:mm') }
            temparr.push(obj);
            console.log(temparr, '..temparr..');
        }
    }

    // create todo api....................
    CreateTodoListForStore() {
        temparr = [];
        var curDate = new Date();
        this.dateTimeSelected()
        console.log(this.state.Comment_PlanTab, 'this.state.Comment_PlanTab');

        if (this.state.Selected_CalendarId == '' || this.state.Selected_CalendarId == 0) {
            alert('Please Choose Calendar')
        }
        else if (this.state.StartTime == 'Time') {
            alert('Please select Start Time')
        }
        // else if (this.state.EndDate == 'Date') {
        //     alert('Please select End Date')
        // }
        else if (this.state.EndTime == 'Time' || this.state.EndTime == '') {
            alert('Please select End Time')
        }
        else if (this.state.StartTime == this.state.EndTime) {
            alert('Please select different Time')
        }
        else if (this.state.StartTime > this.state.EndTime) {
            this.setState({ EndTime: 'Time' })
            alert('Please select End Time Grater then Start Time')
        }
        // else if (this.state.selectedStoreUserList == '') {
        //     alert('Please select User')
        // }
        else if (temparr.length <= 0 || temparr == []) {
            alert('Please select Date from Calendar')
        }
        else if (this.state.Comment_PlanTab == '') {
            alert('Please enter Comment')
        }

        else {
            console.log(this.props, '<<<<<props ListOfMessages>>>>>>');
            console.log('access_key:', this.props.encryptedToken)
            console.log('secret_key:', this.props.userDetail.data.userToken);
            console.log('userInfo:', this.props.userInfo);

            this.setState({ CreateTodShowLoader: true })
            this.props.createTodo({
                secret_key: this.props.userDetail.data.userToken,
                access_key: this.props.encryptedToken,
                device_token: "12345678",
                device_type: deviceType,
                user_id: this.props.userInfo.id,
                dates: temparr,
                title: "task todo list",
                comments: this.state.Comment_PlanTab,
                calendar_id: this.state.Selected_CalendarId,
                is_testdata: "1"
            })

        }
    }

    // Edit Todo/Plan......................
    EditTodo() {
        temparr = [];
        // var curDate = new Date();
        this.dateTimeSelected()
        console.log(this.state.editTodoId, '===editTodoId===');
        console.log(this.state.Comment_PlanTab, '===Comment_PlanTab===');

        if (this.state.Selected_CalendarId == '' || this.state.Selected_CalendarId == 0) {
            alert('Please Choose Calendar')
        }
        else if (this.state.StartTime == 'Time') {
            alert('Please select Start Time')
        }
        else if (this.state.EndTime == 'Time' || this.state.EndTime == '') {
            alert('Please select End Time')
        }
        else if (this.state.StartTime == this.state.EndTime) {
            alert('Please select different Time')
        }
        else if (this.state.StartTime > this.state.EndTime) {
            this.setState({ EndTime: 'Time' })
            alert('Please select End Time Grater then Start Time')
        }
        else if (temparr.length <= 0 || temparr == []) {
            alert('Please select Date from Calendar')
        }
        else if (this.state.Comment_PlanTab == "") {
            alert('Please enter Comment')
        }
        else {
            console.log(this.props, '<<<<<props ListOfMessages>>>>>>');
            console.log('access_key:', this.props.encryptedToken)
            console.log('secret_key:', this.props.userDetail.data.userToken);
            console.log('userInfo:', this.props.userInfo);

            this.setState({ EditTodoShowLoader: true })
            this.props.editTodo({
                secret_key: this.props.userDetail.data.userToken,
                access_key: this.props.encryptedToken,
                device_token: "12345678",
                device_type: deviceType,
                user_id: this.props.userInfo.id,
                TodoList_id: this.state.editTodoId,
                dates: temparr,
                title: "Edit todo list",
                comments: this.state.Comment_PlanTab,
                calendar_id: this.state.Selected_CalendarId,
                is_testdata: "1"
            })
        }
    }
    // -----------------------------------------


    //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< calendar list start api >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    async GetAllCalender() {

        console.log(this.props, '<<<<<props GetAllCalenderList>>>>>>');

        await this.setState({ calendarListShowLoader: true })

        console.log('access_key:', this.props.encryptedToken)
        console.log('secret_key:', this.props.userDetail.data.userToken);

        this.props.allCalendarList({
            secret_key: this.props.userDetail.data.userToken,
            access_key: this.props.encryptedToken,
            device_token: "12345678",
            device_type: deviceType,
            user_id: this.props.userInfo.id,
            is_testdata: "1"
        })
    }

    PlanTab() {
        // console.log(this.state.markedDates, 'markedDates');

        return (
            <View style={{ flex: 1, margin: Matrics.Scale(7) }}>

                <ScrollView style={{ flex: 1 }}>

                    {/* ================================= 1 =================================== */}
                    <View style={Styles.planMainView}>
                        <TouchableOpacity
                            onPress={() => {
                                if (!this.state.pickerOn) {
                                    this.setState({ pickerOn: true })

                                } else {
                                    this.setState({ pickerOn: false })
                                }
                            }}
                            style={{ height: Matrics.Scale(50), justifyContent: 'center' }}>

                            <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
                                <View style={{ flex: 0.9, }}>
                                    <Text style={Styles.tabText}>
                                        {this.state.PlanJobType}
                                        {/* {this.props.navigation.state.params.SelectedCalendarTitle} */}
                                    </Text>
                                </View>

                                <View style={{ flex: 0.1, alignItems: 'center' }}>
                                    <Image
                                        style={{ height: Matrics.Scale(5), width: Matrics.Scale(10) }}
                                        source={Images.DowonArrow}
                                        resizeMode='stretch' />
                                </View>
                            </View>

                        </TouchableOpacity>
                    </View>
                    {
                        this.state.pickerOn &&
                        <Picker
                            style={{ width: '100%', }}
                            itemStyle={{
                                borderWidth: 1,
                                height: Matrics.Scale(120),
                                width: '100%', borderColor: 'gray'
                            }}
                            value={this.state.PlanJobType}
                            selectedValue={this.state.PlanJobType}

                            onValueChange={async (item) => {
                                console.log(item, 'Plan tab item.......');
                                console.log(item.id, 'Plan tab item.id.......');

                                if (item.id != 0 && item.id != null) {
                                    // selectedId = [item.id]
                                    await this.setState({ Selected_CalendarId: item.id })
                                    // console.log(selectedId, '....selectedId......');
                                    console.log(this.state.Selected_CalendarId, '....Selected_CalendarId......');
                                } else {
                                    alert('Please choose calendar')
                                }
                                this.setState({ PlanJobType: item.title, choosenIndex: item.Position, pickerOn: false })

                            }}>

                            <Picker.Item label={'Choose Calendar'} value={'Choose Calendar'} />
                            {this.state.PlanTab_CalendarList.map(item => {
                                console.log(this.state.PlanTab_CalendarList, '<<<<<.state.PlanTab_CalendarList>>>>>');
                                // console.log(item, '.....item:::::::');
                                console.log(item.title, '.....title');

                                return <Picker.Item label={item.title} value={item} />
                            })
                            }

                        </Picker>
                    }

                    {/* ================================= 2 =================================== */}
                    <View style={Styles.plantabView2}>
                        <Text style={Styles.tabText}>
                            Cafe Part Time Job
                </Text>
                    </View>

                    {/* ================================== 3 ================================== */}
                    <View style={Styles.plantabView3}>
                        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
                            <View style={{ flex: 0.5, }}>
                                <Text style={Styles.tabText}>
                                    Start Time
                                </Text>
                            </View>

                            {/* <View style={{ flex: 0.3, alignItems: 'center' }}>
                                <TouchableOpacity
                                    onPress={this.showStartDatePicker}
                                >
                                    <Text style={{ alignItems: 'center' }}>
                                        {moment(this.state.StartDate).format('YYYY/MM/DD') == 'Invalid date' || undefined ? 'Date' : moment(this.state.StartDate).format('YYYY/MM/DD')}

                                    </Text>

                                    <DateTimePicker
                                        style={{
                                            height: Matrics.Scale(200)
                                        }}
                                        // is24Hour={true}
                                        mode='date'
                                        isVisible={this.state.isStartDatePicker}
                                        onConfirm={this.handleDatePicked}
                                        // titleIOS='Time'
                                        onCancel={this.hideDateTimePicker}
                                    />
                                </TouchableOpacity>
                            </View> */}

                            <View style={{ flex: 0.5, alignItems: 'center', }}>
                                <TouchableOpacity
                                    onPress={this.showDateTimePicker}
                                >
                                    <Text style={{ alignItems: 'center' }}>
                                        {/* {this.state.StartTime} */}

                                        {moment(this.state.StartTime).format('HH:mm') == 'Invalid date' || undefined ? 'Time' : moment(this.state.StartTime).format('HH:mm')}

                                        {/* 24:24 */}
                                    </Text>

                                    <DateTimePicker
                                        style={{
                                            height: Matrics.Scale(200)
                                        }}
                                        is24Hour={true}
                                        mode='time'
                                        isVisible={this.state.isDateTimePickerVisible}
                                        onConfirm={this.handleTimePicked}
                                        titleIOS='Select Time'
                                        onCancel={this.hideDateTimePicker}
                                    />

                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>

                    {/* ==================================== 4 ================================ */}
                    <View style={Styles.plantabView4}>
                        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
                            <View style={{ flex: 0.5, }}>
                                <Text style={Styles.tabText}>
                                    End Time
                                </Text>
                            </View>

                            {/* <View style={{ flex: 0.3, alignItems: 'center' }}>
                                <TouchableOpacity
                                    onPress={this.showEndDatePicker}
                                >
                                    <Text style={{ alignItems: 'center' }}>
                                        {moment(this.state.EndDate).format('YYYY/MM/DD') == 'Invalid date' || undefined ? 'Date' : moment(this.state.EndDate).format('YYYY/MM/DD')}

                                    </Text>

                                    <DateTimePicker
                                        style={{
                                            height: Matrics.Scale(200)
                                        }}
                                        // is24Hour={true}
                                        mode='date'
                                        isVisible={this.state.isEndDatePicker}
                                        onConfirm={this.handleEndDatePicked}
                                        titleIOS='Time'
                                        onCancel={this.hideDateTimePicker}
                                    />
                                </TouchableOpacity>
                            </View> */}

                            <View style={{ flex: 0.5, alignItems: 'center', }}>
                                <TouchableOpacity
                                    onPress={this.showEndDateTimePicker}
                                >
                                    <Text style={{ alignItems: 'center' }}>
                                        {/* {this.state.EndTime} */}

                                        {moment(this.state.EndTime).format('HH:mm') == 'Invalid date' || undefined ? 'Time' : moment(this.state.EndTime).format('HH:mm')}


                                    </Text>

                                    <DateTimePicker
                                        style={{
                                            height: Matrics.Scale(200)
                                        }}
                                        is24Hour={true}
                                        mode='time'
                                        isVisible={this.state.isDateEndTimePickerVisible}
                                        onConfirm={this.handleEndTimePicked}
                                        titleIOS='Select Time'
                                        onCancel={this.hideDateTimePicker}
                                    />

                                </TouchableOpacity>
                            </View>

                        </View>
                    </View>

                    {/* ===================================== 5 ============================== */}
                    <View style={Styles.plantabView5}>
                        <TouchableOpacity
                            onPress={() => {
                                // this.setState({ onCalendar: true })
                                if (!this.state.onCalendar) {
                                    this.setState({ onCalendar: true })
                                    // this.PlanTabCalendar()
                                } else {
                                    this.setState({ onCalendar: false })
                                }
                            }}

                            style={{ height: Matrics.Scale(50), justifyContent: 'center' }}>

                            <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
                                <View style={{ flex: 0.9, }}>
                                    <Text style={Styles.tabText}>
                                        Multiple Choice
                            </Text>
                                </View>

                                <View style={{ flex: 0.1, alignItems: 'center' }}>
                                    <Image
                                        style={{ height: Matrics.Scale(5), width: Matrics.Scale(10) }}
                                        source={Images.DowonArrow}
                                        resizeMode='stretch' />
                                </View>
                            </View>

                        </TouchableOpacity>
                    </View>

                    {
                        this.state.onCalendar &&
                        <Calendar
                            theme={{
                                // textSectionTitleColor: 'black',
                                selectedDayBackgroundColor: Colors.LOGIN,
                                todayTextColor: Colors.LOGIN,
                                // dayTextColor: 'black',
                                // textDisabledColor: 'grey',
                                dotColor: Colors.LOGIN,
                                // selectedDotColor: '#ffffff',
                                arrowColor: Colors.LOGIN,
                                monthTextColor: 'black',
                                // textDayFontWeight: '300',
                                textMonthFontWeight: 'bold',
                                // textDayHeaderFontWeight: '300',
                                // textDayFontSize: 16,
                                // textMonthFontSize: 16,
                                // textDayHeaderFontSize: 16
                            }}
                            style={{ borderColor: 'gray', borderWidth: 1 }}
                            onDayPress={async (day, prop) => {

                                if (this.state.editPlan) {
                                    // edit todo========================================================
                                    EditDateSelected = { [day.dateString]: { selected: true, selectedColor: Colors.LOGIN } }
                                    await this.setState({ dateSelected: EditDateSelected })
                                    console.log(this.state.dateSelected, 'edit this.state.dateSelected');
                                } else {
                                    // create todo ============================================================
                                    var myJSON = this.state.dateSelected
                                    var arr = this.state.dateSelected

                                    console.log(arr, "arr=>>>>>")
                                    let temp = {}
                                    console.log(myJSON, 'myJSON');
                                    console.log(day.dateString, 'day.dateString');
                                    console.log(day, 'day');

                                    if (_.isEmpty(myJSON) != true) {
                                        for (let k in myJSON) {
                                            if (k === Object.keys(temp).toString()) {
                                                console.log(k === Object.keys(temp).toString(), 'k === Object.keys(temp)')

                                                var allowed = [day.dateString];
                                                // console.log(allowed, 'allowed');

                                                var filtered = Object.keys(arr)
                                                    .filter(k => !allowed.includes(k))
                                                    .reduce((obj, k) => {
                                                        obj[k] = arr[k];
                                                        return obj;
                                                    }, {});

                                                // console.log(filtered, 'filtered.....');
                                                this.setState({ dateSelected: filtered })
                                                console.log(this.state.dateSelected, '::::dateSelected.....');

                                            } else {
                                                arr[day.dateString] = { selected: true, selectedColor: Colors.LOGIN }
                                                await this.setState({ dateSelected: Object.assign({}, arr) })
                                                console.log(this.state.dateSelected, '...dateSelected...');
                                                temp[day.dateString] = { selected: true, selectedColor: Colors.LOGIN }
                                            }

                                        }
                                    } else {
                                        arr[day.dateString] = { selected: true, selectedColor: Colors.LOGIN }
                                        await this.setState({ dateSelected: Object.assign({}, arr) })
                                        console.log(this.state.dateSelected, '...dateSelected...');
                                        temp[day.dateString] = { selected: true, selectedColor: Colors.LOGIN }
                                    }
                                    // ==============================================================

                                }


                            }}
                            markedDates={this.state.dateSelected}
                            // markedDates={this.state.AllColorDate}
                            firstDay={1}

                            // e.g.:
                            // markedDates={{
                            //     '2019-07-16': { selected: true, selectedColor: 'blue' },
                            //     '2019-07-17': { marked: true },
                            //     '2019-07-18': { marked: true, dotColor: 'red', activeOpacity: 0 },
                            //     '2019-07-19': { disabled: true, disableTouchEvent: true }
                            // }}
                            current={new Date()}
                            minDate={new Date()}
                        />
                    }

                    {/* ==================================== 6 ================================ */}
                    <View style={Styles.plantabView2}>
                        <TextInput
                            style={Styles.tabText}
                            value={this.state.Comment_PlanTab}
                            placeholderTextColor={"#ccc"}
                            onChangeText={text => this.setState({ Comment_PlanTab: text })}
                            placeholder={"Comment"}
                        />
                    </View>

                    {/* ==================================== Button ================================ */}
                    <View style={{ alignItems: 'center' }}>
                        {/* {
                            this.state.pickerOn &&
                            <TouchableOpacity
                                onPress={() => {
                                    this.setState({ pickerOn: false })
                                }}
                                style={Styles.buttonContainer}>
                                <Text
                                    style={{
                                        fontSize: Matrics.Scale(20),
                                        color: Colors.LOGIN,
                                    }}>Enter</Text>
                            </TouchableOpacity>
                        } */}


                        {/* {
                            this.state.pickerOn && */}
                        {
                            this.state.editPlan ?
                                <TouchableOpacity
                                    onPress={() => {
                                        // editPlan
                                        this.EditTodo()
                                        // this.setState({ pickerOn: false })
                                        // this.setState({ onCalendar: false })
                                    }}
                                    style={Styles.buttonContainer}>
                                    <Text
                                        style={{
                                            fontSize: Matrics.Scale(20),
                                            color: Colors.LOGIN,
                                        }}>EDIT</Text>
                                </TouchableOpacity>
                                :
                                <TouchableOpacity
                                    onPress={() => {
                                        // editPlan
                                        this.CreateTodoListForStore()
                                        // this.setState({ pickerOn: false })
                                        // this.setState({ onCalendar: false })
                                    }}
                                    style={Styles.buttonContainer}>
                                    <Text
                                        style={{
                                            fontSize: Matrics.Scale(20),
                                            color: Colors.LOGIN,
                                        }}>
                                        {/* SAVE */}
                                        {language.editschedule.Save}
                                    </Text>
                                </TouchableOpacity>
                        }
                    </View>

                    {/* ==================================================================== */}

                </ScrollView>
            </View>
        );
    }
    // .......................................... plan Tab End..............................

    // .......................................... Message Tab Start..............................
    // api....................
    async CreateMessageForStore() {
        // console.log(global.AllUserList, 'edit Screen global.AllUserList');

        await this.setState({ selectedStoreUserList: global.AllUserList, })
        // console.log(this.state.selectedStoreUserList.length, 'selectedStoreUserList.length');

        // this.setState({ ChooseToUser: this.state.selectedStoreUserList.length + " User Selected" })

        if (this.state.MessageStartDate == 'Date') {
            alert('Please select Start Date')
        } else if (this.state.MessageStartTime == 'Time') {
            alert('Please select Start Time')
        }
        // else if (this.state.MessageEndDate == 'Date') {
        //     alert('Please select End Date')
        // } 
        else if (this.state.MessageEndTime == 'Time' || this.state.MessageEndTime == '') {
            alert('Please select End Time')
        } else if (this.state.MessageStartTime == this.state.MessageEndTime) {
            alert('Please select different Time')
        } else if (this.state.MessageStartTime > this.state.MessageEndTime) {
            this.setState({ MessageEndTime: 'Time' })
            alert('Please select End Time Grater then Start Time')
        }
        // else if (this.state.MessageStartDate != this.state.MessageEndDate) {
        //     alert('Please select same Date')
        // } 
        // else if (global.AllUserList == [] || global.AllUserList == undefined) {
        //     alert('Please select user....')
        // }
        // else if (this.state.ChooseToUser == "Choose To User") {
        //     alert('Please select user from Choose to User column')
        // }
        // else if (this.state.selectedStoreUserList == '') {
        // alert('Please select user')
        // }
        else if (this.state.Comment_messageTab == '') {
            alert('Please enter Comment')
        } else {
            // ------------------------
            console.log(this.props, '<<<<<props createMessage>>>>>>');
            console.log('access_key:', this.props.encryptedToken)
            console.log('secret_key:', this.props.userDetail.data.userToken);
            console.log('userInfo:', this.props.userInfo);

            this.setState({ showLoader: true })
            this.props.createMessage({
                secret_key: this.props.userDetail.data.userToken,
                access_key: this.props.encryptedToken,
                device_token: "12345678",
                device_type: deviceType,
                self_user_id: this.props.userInfo.id,
                start_date: moment(this.state.MessageStartDate).format('YYYY-MM-DD') + ' ' + moment(this.state.MessageStartTime).format('HH:mm'),
                end_date: moment(this.state.MessageStartDate).format('YYYY-MM-DD') + ' ' + moment(this.state.MessageEndTime).format('HH:mm'),
                user_ids: ["1"],
                title: "message",
                comments: this.state.Comment_messageTab,
                calendar_id: "3",
                is_testdata: "1"
            })
            // user_ids: global.AllUserList,

            // APICaller(endPoint, 'post', body).then(async (json) => {
            //     console.log(json, 'CreateMessageForStore json response');

            //     if (json.status == 1) {
            //         alert(json.message);

            //         await EventRegister.emit('createMessage', { offset: 0 });

            //         this.props.navigation.navigate('Schedule')
            //         this.setState({ showLoader: false });

        }
    }

    MessageTab() {
        return (
            <View style={{ flex: 1, margin: Matrics.Scale(7) }}>
                <KeyboardAwareScrollView style={{ flex: 1 }}>
                    {/* ================================== 1 ================================== */}
                    {/* <View                       
                        style={Styles.tabLayoutView}>
                        <View style={{
                            height: Matrics.Scale(50),
                            justifyContent: 'center'
                        }}>

                            <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
                                <View style={{ flex: 0.9, }}>
                                    <Text style={Styles.tabText}>
                                        Want To change Part Time Job
                        </Text>
                                </View>


                            </View>

                        </View>
                    </View> */}

                    {/* ================================== 2 ================================== */}
                    <View style={Styles.newTabLayoutView}>
                        <Text style={Styles.tabText}>
                            Change Request
                        </Text>
                    </View>

                    {/* ================================== 3 ================================== */}
                    <View style={Styles.plantabView3}>
                        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
                            <View style={{ flex: 0.5, }}>
                                <Text style={Styles.tabText}>
                                    Start
                                </Text>
                            </View>

                            <View style={{ flex: 0.3, alignItems: 'center' }}>
                                <TouchableOpacity
                                    onPress={this.showMessageStartDatePicker}
                                >
                                    <Text style={{ alignItems: 'center' }}>
                                        {/* {moment(this.state.MessageStartDate).format('YYYY/MM/DD') } */}
                                        {moment(this.state.MessageStartDate).format('YYYY-MM-DD') == 'Invalid date' || undefined ? 'Date' : moment(this.state.MessageStartDate).format('YYYY-MM-DD')}

                                        {/* 2019/12/07 */}
                                    </Text>

                                    <DateTimePicker
                                        style={{
                                            height: Matrics.Scale(200)
                                        }}
                                        // is24Hour={true}
                                        mode='date'
                                        isVisible={this.state.isMessageStartDatePicker}
                                        onConfirm={this.handleMessageDatePicked}
                                        // titleIOS='Time'
                                        onCancel={this.hideDateTimePicker}
                                    />
                                </TouchableOpacity>
                            </View>

                            <View style={{ flex: 0.2, alignItems: 'center', }}>
                                <TouchableOpacity
                                    onPress={this.showMessageDateTimePicker}
                                >
                                    <Text style={{ alignItems: 'center' }}>
                                        {/* {this.state.MessageStartTime} */}
                                        {/* {moment(this.state.MessageStartTime).format('HH:MM')} */}

                                        {/* {moment(this.state.MessageStartTime).format('h:mm') == 'Invalid date' || undefined ? 'Time' : moment(this.state.MessageStartTime).format('h:mm')} */}
                                        {moment(this.state.MessageStartTime).format('HH:mm') == 'Invalid date' || undefined ? 'Time' : moment(this.state.MessageStartTime).format('HH:mm')}

                                    </Text>

                                    <DateTimePicker
                                        style={{
                                            height: Matrics.Scale(200)
                                        }}
                                        mode='time'
                                        is24Hour={true}
                                        isVisible={this.state.isMessageStartTimePickerVisible}
                                        onConfirm={this.handleMessageStartTimePicked}
                                        titleIOS='Select Time'
                                        onCancel={this.hideDateTimePicker}
                                    />

                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>

                    {/* ==================================== 4 ================================ */}
                    {/* <View style={Styles.newTabLayoutView}> */}
                    <View style={Styles.messageTabView4}>
                        <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
                            <View style={{ flex: 0.5, }}>
                                <Text style={Styles.tabText}>
                                    End
                                </Text>
                            </View>

                            <View style={{ flex: 0.3, alignItems: 'center' }}>
                                <TouchableOpacity
                                    onPress={this.showMessageEndDatePicker}
                                >
                                    <Text style={{ alignItems: 'center' }}>
                                        {/* {this.state.MessageEndDate} */}
                                        {/* {moment(this.state.MessageEndDate).format('YYYY/MM/DD')} */}

                                        {/* {moment(this.state.MessageEndDate).format('YYYY-MM-DD') == 'Invalid date' || undefined ? 'Date' : moment(this.state.MessageEndDate).format('YYYY-MM-DD')} */}
                                        {moment(this.state.MessageStartDate).format('YYYY-MM-DD') == 'Invalid date' || undefined ? 'Date' : moment(this.state.MessageStartDate).format('YYYY-MM-DD')}

                                        {/* 2019/12/07 */}
                                    </Text>

                                    <DateTimePicker
                                        style={{ height: Matrics.Scale(200) }}
                                        is24Hour={true}
                                        mode='date'
                                        isVisible={this.state.isMessageEndDatePicker}
                                        onConfirm={this.handleMessageEndDatePicked}
                                        titleIOS='Time'
                                        onCancel={this.hideDateTimePicker}
                                    />
                                </TouchableOpacity>
                            </View>

                            <View style={{ flex: 0.2, alignItems: 'center', }}>
                                <TouchableOpacity
                                    onPress={this.showMessageEndDateTimePicker}>

                                    <Text style={{ alignItems: 'center' }}>
                                        {/* {this.state.MessageEndTime} */}
                                        {/* {moment(this.state.MessageEndTime).format('HH:MM')} */}

                                        {/* {moment(this.state.MessageEndTime).format('hh:mm') == 'Invalid date' || undefined ? 'Time' : moment(this.state.MessageEndTime).format('h:mm')} */}
                                        {moment(this.state.MessageEndTime).format('HH:mm') == 'Invalid date' || undefined ? 'Time' : moment(this.state.MessageEndTime).format('HH:mm')}

                                    </Text>

                                    <DateTimePicker
                                        style={{ height: Matrics.Scale(200) }}
                                        mode='time'
                                        is24Hour={true}
                                        isVisible={this.state.isMessageEndTimePickerVisible}
                                        onConfirm={this.handleMessageEndTimePicked}
                                        titleIOS='Select Time'
                                        onCancel={this.hideDateTimePicker}
                                    />

                                </TouchableOpacity>
                            </View>
                        </View>
                    </View>

                    {/* ==================================== 5 ================================ */}
                    <View style={Styles.newTabLayoutView}>
                        <TouchableOpacity
                            onPress={() =>
                                this.props.navigation.navigate('ChooseToUser')
                            }
                            style={{
                                height: Matrics.Scale(50),
                                justifyContent: 'center'
                            }}>

                            <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
                                <View style={{ flex: 0.9, }}>
                                    <Text style={Styles.tabText}>
                                        {this.state.ChooseToUser}

                                    </Text>
                                </View>

                                <View style={{ flex: 0.1, alignItems: 'center' }}>
                                    <Image
                                        style={{
                                            height: Matrics.Scale(12),
                                            width: Matrics.Scale(8)
                                        }}
                                        source={Images.graterthen}
                                        resizeMode='stretch' />
                                </View>
                            </View>

                        </TouchableOpacity>
                    </View>


                    {/* ==================================== 6 ================================ */}
                    <View style={Styles.newTabLayoutView}>
                        <TextInput
                            style={Styles.tabText}
                            value={this.state.Comment_messageTab}
                            placeholderTextColor={"#ccc"}
                            onChangeText={text => this.setState({ Comment_messageTab: text })}
                            placeholder={"Comment"}
                        />
                    </View>

                    {/* ==================================== Save Button ================================ */}
                    <View style={{ alignItems: 'center' }}>

                        <TouchableOpacity
                            onPress={() => {
                                // if (this.state.ChooseToUser < 0) {
                                //     this.setState({ ChooseToUser: this.state.selectedStoreUserList.length + " User Selected" })
                                //     console.log(this.state.ChooseToUser, 'ChooseToUser::::');

                                // }
                                this.CreateMessageForStore()
                            }
                            }
                            style={Styles.buttonContainer}>
                            <Text
                                style={{ fontSize: Matrics.Scale(20), color: Colors.LOGIN, }}>
                                {/* SAVE */}
                                {language.editschedule.Save}
                            </Text>
                        </TouchableOpacity>
                    </View>

                </KeyboardAwareScrollView>
            </View>

        );
    }
    // .......................................... Message Tab End..............................


    // .......................................... Calendar Tab Start..............................
    //  1.)  api careate calendar.....................

    async createCalendar() {
        console.log(this.props, '<<<<<props create calendar>>>>>>');
        console.log('access_key:', this.props.encryptedToken)
        console.log('secret_key:', this.props.userDetail.data.userToken);
        console.log('userInfo:', this.props.userInfo);
        this.setState({ createCalendarShowLoader: true })

        this.props.createCalendar({
            secret_key: this.props.userDetail.data.userToken,
            access_key: this.props.encryptedToken,
            device_token: "12345678",
            device_type: deviceType,
            user_id: this.props.userInfo.id,
            name: this.state.NewCalendarName,
            description: "test calendar",
            is_testdata: "1",
        })
    }

    //  2.)  api Delete .....................
    DeleteCalender() {
        if (this.state.SelectCalendar == {} ||
            this.state.SelectCalendar == undefined ||
            this.state.SelectCalendar == 'Select Calendar') {
            alert('Please Select Calendar')
        } else {
            this.setState({ deleteCalendarShowLoader: true });
            this.props.deleteCalendar({
                secret_key: this.props.userDetail.data.userToken,
                access_key: this.props.encryptedToken,
                device_token: "12345678",
                device_type: deviceType,
                user_id: this.props.userInfo.id,
                calendar_id: this.state.SelectedCalendareId,
                is_testdata: "1"
            })
        }
    }

    //  3.)  api Copy .....................
    CopyCalender() {
        console.log(this.state.userCalendar_Id, 'this.state.userCalendar_Id');
        console.log(this.state.SelectedCalendareId, 'this.state.SelectedCalendareId');

        if (this.state.SelectCopyCalendar == "" ||
            this.state.SelectCopyCalendar == undefined ||
            this.state.SelectCopyCalendar == 'Select Calendar') {
            alert('Please Select Calendar')
        } else {
            this.setState({ copyCalendarShowLoader: true })
            this.props.copyCalendar({
                secret_key: this.props.userDetail.data.userToken,
                access_key: this.props.encryptedToken,
                device_token: "12345678",
                device_type: deviceType,
                user_id: this.props.userInfo.id,
                calendar_id: this.state.copyFromCalendarId,
                copied_calendar_id: this.state.SelectedCalendareId,
                is_testdata: "1"
            })
        }
    }

    //  4.)  api Edit .....................
    // EditCalender() {
    //     console.log(this.state.userCalendar_Id, 'this.state.userCalendar_Id');
    //     console.log(this.state.SelectedCalendareId, 'this.state.SelectedCalendareId');


    //     if (this.state.EditCalenderName == '') {
    //         alert('Please Enter Calendar Name')
    //     } else if (this.state.EditCalendarTitle == '') {
    //         alert('Please Enter Tile')
    //     } else if (this.state.EditCalendarDescription == '') {
    //         alert('Please Enter Description')
    //     } else {
    //         this.setState({ showLoader: true });
    //         let endPoint = 'EditCalender';
    //         let body = '';

    //         let data = {
    //             "secret_key": global.userToken,
    //             "access_key": global.encrypted_value,
    //             "device_token": "12345678",
    //             "device_type": 1,
    //             "user_id": global.UserData.id,
    //             "calendar_id": this.state.userCalendar_Id,
    //             "copied_calendar_id": this.state.SelectedCalendareId,
    //             "is_testdata": "1"
    //         };

    //         body = JSON.stringify(data);
    //         console.log('CopyCalender body.....', body);

    //         APICaller(endPoint, 'post', body).then(async (json) => {
    //             console.log(json, 'CopyCalender json response');

    //             if (json.status == 1) {
    //                 alert(json.message);
    //                 // this.props.navigation.navigate('Schedule')
    //                 this.setState({ showLoader: false });
    //             } else {
    //                 alert(json.message);
    //                 this.setState({ showLoader: false });
    //             }
    //         })
    //             .catch((error) => {
    //                 this.setState({ showLoader: false });
    //                 alert('Something went wrong, try again.')
    //                 console.error(error);
    //             });
    //     }
    // }

    //  5.)  api Share .....................
    // ShareCalender() {
    //     console.log(this.state.userCalendar_Id, 'this.state.userCalendar_Id');
    //     console.log(this.state.SelectedCalendareId, 'this.state.SelectedCalendareId');

    //     if (this.state.SelectShareCalendar == {} ||
    //         this.state.SelectShareCalendar == undefined ||
    //         this.state.SelectShareCalendar == 'Select Calendar') {
    //         alert('Please Select Calendar')
    //     } else {
    //         this.setState({ showLoader: true });
    //         let endPoint = 'ShareCalender';
    //         let body = '';

    //         let data = {
    //             "secret_key": global.userToken,
    //             "access_key": global.encrypted_value,
    //             "device_token": "12345678",
    //             "device_type": 1,
    //             "user_id": global.UserData.id,
    //             "calendar_id": this.state.SelectedCalendareId,
    //             "is_testdata": "1"
    //         };

    //         body = JSON.stringify(data);
    //         console.log('ShareCalender body.....', body);

    //         APICaller(endPoint, 'post', body).then(async (json) => {
    //             console.log(json, 'ShareCalender json response');

    //             if (json.status == 1) {
    //                 alert(json.message);
    //                 this.setState({ showLoader: false });
    //             } else {
    //                 alert(json.message);
    //                 this.setState({ showLoader: false });
    //             }
    //         })
    //             .catch((error) => {
    //                 this.setState({ showLoader: false });
    //                 alert('Something went wrong, try again.')
    //                 console.error(error);
    //             });
    //     }
    // }

    CalendarTab() {
        return (
            <View style={{ flex: 1, margin: Matrics.Scale(7) }}>

                {/* ==================================== 1 ================================ */}
                <KeyboardAwareScrollView style={{ flex: 1 }}>
                    <View style={Styles.calendarTabmainColumnView}>
                        <TouchableOpacity
                            onPress={() => {
                                this.setState({ addCalendarTab: !this.state.addCalendarTab })
                                this.setState({ deleteCalenderTab: false, copyCalendarTab: false, editeCalendar: false, shareCalendar: false })
                            }}
                            style={{ height: Matrics.Scale(50), justifyContent: 'center' }}>

                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <View style={{ flex: 0.1, alignItems: 'center' }}>
                                    <Image style={Styles.calendarTabColumnIcon}
                                        source={this.state.addCalendarTab == true ? Images.SelectTab : Images.UnselctedTab}
                                        resizeMode='stretch' />
                                </View>
                                <View style={{ flex: 0.9, }}>
                                    <Text style={Styles.tabText}>
                                        Add calendar
                            </Text>
                                </View>
                            </View>

                        </TouchableOpacity>
                        {
                            this.state.addCalendarTab &&
                            <View>
                                <TextInput
                                    style={Styles.calendarTabInputText}
                                    value={this.state.NewCalendarName}
                                    placeholderTextColor={"#ccc"}
                                    onChangeText={text => this.setState({ NewCalendarName: text })}
                                    placeholder={"Calender Name"}
                                />
                                <View>

                                    <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                        <View style={{ flex: 0.1, alignItems: 'center' }}>
                                            <Image
                                                style={Styles.calendarTabColumnIcon}
                                                source={Images.selsctStoreUser}
                                                resizeMode='stretch' />
                                        </View>
                                        <View style={{ flex: 0.9, }}>
                                            <Text style={Styles.tabText}>
                                                Text Text Text
                                         </Text>
                                        </View>
                                    </View>

                                    <TouchableOpacity
                                        onPress={() => {
                                            this.createCalendar()
                                        }}
                                        style={Styles.calendarTabButton}>
                                        <Text
                                            style={{
                                                fontSize: Matrics.Scale(20),
                                                color: 'white',
                                            }}>ADD</Text>
                                    </TouchableOpacity>
                                </View>

                            </View>
                        }
                    </View>

                    {/* ==================================== 2 =============================== */}
                    <View style={Styles.calendarTabmainColumnView}>
                        <TouchableOpacity
                            onPress={() => {
                                this.setState({ deleteCalenderTab: !this.state.deleteCalenderTab })
                                this.setState({ addCalendarTab: false, copyCalendarTab: false, editeCalendar: false, shareCalendar: false })
                            }}
                            style={{ height: Matrics.Scale(50), justifyContent: 'center' }}>

                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <View style={{ flex: 0.1, alignItems: 'center' }}>
                                    <Image
                                        style={Styles.calendarTabColumnIcon}
                                        source={this.state.deleteCalenderTab == true ? Images.SelectTab : Images.UnselctedTab}
                                        resizeMode='stretch' />
                                </View>
                                <View style={{ flex: 0.9, }}>
                                    <Text style={Styles.tabText}>
                                        Delete calendar
                            </Text>
                                </View>
                            </View>

                        </TouchableOpacity>
                        {
                            this.state.deleteCalenderTab &&
                            <View>
                                <View style={Styles.share_deleteCalendarView}>

                                    <TouchableOpacity
                                        onPress={() => {
                                            if (!this.state.CalendarPickerOn) {
                                                this.setState({ CalendarPickerOn: true })
                                            } else {
                                                this.setState({ CalendarPickerOn: false })
                                            }
                                        }}
                                        style={{ height: Matrics.Scale(35), justifyContent: 'center' }}>
                                        <Text
                                            style={{
                                                color: this.state.CalendarPickerOn ? Colors.LOGIN : Colors.GREY_LIGHT,
                                                fontSize: Matrics.Scale(15),
                                                marginLeft: Matrics.Scale(10),
                                            }}>
                                            {this.state.SelectCalendar}
                                        </Text>
                                    </TouchableOpacity>
                                </View>

                                {
                                    this.state.CalendarPickerOn &&
                                    <Picker
                                        style={{ width: '100%', }}
                                        itemStyle={{
                                            width: '95%',
                                            borderTopWidth: 1,
                                            borderBottomWidth: 1,
                                            alignSelf: 'center',
                                            height: Matrics.Scale(100),
                                            borderColor: Colors.BOARDER_COLOR
                                        }}
                                        value={this.state.SelectCalendar}
                                        selectedValue={this.state.SelectCalendar}

                                        onValueChange={async (item) => {
                                            // console.log(item, 'Plan tab item.......');
                                            // console.log(item.id, 'Plan tab item.id.......');

                                            if (item.id != 0 && item.id != null) {
                                                selectedId = [item.id]
                                                await this.setState({ SelectedCalendareId: selectedId.toString() })
                                            } else {
                                                alert('Please Select Calendar')
                                            }
                                            this.setState({ SelectCalendar: item.title ? item.title : 'Select Calendar', choosenIndex: item.Position, CalendarPickerOn: false })
                                        }}>

                                        <Picker.Item label={'Select calendar'} value={'Select calendar'} />
                                        {this.state.PlanTab_CalendarList.map(item => {
                                            console.log(item.title, '.....title');

                                            return <Picker.Item label={item.title} value={item} />
                                        })
                                        }
                                    </Picker>
                                }
                                <View>
                                    <TouchableOpacity
                                        onPress={() => {
                                            this.DeleteCalender()
                                        }}
                                        style={Styles.calendarTabButton}>
                                        <Text
                                            style={{
                                                fontSize: Matrics.Scale(20),
                                                color: 'white',
                                            }}>DELETE</Text>
                                    </TouchableOpacity>
                                </View>

                            </View>
                        }
                    </View>

                    {/* ==================================== 3 ================================ */}
                    <View style={Styles.calendarTabmainColumnView}>
                        <TouchableOpacity
                            onPress={() => {
                                this.setState({ copyCalendarTab: !this.state.copyCalendarTab })
                                this.setState({ addCalendarTab: false, deleteCalenderTab: false, editeCalendar: false, shareCalendar: false })
                            }}
                            style={{ height: Matrics.Scale(50), justifyContent: 'center' }}>

                            <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                                <View style={{ flex: 0.1, alignItems: 'center' }}>
                                    <Image
                                        style={Styles.calendarTabColumnIcon}
                                        source={this.state.copyCalendarTab == true ? Images.SelectTab : Images.UnselctedTab}
                                        resizeMode='stretch' />
                                </View>
                                <View style={{ flex: 0.9, }}>
                                    <Text style={Styles.tabText}>
                                        Copy calendar
                            </Text>
                                </View>
                            </View>

                        </TouchableOpacity>
                        {
                            this.state.copyCalendarTab &&
                            <View>
                                <View style={Styles.calendarTabView3}>
                                    <TouchableOpacity
                                        onPress={() => {
                                            if (!this.state.isCopyCalendarPicker) {
                                                this.setState({ isCopyCalendarPicker: true })
                                            } else {
                                                this.setState({ isCopyCalendarPicker: false })
                                            }
                                        }}
                                        style={{ height: Matrics.Scale(35), justifyContent: 'center' }}>
                                        <Text
                                            style={{
                                                color: this.state.isCopyCalendarPicker ? Colors.LOGIN : Colors.GREY_LIGHT,
                                                fontSize: Matrics.Scale(15),
                                                marginLeft: Matrics.Scale(10),
                                            }}>
                                            {this.state.SelectCopyCalendar}
                                        </Text>
                                    </TouchableOpacity>
                                </View>
                                {
                                    this.state.isCopyCalendarPicker &&
                                    <Picker
                                        style={{ width: '100%' }}
                                        itemStyle={{
                                            width: '95%',
                                            borderTopWidth: 1,
                                            borderBottomWidth: 1,
                                            alignSelf: 'center',
                                            // backgroundColor:'yellow',
                                            height: Matrics.Scale(100),
                                            borderColor: Colors.BOARDER_COLOR
                                        }}
                                        value={this.state.SelectCopyCalendar}
                                        selectedValue={this.state.SelectCopyCalendar}

                                        onValueChange={async (item) => {
                                            // console.log(item, 'Plan tab item.......');
                                            console.log(item.id, 'Plan tab item.id.......');

                                            if (item.id != 0 && item.id != null) {
                                                selectedId = [item.id]
                                                await this.setState({ SelectedCalendareId: selectedId.toString() })
                                                console.log(this.state.SelectedCalendareId, 'SelectedCalendareId');

                                            } else {
                                                alert('Please Select Calendar')
                                            }
                                            this.setState({
                                                SelectCopyCalendar: item.title ? item.title : 'Select Calendar',
                                                choosenIndex: item.Position, isCopyCalendarPicker: false
                                            })
                                        }}>

                                        <Picker.Item label={'Select calendar'} value={'Select calendar'} />
                                        {this.state.PlanTab_CalendarList.map(item => {
                                            console.log(item.title, '.....title');
                                            return <Picker.Item label={item.title} value={item} />
                                        })
                                        }
                                    </Picker>
                                }
                                <View>
                                    <TouchableOpacity
                                        onPress={() => {
                                            this.CopyCalender()
                                            // this.props.navigation.navigate('Schedule')
                                        }}
                                        style={Styles.calendarTabButton}>
                                        <Text
                                            style={{
                                                fontSize: Matrics.Scale(20),
                                                color: 'white',
                                            }}>COPY</Text>
                                    </TouchableOpacity>
                                </View>

                            </View>
                        }
                    </View>

                    {/* ==================================== 4 ================================ */}
                    <View style={Styles.calendarTabmainColumnView}>
                        <TouchableOpacity
                            onPress={() => {
                                this.setState({ editeCalendar: !this.state.editeCalendar })
                                this.setState({ addCalendarTab: false, deleteCalenderTab: false, copyCalendarTab: false, shareCalendar: false })
                            }}
                            style={{ height: Matrics.Scale(50), justifyContent: 'center' }}>
                            <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
                                <View style={{ flex: 0.1, alignItems: 'center' }}>
                                    <Image
                                        style={Styles.calendarTabColumnIcon}
                                        source={this.state.editeCalendar == true ? Images.SelectTab : Images.UnselctedTab}
                                        resizeMode='stretch' />
                                </View>
                                <View style={{ flex: 0.9, }}>
                                    <Text style={Styles.tabText}>
                                        Edit calendar
                            </Text>
                                </View>
                            </View>

                        </TouchableOpacity>
                        {
                            this.state.editeCalendar &&
                            <View>
                                <TextInput
                                    style={Styles.calendarTabInputText}
                                    value={this.state.EditCalenderName}
                                    placeholderTextColor={"#ccc"}
                                    onChangeText={text => this.setState({ EditCalenderName: text })}
                                    placeholder={"Calender Name"}
                                />

                                {/* ------------------------------ */}
                                <View style={Styles.editeCalendarView}>
                                    <View style={{ flex: 0.8 }}>
                                        <TextInput
                                            style={{
                                                fontSize: Matrics.Scale(15),
                                                color: this.state.isCalendarTitleEdit ? 'gray' : 'black',
                                            }}
                                            value={this.state.EditCalendarTitle}
                                            editable={this.state.isCalendarTitleEdit}
                                            placeholderTextColor={"#ccc"}
                                            onChangeText={text => this.setState({ EditCalendarTitle: text })}
                                            placeholder={"Title"}
                                        />
                                    </View>

                                    <View style={{ flex: 0.2 }}>
                                        <TouchableOpacity
                                            onPress={() => {
                                                this.setState({ isCalendarTitleEdit: !this.state.isCalendarTitleEdit })
                                            }}>
                                            <Text style={{ color: Colors.LOGIN }}>
                                                Edit
                                        </Text>

                                        </TouchableOpacity>
                                    </View>
                                </View>
                                <View style={Styles.editeCalendarView}>
                                    <View style={{ flex: 0.8 }}>
                                        <TextInput
                                            style={{
                                                fontSize: Matrics.Scale(15),
                                                color: this.state.isCalendarDesEdit ? 'gray' : 'black',
                                            }}
                                            value={this.state.EditCalendarDescription}
                                            editable={this.state.isCalendarDesEdit}
                                            placeholderTextColor={"#ccc"}
                                            onChangeText={text => this.setState({ EditCalendarDescription: text })}
                                            placeholder={"Description"}
                                        />
                                    </View>

                                    <View style={{ flex: 0.2 }}>
                                        <TouchableOpacity
                                            onPress={() => {
                                                // this.onUpdateProfile(),
                                                this.setState({ isCalendarDesEdit: !this.state.isCalendarDesEdit })
                                            }}>
                                            <Text style={{ color: Colors.LOGIN }}>
                                                Edit
                                        </Text>

                                        </TouchableOpacity>
                                    </View>
                                </View>
                                {/* ------------------------------ */}

                                <View>
                                    <TouchableOpacity
                                        onPress={() => {
                                            // this.CreateCalender()
                                            // this.props.navigation.state.params.addItem(this.state.NewCalendarName)
                                            // this.props.navigation.navigate('Schedule')
                                        }}
                                        style={Styles.calendarTabButton}>
                                        <Text
                                            style={{
                                                fontSize: Matrics.Scale(20),
                                                color: 'white',
                                            }}>EDIT</Text>
                                    </TouchableOpacity>
                                </View>

                            </View>
                        }
                    </View>
                    {/* ==================================== 5 ================================ */}
                    <View style={Styles.calendarTabmainColumnView}>
                        <TouchableOpacity
                            onPress={() => {
                                this.setState({ shareCalendar: !this.state.shareCalendar })
                                this.setState({ addCalendarTab: false, deleteCalenderTab: false, copyCalendarTab: false, editeCalendar: false })
                            }}
                            style={{ height: Matrics.Scale(50), justifyContent: 'center' }}>
                            <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center' }}>
                                <View style={{ flex: 0.1, alignItems: 'center' }}>
                                    <Image
                                        style={{ height: Matrics.Scale(20), width: Matrics.Scale(20) }}
                                        source={this.state.shareCalendar == true ? Images.SelectTab : Images.UnselctedTab}
                                        // source={Images.UnselctedTab}
                                        resizeMode='stretch' />
                                </View>
                                <View style={{ flex: 0.9, }}>
                                    <Text style={Styles.tabText}>
                                        Share calendar
                            </Text>
                                </View>
                            </View>

                        </TouchableOpacity>

                        {
                            this.state.shareCalendar &&
                            <View>
                                <View style={Styles.share_deleteCalendarView}>
                                    <TouchableOpacity
                                        onPress={() => {
                                            if (!this.state.isShareCalendarPicker) {
                                                this.setState({ isShareCalendarPicker: true })
                                            } else {
                                                this.setState({ isShareCalendarPicker: false })
                                            }
                                        }}
                                        style={{ height: Matrics.Scale(35), justifyContent: 'center' }}>
                                        <Text
                                            style={{
                                                color: this.state.isShareCalendarPicker ? Colors.LOGIN : Colors.GREY_LIGHT,
                                                fontSize: Matrics.Scale(15),
                                                marginLeft: Matrics.Scale(10),
                                            }}>
                                            {this.state.SelectShareCalendar}
                                        </Text>
                                    </TouchableOpacity>
                                </View>
                                {
                                    this.state.isShareCalendarPicker &&
                                    <Picker
                                        style={{ width: '100%' }}
                                        itemStyle={{
                                            width: '95%',
                                            borderTopWidth: 1,
                                            borderBottomWidth: 1,
                                            alignSelf: 'center',
                                            // backgroundColor:'yellow',
                                            height: Matrics.Scale(100),
                                            borderColor: Colors.BOARDER_COLOR
                                        }}
                                        value={this.state.SelectShareCalendar}
                                        selectedValue={this.state.SelectShareCalendar}

                                        onValueChange={async (item) => {
                                            // console.log(item, 'Plan tab item.......');
                                            console.log(item.id, 'Plan tab item.id.......');

                                            if (item.id != 0 && item.id != null) {
                                                selectedId = [item.id]
                                                await this.setState({ SelectedCalendareId: selectedId.toString() })
                                                console.log(this.state.SelectedCalendareId, 'SelectedCalendareId');

                                            } else {
                                                alert('Please Choose user')
                                            }
                                            this.setState({
                                                SelectShareCalendar: item.title ? item.title : 'Choose user',
                                                choosenIndex: item.Position, isShareCalendarPicker: false
                                            })
                                        }}>

                                        <Picker.Item label={'Choose user'} value={'Choose user'} />
                                        {this.state.PlanTab_CalendarList.map(item => {
                                            console.log(item.title, '.....title');
                                            return <Picker.Item label={item.title} value={item} />
                                        })
                                        }
                                    </Picker>
                                }
                                <View>
                                    <TouchableOpacity
                                        onPress={() => {
                                            // this. ShareCalender()
                                            // this.props.navigation.navigate('Schedule')
                                        }}
                                        style={Styles.calendarTabButton}>
                                        <Text
                                            style={{
                                                fontSize: Matrics.Scale(20),
                                                color: 'white',
                                            }}>SHARE</Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        }
                    </View>
                </KeyboardAwareScrollView>
            </View>

        );
    }
    // .......................................... Calendar Tab End..............................
    render() {
        return (
            <SafeAreaView style={{ flex: 1 }}>

                <View style={{ flex: 1 }}>

                    {/* 3 Tab Hader start============================>>>>>>>>>>>*/}
                    <View style={{ flexDirection: 'row' }}>

                        <View style={Styles.tabManiView}>
                            <TouchableOpacity
                                onPress={() => {
                                    this.setState({ PlanTab: true })
                                    this.setState({ MessageTab: false })
                                    this.setState({ CalendarTab: false })
                                }}>
                                <View style={{
                                    height: 48,
                                    borderBottomColor: this.state.PlanTab ? Colors.LOGIN : 'white',
                                    borderBottomWidth: 1, alignItems: 'center', justifyContent: 'center'
                                }}>
                                    <Text style={{ color: this.state.PlanTab ? 'black' : 'gray' }}>
                                        {/* Plan */}
                                        {language.editschedule.Plan}
                                    </Text>
                                </View>

                            </TouchableOpacity>
                        </View>

                        <View style={Styles.tabManiView}>
                            <TouchableOpacity
                                onPress={() => {
                                    this.setState({ PlanTab: false })
                                    this.setState({ MessageTab: true })
                                    this.setState({ CalendarTab: false })
                                }}>
                                <View style={{
                                    height: 48,
                                    borderBottomColor: this.state.MessageTab ? Colors.LOGIN : 'white',
                                    borderBottomWidth: 1.5, alignItems: 'center', justifyContent: 'center'
                                }}>
                                    <Text style={{ color: this.state.MessageTab ? 'black' : 'gray' }}>
                                        {/* Message */}
                                        {language.editschedule.Message}
                                    </Text>
                                </View>
                            </TouchableOpacity>
                        </View>

                        <View style={Styles.tabManiView}>
                            <TouchableOpacity
                                onPress={() => {
                                    this.setState({ PlanTab: false })
                                    this.setState({ MessageTab: false })
                                    this.setState({ CalendarTab: true })

                                }}>
                                <View style={{
                                    height: 48,
                                    borderBottomColor: this.state.CalendarTab ? Colors.LOGIN : 'white',
                                    borderBottomWidth: 1.5, alignItems: 'center', justifyContent: 'center'
                                }}>
                                    <Text style={{ color: this.state.CalendarTab ? 'black' : 'gray' }}>
                                        {/* Calendar */}
                                        {language.editschedule.Calendar}
                                    </Text>
                                </View>
                            </TouchableOpacity>
                        </View>

                    </View>
                    {/* 3 Tab Hader end============================>>>>>>>>>>>*/}

                    {
                        this.state.PlanTab &&
                        this.PlanTab()
                    }
                    {
                        this.state.MessageTab &&
                        this.MessageTab()
                    }
                    {
                        this.state.CalendarTab &&
                        this.CalendarTab()
                    }
                </View >
                <LoadWheel isVisible={this.state.showLoader || this.state.calendarListShowLoader || this.state.createCalendarShowLoader || this.state.deleteCalendarShowLoader || this.state.CreateTodShowLoader || this.state.EditTodoShowLoader || this.state.copyCalendarShowLoader} />
            </SafeAreaView>
        );
    }
}
const Styles = {
    tabManiView: {
        borderBottomColor: '#B6B4B6',
        borderBottomWidth: 1,
        borderTopColor: '#B6B4B6',
        borderTopWidth: 1,
        flex: 0.33,
    },
    tabLayoutView: {
        borderWidth: 1,
        marginBottom: Matrics.Scale(7),
        borderColor: 'gray',
        justifyContent: 'center'
    },
    tabText: {
        marginLeft: Matrics.Scale(10)
    },
    buttonContainer: {
        height: Matrics.Scale(40),
        marginTop: Matrics.Scale(10),
        borderWidth: 1,
        borderColor: Colors.LOGIN,
        alignItems: 'center',
        justifyContent: "center",
        width: "45%",
        borderRadius: Matrics.Scale(3)
    },
    // plan........
    planMainView: {
        borderWidth: 1,
        // marginBottom: Matrics.Scale(7),
        borderColor: Colors.BOARDER_COLOR,
        borderRadius: Matrics.Scale(5),
        height: Matrics.Scale(50),
        justifyContent: 'center'
    },
    plantabView2: {
        borderWidth: 1,
        marginTop: Matrics.Scale(7),
        marginBottom: Matrics.Scale(7),
        borderColor: Colors.BOARDER_COLOR,
        borderRadius: Matrics.Scale(5),
        height: Matrics.Scale(50),
        justifyContent: 'center'
    },
    plantabView3: {
        borderTopWidth: 1,
        borderLeftWidth: 1,
        borderRightWidth: 1,
        borderColor: Colors.BOARDER_COLOR,
        borderRadius: Matrics.Scale(5),
        // padding: Matrics.Scale(5),
        height: Matrics.Scale(50),
        justifyContent: 'center'
    },
    plantabView4: {
        borderWidth: 1,
        marginBottom: Matrics.Scale(7),
        borderColor: Colors.BOARDER_COLOR,
        borderRadius: Matrics.Scale(5),
        height: Matrics.Scale(50),
        justifyContent: 'center'
    },
    plantabView5: {
        borderWidth: 1,
        borderColor: Colors.BOARDER_COLOR,
        borderRadius: Matrics.Scale(5),
        height: Matrics.Scale(50),
        justifyContent: 'center'
    },
    // message tab........
    messageTabView4: {
        borderWidth: 1,
        borderLeftWidth: 1,
        borderRightWidth: 1,
        borderColor: Colors.BOARDER_COLOR,
        borderRadius: Matrics.Scale(5),
        marginBottom: Matrics.Scale(7),
        height: Matrics.Scale(50),
        justifyContent: 'center',
        borderBottomRadius: Matrics.Scale(5),
    },
    newTabLayoutView: {
        borderWidth: 1,
        marginBottom: Matrics.Scale(7),
        borderColor: Colors.BOARDER_COLOR,
        borderRadius: Matrics.Scale(5),
        height: Matrics.Scale(50),
        justifyContent: 'center'
    },
    // calendar tab.............
    calendarTabmainColumnView: {
        borderWidth: 1,
        marginBottom: Matrics.Scale(7),
        borderColor: Colors.BOARDER_COLOR,
        borderRadius: Matrics.Scale(5),
        justifyContent: 'center'
    },
    calendarTabInputText: {
        backgroundColor: '#F8F8F8',
        fontSize: Matrics.Scale(15),
        padding: Matrics.Scale(10),
        marginLeft: Matrics.Scale(10),
        marginRight: Matrics.Scale(10),
        marginBottom: Matrics.Scale(10),
        borderRadius: Matrics.Scale(5)
    },
    calendarTabButton: {
        height: Matrics.Scale(35),
        margin: Matrics.Scale(10),
        borderWidth: 1,
        borderColor: Colors.LOGIN,
        alignItems: 'center',
        justifyContent: "center",
        backgroundColor: Colors.LOGIN,
        borderRadius: Matrics.Scale(3)
    },
    calendarTabColumnIcon: {
        height: Matrics.Scale(20),
        width: Matrics.Scale(20)
    },
    editeCalendarView: {
        backgroundColor: '#F8F8F8',
        flexDirection: 'row',
        padding: Matrics.Scale(7),
        marginLeft: Matrics.Scale(10),
        marginRight: Matrics.Scale(10),
        marginBottom: Matrics.Scale(10),
        borderRadius: Matrics.Scale(5)
    },
    share_deleteCalendarView: {
        borderColor: '#ECECEC',
        borderBottomWidth: Matrics.Scale(1),
        borderTopWidth: Matrics.Scale(1),
        marginLeft: Matrics.Scale(10),
        marginRight: Matrics.Scale(10)
    },
    calendarTabView3: {
        borderColor: '#ECECEC',
        borderBottomWidth: Matrics.Scale(1),
        borderTopWidth: Matrics.Scale(1),
        marginLeft: Matrics.Scale(10),
        marginRight: Matrics.Scale(10)
    }



}

//Props Connection
const mapStateToProps = (state) => {
    console.log(state, 'state==================');

    return {
        calendarListDetail: state.Schedule,
        createdCalendarDetail: state.CalendarTab,
        deleteCalendarDetail: state.DeleteCalendar,
        copyCalendarDetail: state.CopyCalendar,
        createMessageDetail: state.MessageTab,
        createTodoDetail: state.PlanTab,
        editTodoDetail: state.EditTodo,
        logout: state.Logout,
        userDetail: state.Auth,
        encryptedToken: state.Encrypt.data ? state.Encrypt.data.encrypted_value : undefined,
        userInfo: state.Auth.data && state.Auth.data.data ? state.Auth.data.data.User : undefined,

    };
}
//Redux Connection  
export default connect(mapStateToProps, { logOutRequest, allCalendarList, createCalendar, deleteCalendar, copyCalendar, createTodo, editTodo, createMessage })(EditSchedule);