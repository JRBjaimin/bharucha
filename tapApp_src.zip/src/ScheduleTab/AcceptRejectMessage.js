import React, { Component } from "react";
import { connect } from 'react-redux';
import { Text, View, Image, TextInput, TouchableOpacity, Platform, FlatList, Modal } from "react-native";
import AsyncStorage from '@react-native-community/async-storage';
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
//Assets
import { createAcceptRejectMessage, taskApprovalManager } from '@Redux/Actions/AcceptRejecrMessageActions'
import { Colors, Matrics, Images } from "../Assets";
import { LoadWheel } from "../Components/Common/LoadWheel";
import { HeaderEditLeftButton } from '../Components'
import { profilePath } from "../Components/Common/imagePath";

let Nodata = true
let deviceType = Platform.OS == 'ios' ? 1 : 0;
class AcceptRejectMessage extends React.Component {
    //NAVGATION OPTIONS FOR HEADER
    static navigationOptions = ({ navigation }) => ({
        headerTitle: 'User Request',
        headerTitleStyle: { flex: 1, textAlign: 'center' },
        headerLeft: <HeaderEditLeftButton
            onEditLeftPress={() => { navigation.navigate('Schedule') }}
        />,
        headerRight: <View />
    })

    constructor(props) {
        super(props);
        this.state = {
            // RequestedUsershowLoader: false,
            AcceptRejectMessageShowLoader: false,
            TaskApprovalManagerShowLoader: false,
            profileImage: this.props.navigation.state.params.data.profile_picture,
            calendar_id: this.props.navigation.state.params.data.id,
            loading: false,
            Comment: '',
            isSelectOK: false,
            isSelectNG: false,
            request_status: '',
            RequestedUserList: [],
            isModal: false,
            isRequestStatus: 'Pandding',
            data: {}
        };
    }

    async componentWillMount() {
        this.offset = 0;
        if (this.props.navigation.state.params) {
            console.log(this.props.navigation.state.params, 'this.props.navigation.state.params')
            await this.setState({ data: this.props.navigation.state.params.data })
            console.log(this.state.data, "....data.....");

        }
        // await this.ListRequestedUser(this.offset)
    }

    async componentWillReceiveProps(nextProps) {

        console.log(nextProps, 'nextProps');
        console.log(nextProps.AcceptRejectMessageDetail, 'nextProps.AcceptRejectMessageDetail');
        console.log(nextProps.TaskApprovalManagreDetail, 'nextProps.TaskApprovalManagreDetail');

        const nextAcceptRejectMessageDetail = nextProps.AcceptRejectMessageDetail;
        console.log(nextAcceptRejectMessageDetail, 'nextAcceptRejectMessageDetail');

        const nextTaskApprovalManagreDetail = nextProps.TaskApprovalManagreDetail;
        console.log(nextTaskApprovalManagreDetail, 'nextTaskApprovalManagreDetail');

        // .....................createAcceptRejectMessage list.....................
        console.log(this.state.RequestedUsershowLoader, "RequestedUsershowLoader");

        if (nextAcceptRejectMessageDetail.acceptRejectMessageSuccess && nextAcceptRejectMessageDetail.data.status == 1 && this.state.AcceptRejectMessageShowLoader) {
            this.props.navigation.navigate('Schedule')
            await this.setState({ AcceptRejectMessageShowLoader: false })
        }
        else if (nextAcceptRejectMessageDetail.acceptRejectMessageSuccess && nextAcceptRejectMessageDetail.data.status == 0 && this.state.AcceptRejectMessageShowLoader) {
            await this.setState({ AcceptRejectMessageShowLoader: false })
            alert(nextAcceptRejectMessageDetail.data.message)
        }
        //if api doesn't get called
        else if (nextAcceptRejectMessageDetail.acceptRejectMessageFail) {
            await this.setState({ AcceptRejectMessageShowLoader: false })
            alert('Something went wrong.Please try again later.')
        }

        // .....................TaskApprovalManager list.....................
        console.log(this.state.TaskApprovalManagerShowLoader, "TaskApprovalManagerShowLoader");

        if (nextTaskApprovalManagreDetail.taskApproveSuccess && nextTaskApprovalManagreDetail.data.status == 1 && this.state.TaskApprovalManagerShowLoader) {
            this.props.navigation.navigate('Schedule')
            await this.setState({ TaskApprovalManagerShowLoader: false })
        }
        else if (nextTaskApprovalManagreDetail.taskApproveSuccess && nextTaskApprovalManagreDetail.data.status == 0 && this.state.TaskApprovalManagerShowLoader) {
            await this.setState({ TaskApprovalManagerShowLoader: false })
            alert(nextTaskApprovalManagreDetail.data.message)
        }
        //if api doesn't get called
        else if (nextTaskApprovalManagreDetail.taskApproveFail) {
            await this.setState({ TaskApprovalManagerShowLoader: false })
            alert('Something went wrong.Please try again later.')
        }


    }

    loadMoreData = () => {
        console.log(this.offset, 'loadMoreData');

        if (this.state.RequestedUserList.length != 0 && Nodata) {
            this.offset = this.offset + 1;
            setTimeout(() => { this.ListRequestedUser(this.offset) }, 500)
        }
    }

    async AcceptRejectMessage() {
        console.log(this.state.request_status, 'this.state.request_status');
        if (this.state.request_status == '') {
            alert('Please select one button')
        } else if (this.state.Comment == '') {
            alert('Please write a comment')
        } else {
            console.log(this.props, '<<<<<props createAcceptRejectMessage>>>>>>');
            // await this.setState({ : true })
            console.log('access_key:', this.props.encryptedToken)
            console.log('secret_key:', this.props.userDetail.data.userToken);
            console.log('userInfo:', this.props.userInfo);

            this.props.createAcceptRejectMessage({
                secret_key: this.props.userDetail.data.userToken,
                access_key: this.props.encryptedToken,
                device_token: "12345678",
                device_type: deviceType,
                user_id: this.props.userInfo.id,
                calendar_task_id: this.state.calendar_id,
                is_testdata: "1",
                request_status: this.state.request_status,
                comment: this.state.Comment
            })
        }
    }

    async TaskApprovalManager() {
        console.log(this.state.request_status, 'this.state.request_status');

        if (this.state.request_status == '') {
            alert('Please select one button')
        } else if (this.state.Comment == '') {
            alert('Please write a comment')
        } else {
            await this.setState({ TaskApprovalManagerShowLoader: true });
            this.props.taskApprovalManager({
                secret_key: this.props.userDetail.data.userToken,
                access_key: this.props.encryptedToken,
                device_token: "12345678",
                device_type: deviceType,
                user_id: this.props.userInfo.id,
                calendar_task_id: this.state.calendar_id,
                request_status: this.state.request_status,
                is_testdata: "1",
                comment: this.state.Comment
            })

            //         let endPoint = 'TaskApprovalManager';
            //         let body = '';
            //         let data = {
            //             "secret_key": global.userToken,
            //             "access_key": global.encrypted_value,
            //             "device_token": "12345678",
            //             "device_type": 1,
            //             "user_id": global.UserData.id,
            //             "calendar_task_id": this.state.calendar_id,
            //             "request_status": this.state.request_status,
            //             "is_testdata": "1",
            //             "comment": this.state.Comment
            //         };
            //         body = JSON.stringify(data);
            //         console.log(body, 'TaskApprovalManager body');


            //         APICaller(endPoint, 'post', body).then(async (json) => {
            //             console.log(json, 'TaskApprovalManager json response');

            //             // if (json.status == 1) {

            //             alert(json.message)
            //             // this.props.navigation.navigate('Schedule')
        }
    }


    // closeModal() {
    //     this.setState({ isModal: false });
    // }
    loadEmptyView = () => {
        return (
            <View style={{ flex: 1, justifyContent: 'center' }}>
                {this.state.loading == false &&
                    <View>
                        <Text
                            style={{ color: 'red', fontSize: Matrics.Scale(17), textAlign: 'center' }}>
                            NO Data Found
                        </Text>
                    </View>
                }
            </View>
        );
    }

    // renderModel() {
    //     return (
    //         <Modal
    //             transparent={true}
    //             visible={this.state.isModal}
    //             animationType={'slide'}
    //             onRequestClose={() => this.setState({ isModal: false })}
    //         >

    //             {/* Header start============================>>>>>>>>>>>*/}
    //             <View style={Styles.headerContainer}>

    //                 <View style={Styles.headerLeftContainer}>
    //                     <TouchableOpacity
    //                         onPress={() => this.closeModal()}
    //                         style={Styles.tuch}>
    //                         <Text style={{ color: '#FBA800' }}>
    //                             CLOSE
    //                         </Text>

    //                     </TouchableOpacity>

    //                 </View>

    //                 <View style={Styles.headerCenterContainer}>
    //                     <Text style={Styles.textStyle}>
    //                         Employee Request</Text>
    //                 </View>

    //                 <View style={Styles.headerRightContainer} />
    //             </View>
    //             {/* Header end============================>>>>>>>>>>>>>*/}

    //             <View style={{}}>
    //                 <View style={{
    //                     backgroundColor: 'white',
    //                     height: 500,
    //                 }}>
    //                     <FlatList
    //                         contentContainerStyle={{ flexGrow: 1 }}
    //                         data={this.state.RequestedUserList}
    //                         extraData={this.state}
    //                         renderItem={(item) => {
    //                             console.log(item, 'Message item');

    //                             return (
    //                                 // <TouchableOpacity>
    //                                 <View style={{ flexDirection: 'row', flex: 1 }}>
    //                                     <View style={{
    //                                         height: Matrics.Scale(60),
    //                                         flex: 0.2, justifyContent: 'center',
    //                                         marginLeft: Matrics.Scale(10)
    //                                     }}>
    //                                         <Image
    //                                             source={item.image ? { uri: profilePath + item.image } : Images.friendIcon}

    //                                             resizeMode='stretch'
    //                                             style={{
    //                                                 marginLeft: Matrics.Scale(10),
    //                                                 height: Matrics.Scale(25),
    //                                                 width: Matrics.Scale(25),
    //                                             }} />
    //                                     </View>


    //                                     <View style={{
    //                                         flex: 0.6, height: Matrics.Scale(60),
    //                                         alignContent: 'center', justifyContent: 'center',
    //                                         borderColor: Colors.TAB_BG, borderBottomWidth: 1,

    //                                     }}>
    //                                         <View>
    //                                             <Text style={{ justifyContent: 'center', fontSize: 18 }}>
    //                                                 {item.item.firstname}
    //                                             </Text>
    //                                         </View>
    //                                         <View>
    //                                             <Text style={{ justifyContent: 'center', fontSize: 12 }}>
    //                                                 {item.item.user_comment}
    //                                             </Text>
    //                                         </View>

    //                                     </View>

    //                                     <View style={{
    //                                         flex: 0.2,
    //                                         height: Matrics.Scale(60), alignItems: 'center',
    //                                         justifyContent: 'center',
    //                                         borderColor: Colors.TAB_BG, borderBottomWidth: 1,
    //                                         marginRight: Matrics.Scale(10)
    //                                     }}>
    //                                         {
    //                                             item.item.status == 0 &&
    //                                             <Text style={{ color: 'orange' }}>
    //                                                 Pending
    //                                             </Text>
    //                                         }
    //                                         {
    //                                             item.item.status == 1 &&
    //                                             <Text style={{ color: 'green' }}>
    //                                                 Accepted
    //                                             </Text>
    //                                         }
    //                                         {
    //                                             item.item.status == 2 &&
    //                                             <Text style={{ color: 'red' }}>
    //                                                 Rejected
    //                                             </Text>
    //                                         }

    //                                     </View>
    //                                 </View>
    //                             )
    //                         }}
    //                         ListEmptyComponent={() => this.loadEmptyView()}
    //                         onEndReached={() => this.loadMoreData()}
    //                         onEndReachedThreshold={0.5}
    //                         showsVerticalScrollIndicator={false}
    //                     />

    //                 </View>
    //                 <View style={{ height: Matrics.Scale(400), backgroundColor: 'white' }}>
    //                 </View>

    //                 {/* ========================== */}

    //             </View>

    //         </Modal >
    //     )
    // }

    render() {
        return (
            <View style={{ flex: 1 }}>
                {/* <CommonStatusBar translucent={true} backgroundColor={Colors.STATUS_BAR_COLOR} barStyle='light-content' /> */}

                <KeyboardAwareScrollView style={{ flex: 1, margin: Matrics.Scale(5) }}>
                    <View style={{ flex: 1 }}>
                        <View style={Styles.mainView}>
                            <View style={{ flexDirection: 'row', backgroundColor: Colors.LightYellow }}>

                                <View style={{ flex: 0.1, margin: Matrics.Scale(10) }}>
                                    <Image
                                        source={Images.MessageListIcon}
                                        resizeMode='stretch'
                                        style={Styles.icon}
                                    />
                                </View>
                                <View style={{ margin: Matrics.Scale(10), flex: 0.9, justifyContent: 'center' }}>

                                    <Text style={{ fontSize: Matrics.Scale(15) }}>
                                        Change Work Schedule
                                    </Text>
                                </View>

                            </View>


                            <View style={{ flexDirection: 'row' }}>
                                <View style={{ flex: 0.2, margin: Matrics.Scale(10) }}>
                                    <Text style={{ color: '#C7C7C7', fontSize: Matrics.Scale(15) }}>
                                        Sender
                                </Text>
                                </View>

                                <View style={{ flex: 0.1, margin: Matrics.Scale(10) }}>
                                    <Image
                                        source={this.state.profileImage ? { uri: profilePath + this.state.profileImage } : Images.friendIcon}
                                        resizeMode='stretch'
                                        style={Styles.image}
                                    />
                                </View>
                                <View style={{ margin: Matrics.Scale(10), flex: 0.7, }}>

                                    <Text style={{ fontSize: Matrics.Scale(15) }}>
                                        {/* data */}
                                        {this.props.navigation.state.params.data.firstname}
                                    </Text>
                                </View>
                            </View>

                            <View style={{ flexDirection: 'row' }}>
                                <View style={{ flex: 0.2, margin: Matrics.Scale(10) }}>
                                    <Text style={{ color: '#C7C7C7', fontSize: Matrics.Scale(15) }}>
                                        Date
                                </Text>
                                </View>

                                <View style={{ flex: 0.8, justifyContent: 'center' }}>

                                    <Text style={{ fontSize: Matrics.Scale(15) }}>
                                        {this.props.navigation.state.params.data.created_date}
                                        {/* Change Work Schedule */}
                                    </Text>
                                </View>
                            </View>

                            <View style={{ flexDirection: 'row' }}>
                                <View style={{ marginLeft: Matrics.Scale(10), marginBottom: Matrics.Scale(10) }}>
                                    <Text style={{ color: '#C7C7C7', fontSize: Matrics.Scale(15) }}>
                                        Comment
                                </Text>
                                </View>
                                <View style={{ marginLeft: Matrics.Scale(10), flex: 0.8, }}>

                                    <Text style={{ fontSize: Matrics.Scale(15) }}>
                                        {/* comment */}
                                        {this.props.navigation.state.params.data.comments}
                                    </Text>
                                </View>
                            </View>
                        </View>

                        <View style={{ flexDirection: 'row', }}>
                            <TouchableOpacity
                                onPress={() => {
                                    this.setState({ request_status: '1', isSelectOK: true, isSelectNG: false })
                                }}
                                style={{
                                    flex: 1, height: Matrics.Scale(40),
                                    justifyContent: 'center', alignItems: 'center',
                                    margin: Matrics.Scale(10), borderRadius: Matrics.Scale(2),
                                    backgroundColor: this.state.isSelectOK && !this.state.isSelectNG ? Colors.LOGIN : Colors.GREY,
                                }}>

                                <Text style={{ color: 'white', fontSize: Matrics.Scale(20) }}>OK</Text>
                            </TouchableOpacity>
                            <TouchableOpacity
                                onPress={() => {
                                    this.setState({ request_status: '2', isSelectOK: false, isSelectNG: true })
                                }}
                                style={{
                                    flex: 1, height: Matrics.Scale(40),
                                    justifyContent: 'center', alignItems: 'center',
                                    margin: Matrics.Scale(10), borderRadius: Matrics.Scale(2),
                                    backgroundColor: this.state.isSelectNG && !this.state.isSelectOK ? Colors.LOGIN : Colors.GREY,
                                }}>
                                <Text style={{ color: 'white', fontSize: Matrics.Scale(20) }}>NG</Text>
                            </TouchableOpacity>
                        </View>

                        <View style={Styles.commentView}>
                            <TextInput
                                style={{ marginLeft: Matrics.Scale(10) }}
                                value={this.state.Comment}
                                placeholderTextColor={"#ccc"}
                                onChangeText={text => this.setState({ Comment: text })}
                                placeholder={"Comment"}
                            />
                        </View>

                        <View style={{ justifyContent: 'center', alignItems: 'center', }}>
                            <TouchableOpacity

                                onPress={async () => {
                                    console.log(this.props.userInfo.calender_id, 'this.props.userInfo.calender_id.........');
                                    console.log(this.state.calendar_id, 'this.state.calendar_id.........');

                                    if (this.props.userInfo.calender_id == this.state.calendar_id) {
                                        console.log('<<<< send button calendar_id >>>>', this.state.calendar_id)
                                        this.TaskApprovalManager()
                                        // this.AcceptRejectMessage()
                                    } else {
                                        console.log('else part');
                                        await this.AcceptRejectMessage()
                                    }
                                }}

                                style={{
                                    width: 150, height: Matrics.Scale(40),
                                    justifyContent: 'center', alignItems: 'center',
                                    margin: Matrics.Scale(10), borderRadius: Matrics.Scale(2), borderWidth: 1.5,
                                    borderColor: this.state.isSelectNG || this.state.isSelectOK ? Colors.LOGIN : Colors.GREY,
                                }}>
                                <Text style={{
                                    color: this.state.isSelectNG || this.state.isSelectOK ? Colors.LOGIN : Colors.GREY,
                                    fontSize: Matrics.Scale(20)
                                }}>SEND</Text>
                            </TouchableOpacity>

                        </View>

                    </View>

                </KeyboardAwareScrollView>

                <View style={Styles.footerView}>

                    <TouchableOpacity
                        onPress={() => { this.props.navigation.navigate('EmployeeRequest', { data: this.state.data }) }
                            // this.setState({ isModal: true })} style={Styles.buttonContainer}
                        } >
                        <Text style={Styles.empReqText}>Employee Request</Text>
                    </TouchableOpacity>
                </View>
                {/* {this.renderModel()} */}
                <LoadWheel isVisible={this.state.AcceptRejectMessageShowLoader || this.state.TaskApprovalManagerShowLoader} />
            </View >
        );
    }
}
const Styles = {
    // Header in model start========>>>>>>>>>
    headerContainer: {
        backgroundColor: Colors.STATUS_BAR_COLOR,
        height: Matrics.Scale(70),
        flexDirection: 'row',
        paddingBottom: Matrics.Scale(10),
        paddingTop: Matrics.Scale(10)
    },
    headerLeftContainer: {
        flex: 0.2,
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        // backgroundColor: 'orange'
    },
    headerCenterContainer: {
        flex: 0.6,
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
        // backgroundColor: ''
    },
    headerRightContainer: {
        flex: 0.2,
        justifyContent: 'center',
        alignItems: 'center',
        // backgroundColor: 'green'
    },
    textStyle: {
        fontSize: 25,
        justifyContent: 'center',
        alignItems: 'center',
        color: 'black'
    },
    tuch: {
        margin: Matrics.Scale(2),
        backgroundColor: 'white',
        alignItems: 'center',
        justifyContent: 'center',
        shadowColor: 'black',
        borderRadius: 5,
        borderWidth: 1.5,
        borderColor: Colors.TAB_BG,
        height: Matrics.Scale(30),
        width: Matrics.Scale(60)
    },
    // Header end========>>>>>>>>>
    buttonStyle: {
        flex: 1,
        height: Matrics.Scale(40),
        justifyContent: 'center',
        alignItems: 'center',
        margin: Matrics.Scale(10),
        borderRadius: Matrics.Scale(2)
    },
    buttonContainer: {
        backgroundColor: 'white',
        height: Matrics.Scale(30),
        flexDirection: "row",
        alignItems: 'center',
        justifyContent: "center",
        borderWidth: 1.5,
        width: '60%',
        borderColor: Colors.LOGIN,
        margin: Matrics.Scale(12),
        borderRadius: Matrics.Scale(5)
    },
    mainView: {
        borderWidth: 1,
        margin: Matrics.Scale(10),
        borderColor: Colors.GREY,
        borderRadius: Matrics.Scale(2)
    },
    icon: {
        height: Matrics.Scale(30),
        width: Matrics.Scale(30),
        marginLeft: Matrics.Scale(10),
        justifyContent: 'center', alignItems: 'center'
    },
    image: {
        height: Matrics.Scale(35),
        width: Matrics.Scale(35),
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: Platform.OS == 'ios' ? Matrics.Scale(17.5) : Matrics.Scale(70)
    },
    commentView: {
        borderWidth: 1,
        margin: Matrics.Scale(10),
        borderColor: Colors.GREY,
        height: Matrics.Scale(50),
        justifyContent: 'center'
    },
    footerView: {
        backgroundColor: Colors.LightYellow,
        position: 'absolute',
        alignItems: 'center',
        justifyContent: "center",
        bottom: 0,
        width: '100%',
        borderTopWidth: 1
    },
    empReqText: {
        marginTop: Matrics.Scale(10),
        marginBottom: Matrics.Scale(10),
        fontWeight: '600',
        fontSize: Matrics.Scale(18),
        color: Colors.LOGIN,
    }
}

//Props Connection
const mapStateToProps = (state) => {
    console.log(state, 'state AcceptRejectMessage==================');

    return {
        AcceptRejectMessageDetail: state.AcceptRejectMessage,
        TaskApprovalManagreDetail: state.TaskApprovalManagre,
        // ListRequestedUserDetail: state.ListOfRequestedUser,
        userDetail: state.Auth,
        encryptedToken: state.Encrypt.data ? state.Encrypt.data.encrypted_value : undefined,
        userInfo: state.Auth.data && state.Auth.data.data ? state.Auth.data.data.User : undefined,
    };
}

//Redux Connection  
export default connect(mapStateToProps, { createAcceptRejectMessage, taskApprovalManager })(AcceptRejectMessage);