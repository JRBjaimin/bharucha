import { createStackNavigator } from 'react-navigation'
import Schedule from './Schedule'
import EditSchedule from './EditSchedule'
import ChooseToUser from './ChooseToUser'
import AcceptRejectMessage from './AcceptRejectMessage'
import EmployeeRequest from './EmployeeRequest'

const ScheduleStack = createStackNavigator(
    {
        Schedule: {
            screen: Schedule
        },
        EditSchedule: {
            screen: EditSchedule
        },
        ChooseToUser: {
            screen: ChooseToUser
        },
        AcceptRejectMessage: {
            screen: AcceptRejectMessage
        }
    },
    {
        mode: 'card',
    });

const ScheduleNavigator = createStackNavigator({
    ScheduleStack: {
        screen: ScheduleStack,
        navigationOptions: {
            header: null
        }
    },
    EmployeeRequest: { screen: EmployeeRequest }
},
    {
        mode: 'modal',
    }


)

export default ScheduleNavigator;
