//LIBRARIES
import React from 'react'
import { Image } from 'react-native'
import { createStackNavigator, createBottomTabNavigator, createAppContainer } from 'react-navigation'
//SCREENS
import talkNavigator from './TalkTab/TalkTabNavigation'
import ScheduleNavigator from './ScheduleTab/ScheduleNavigation';
import FriendNavigator from './FriendTab/FriendNavigation';
import SettingsNavigator from './SettingsTab/SettingsNavigation';
import LoginNavigator from './AuthTab/AuthNavigation'
import SplashScreen from './SplashScreen'

//ASSETS
import language from './Assets/Languages/Language'
import { Images, Colors, Matrics } from '../src/Assets'


//MAIN TAB NAVIGATION
const TabNavigator = createBottomTabNavigator({

    Talk: {
        screen: talkNavigator,
        navigationOptions: ({ navigation }) => ({
            tabBarLabel: language.talk.tab,
            tabBarVisible: navigation.state.params && navigation.state.params.tabBarVisible,
            tabBarIcon: ({ tintColor }) => (
                <Image source={Images.talkTab} style={{ height: Matrics.Scale(22), width: Matrics.Scale(25), tintColor: tintColor }} />
            ),
        })
    },
    Schedule: {
        screen: ScheduleNavigator,
        navigationOptions: () => ({
            tabBarLabel: language.schedule.tab,
            tabBarIcon: ({ tintColor, focused }) => (

                // <Image source = { Images.scheduleTab } style={{ height: Matrics.Scale(22), width: Matrics.Scale(24), tintColor: tintColor }} />

                <Image source={`${focused ? Images.schedule_active : Images.schedule_inactive}`} style={{ height: Matrics.Scale(22), width: Matrics.Scale(24) }} />

            ),
            tabBarOnPress: ({ navigation }) => {
                navigation.navigate('Schedule');
            }
        })

    },
    Friend: {
        screen: FriendNavigator,
        navigationOptions: () => ({
            tabBarLabel: language.friend.tab,
            tabBarIcon: ({ tintColor, focused }) => (
                <Image source={`${focused ? Images.friend_active : Images.friend_inactive}`} style={{ height: Matrics.Scale(22), width: Matrics.Scale(24), tintColor: tintColor }} />
            ),
        })
    },
    Other: {
        screen: SettingsNavigator,
        navigationOptions: () => ({
            tabBarLabel: language.other.Tab,
            tabBarIcon: ({ tintColor }) => (
                <Image source={Images.otherTab} style={{ height: Matrics.Scale(22), width: Matrics.Scale(24), tintColor: tintColor }} />
            ),

        })
    }
}, {
        tabBarOptions: {
            renderIndicator: () => null,
            activeTintColor: Colors.ICON_TINT_COLOR,
            inactiveTintColor: Colors.GREY,
            showIcon: true,
        }
    })


//MERGE TAB AND AUTH STACK
const MainAppNavigator = createStackNavigator({
    SplashScreen: { screen: SplashScreen },
    Auth: {
        screen: LoginNavigator,
        navigationOptions: {
            header: null
        }
    },
    Main: {
        screen: TabNavigator,
        navigationOptions: {
            header: null
        }
    },
})



//Created container to wrap AppNavigation
export default AppNavigator = createAppContainer(MainAppNavigator)