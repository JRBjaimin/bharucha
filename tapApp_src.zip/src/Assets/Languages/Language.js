import LocalizedStrings from 'react-native-localization';
import Japanese from './Japanese'
import English from './English'


let strings = new LocalizedStrings({
  japanese: Japanese,
  english: English,
});
export default strings;