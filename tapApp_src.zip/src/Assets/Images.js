const images = {

  //App Logo
  DowonArrow: require('../Assets/Images/arrow.png'),

  fakeDp : require('../Assets/Images/FakeDP.jpeg'),

  friendIcon:require('../Assets/Images/friendIcon.png'),

  //Login Screen Images
  Tape: require('../Assets/Images/TAPE.png'),


  // Registration Screen Images
  // Employee: require('../Assets/Images/Group2.png'),
  // StoreMaster: require('../Assets/Images/Group5.png'),
  // EmployeeSelect: require('../Assets/Images/Group4.png'),
  // StoreMasterSelect: require('../Assets/Images/Group3.png'),



  // Register Screen
  dpIcon: require('../Assets/Images/Group1.png'),
  UserNameIcon: require('../Assets/Images/Auth/icon_username.png'),
  EmailIcon: require('../Assets/Images/Auth/icon_Email.png'),
  PasswordIcon: require('../Assets/Images/Auth/icon_Password.png'),
  checkBoxUncheck: require('../Assets/Images/Auth/checkBoxUnchecked.png'),
  checkBoxCheck: require('../Assets/Images/Auth/checkBoxChecked.png'),


  // // Shope Manager Screen
  // Left: require('../Assets/Images/icon_Chevron_Left.png'),
  // Right: require('../Assets/Images/icon_Chevron_Right.png'),
  // Time: require('../Assets/Images/Vector_Smart_Object.png'),


  // //Tab Images
  talkTab: require('../Assets/Images/Tab_Icons/talk.png'),
  // scheduleTab: require('../Assets/Images/Tab_Icons/schedule.png'),
  friendTab: require('../Assets/Images/Tab_Icons/friend.png'),
  otherTab: require('../Assets/Images/Tab_Icons/other.png'),
  schedule_active :  require('../Assets/Images/Tab_Icons/schedule_Select.png'),
  schedule_inactive :require('../Assets/Images/Tab_Icons/schedule_Unselect.png'),
  friend_active :  require('../Assets/Images/Tab_Icons/other_select.png'),
  friend_inactive :require('../Assets/Images/Tab_Icons/other_unselect.png'),

 //TALK TAB
 camera: require('../Assets/Images/Talk_Tab/camera.png'),
 gallery: require('../Assets/Images/Talk_Tab/gallery.png'),
 location: require('../Assets/Images/Talk_Tab/location.png'),


  // //Schedule Screen
  Addicon: require('../Assets/Images/Addicon.png'),
  graterthen:require('../Assets/Images/graterthen.png'),
  MessageListIcon: require('../Assets/Images/MessageListIcon.png'),
  SelectTab: require('../Assets/Images/SelctTab.png'),
  UnselctedTab: require('../Assets/Images/UnselctedTab.png'),
  unselectStoreUser: require('../Assets/Images/unselectStoreUser.png'),
  selsctStoreUser: require('../Assets/Images/selsctStoreUser.png'),

   //Friend Tab Screen
  QR_icon: require('../Assets/Images/FriendTab/BarcodeIcon.png'),
  find_Id_icon: require('../Assets/Images/FriendTab/find_Id_icon.png'),
  friend_Req : require('../Assets/Images/FriendTab/sendFriendReq_icon.png'),
  search_icon : require('../Assets/Images/FriendTab/Search_icon.png'),
  edit_friend : require('../Assets/Images/FriendTab/edit_friend.png'),
  deleteFriend : require('../Assets/Images/FriendTab/deleteFriend.png'),
  changeTeam : require('../Assets/Images/FriendTab/changeTeam.png'),
  editNameIcon : require('../Assets/Images/FriendTab/editNameIcon.png'),
  ProfileBG : require('../Assets/Images/FriendTab/ProfileBG.png'),


  //OTHER TAB 
  profile_icon : require('../Assets/Images/OtherTab/profile_icon.png'),
  profileBG : require('../Assets/Images/OtherTab/BG.png'),
  ProfilePlaceHolder : require('../Assets/Images/OtherTab/iconProfile.png'),
  IdIcon : require('../Assets/Images/OtherTab/Id_icon.png'),
};

export default images;
  