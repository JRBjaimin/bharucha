import Colors from './GlobalColors';
import Matrics from './Matrics';
import Images from './Images';
import Fonts from './Fonts';

export { Matrics, Colors, Images, Fonts } 