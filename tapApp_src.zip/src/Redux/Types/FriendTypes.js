
//--->>Types for Friend Tab ---->>>

//=====================Search Data Requesting=================//

export const SEARCH_LIST_REQUESTING = 'SEARCH_LIST_REQUESTING';
export const SEARCH_LIST_FAIL = 'SEARCH_LIST_FAIL';
export const SEARCH_LIST_SUCCESS = 'SEARCH_LIST_SUCCESS';


//=====================ADD FRIEND Types=================//

export const ADD_FRIEND_REQUESTING = 'ADD_FRIEND_REQUESTING';
export const ADD_FRIEND_FAIL = 'ADD_FRIEND_FAIL';
export const ADD_FRIEND_SUCCESS = 'ADD_FRIEND_SUCCESS';

//=====================GET FRIENDS LIST=================//

export const GET_FRIEND_LIST_REQUESTING = 'GET_FRIEND_LIST_REQUESTING';
export const GET_FRIEND_LIST_FAIL = 'GET_FRIEND_LIST_FAIL';
export const GET_FRIEND_LIST_SUCCESS = 'GET_FRIEND_LIST_SUCCESS';


//=====================CHANGE USER NAME ALIAS=================//

export const CHANGE_USER_ALIAS_REQUESTING = 'CHANGE_USER_ALIAS_REQUESTING';
export const CHANGE_USER_ALIAS_FAIL = 'CHANGE_USER_ALIAS_FAIL';
export const CHANGE_USER_ALIAS_SUCCESS = 'CHANGE_USER_ALIAS_SUCCESS';

//=====================REMOVE SINGLE FRIEND =================//

export const REMOVE_FRIEND_REQUESTING = 'REMOVE_FRIEND_REQUESTING';
export const REMOVE_FRIEND_FAIL = 'REMOVE_FRIEND_FAIL';
export const REMOVE_FRIEND_SUCCESS = 'REMOVE_FRIEND_SUCCESS';
