
//--->>Types for Uploading Image---->>>

export const ADD_MEDIA_REQUESTING = 'ADD_MEDIA_REQUESTING';
export const ADD_MEDIA_FAIL = 'ADD_MEDIA_FAIL';
export const ADD_MEDIA_SUCCESS = 'ADD_MEDIA_SUCCESS';


