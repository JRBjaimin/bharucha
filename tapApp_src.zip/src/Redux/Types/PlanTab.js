//--->>Types for Create Todo---->>>
export const CREATETODO_REQUESTING = 'CREATETODO_REQUESTING';
export const CREATETODO_FAIL = 'CREATETODO_FAIL';
export const CREATETODO_SUCCESS = 'CREATETODO_SUCCESS';

//--->>Types for Edit Todo---->>>
export const EDITTODO_REQUESTING = 'EDITTODO_REQUESTING';
export const EDITTODO_FAIL       = 'EDITTODO_FAIL';
export const EDITTODO_SUCCESS    = 'EDITTODO_SUCCESS';
