import {
    GETSTOREEMPLOYEE_SUCCESS,
    GETSTOREEMPLOYEE_FAIL
} from '@Types/MessageTab'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case GETSTOREEMPLOYEE_SUCCESS:
            return { getStoreEmployeeSuccess: true, data: action.payload };

        case GETSTOREEMPLOYEE_FAIL:
            return { getStoreEmployeeFail: true, error: action.payload };

        default:
            return state;
    };
};
