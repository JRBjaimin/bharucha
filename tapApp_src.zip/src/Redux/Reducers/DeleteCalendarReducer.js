import {
    DELETECALENDAR_FAIL,    
    DELETECALENDAR_SUCCESS     
} from '@Types/CalendarTab'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case DELETECALENDAR_SUCCESS:
            return { deleteSuccess: true, data: action.payload };

        case DELETECALENDAR_FAIL:
            return { deleteFail: true, error: action.payload };

        default:
            return state;
    };
};
