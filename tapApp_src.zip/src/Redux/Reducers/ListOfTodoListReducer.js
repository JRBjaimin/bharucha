import {
    LISTOFTODO_SUCCESS,
    LISTOFTODO_FAIL,
} from '@Types/ScheduleTypes'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case LISTOFTODO_SUCCESS:
            return { todoListSuccess: true, data: action.payload };

        case LISTOFTODO_FAIL:
            return { todoListFail: true, error: action.payload };

        default:
            return state;
    };
};
