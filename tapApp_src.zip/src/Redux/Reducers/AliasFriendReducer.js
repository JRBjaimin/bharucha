import {
    CHANGE_USER_ALIAS_FAIL,
    CHANGE_USER_ALIAS_SUCCESS
} from '@Types/FriendTypes'



const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case CHANGE_USER_ALIAS_SUCCESS:
            return { changeFriendAliasSuccess: true, data: action.payload };

        case CHANGE_USER_ALIAS_FAIL:
            return { changeFriendAliasFail: true, error: action.payload };
        default:
            return state;
    };
};