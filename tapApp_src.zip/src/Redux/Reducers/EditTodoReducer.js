import {
    EDITTODO_SUCCESS,
    EDITTODO_FAIL,
} from '@Types/PlanTab'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case EDITTODO_SUCCESS:
            return { editTodoSuccess: true, data: action.payload };

        case EDITTODO_FAIL:
            return { editTodoFail: true, error: action.payload };

        default:
            return state;
    };
};
