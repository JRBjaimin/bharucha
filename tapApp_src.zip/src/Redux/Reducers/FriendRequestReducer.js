import {
    ADD_FRIEND_FAIL,
    ADD_FRIEND_SUCCESS
} from '@Types/FriendTypes'



const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case ADD_FRIEND_SUCCESS:
            return { addFriendSuccess: true, data: action.payload };

        case ADD_FRIEND_FAIL:
            return { addFriendFail: true, error: action.payload };
        default:
            return state;
    };
};