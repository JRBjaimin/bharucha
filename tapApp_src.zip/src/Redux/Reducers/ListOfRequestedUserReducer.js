import {
    LISTREQUESTEDUSER_SUCCESS,
    LISTREQUESTEDUSER_FAIL,
} from '@Types/AcceptRejectMessageType'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case LISTREQUESTEDUSER_SUCCESS:
            return { listRequestedUserSuccess: true, data: action.payload };

        case LISTREQUESTEDUSER_FAIL:
            return { listRequestedUserFail: true, error: action.payload };

        default:
            return state;
    };
};
