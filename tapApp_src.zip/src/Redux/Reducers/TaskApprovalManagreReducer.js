import {
    TASKAPPROVALMANAGER_SUCCESS,
    TASKAPPROVALMANAGER_FAIL,
} from '@Types/AcceptRejectMessageType'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case TASKAPPROVALMANAGER_SUCCESS:
            return { taskApproveSuccess: true, data: action.payload };

        case TASKAPPROVALMANAGER_FAIL:
            return { taskApproveFail: true, error: action.payload };

        default:
            return state;
    };
};

