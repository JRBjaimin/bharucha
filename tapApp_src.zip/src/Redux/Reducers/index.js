//Libraries
import { combineReducers } from 'redux';

//Assets
import { LOGOUT_USER_SUCCESS } from '../Types/AuthTypes';
import AuthReducer from './AuthReducer';
import TokenReducer from './TokenReducer';
import SettingsReducer from './SettingsReducer';
import LogoutReducer from './LogoutReducer';
// by jsbn.......
import CalendarTabReducer from './CalendarTabReducer';
import ScheduleReducer from './ScheduleReducer';
import ListOfMesageAndTodoListReducer from './ListOfMesageAndTodoListReducer';
import ListOfMesageReducer from './ListOfMesageReducer';
import ListOfTodoListReducer from './ListOfTodoListReducer';
import PlanTabReducer from './PlanTabReducer';
import FriendReducer from './FriendReducer';
import FriendRequestReducer from './FriendRequestReducer';
import MyFriendListReducer from './MyFriendListReducer';
import AliasFriendReducer from './AliasFriendReducer';
import AcceptRejectMessageReducer from './AcceptRejectMessageReducer';
import TaskApprovalManagreReducer from './TaskApprovalManagreReducer';
import ListOfRequestedUserReducer from './ListOfRequestedUserReducer';
import MessageTabReducer from './MessageTabReducer';
import GetEmployeeStoreReducer from './GetEmployeeStoreReducer';
import GetStoreEmployeeReducer from './GetStoreEmployeeReducer';
import RemoveFriendReducer from './RemoveFriendReducer';
import ChangePasswordReducer from './ChangePasswordReducer';

import DeleteCalendarReducer from './DeleteCalendarReducer';
import CopyCalendarReducer from './CopyCalendarReducer';
import EditCalendarReducer from './EditCalendarReducer';
import ShareCalendarReducer from './ShareCalendarReducer';
import EditTodoReducer from './EditTodoReducer';
import TalkReducer from './TalkReducer' 

let appReducer = combineReducers({
  Auth: AuthReducer,
  Encrypt: TokenReducer,
  Settings: SettingsReducer,
  Logout: LogoutReducer,
  // by j....
  CalendarTab: CalendarTabReducer,
  Schedule: ScheduleReducer,
  ListOfMesageAndTodoList: ListOfMesageAndTodoListReducer,
  ListOfMesage: ListOfMesageReducer,
  ListOfTodoList: ListOfTodoListReducer,
  PlanTab: PlanTabReducer,
  AcceptRejectMessage: AcceptRejectMessageReducer,
  TaskApprovalManagre: TaskApprovalManagreReducer,
  ListOfRequestedUser: ListOfRequestedUserReducer,
  MessageTab: MessageTabReducer,
  GetEmployeeStore: GetEmployeeStoreReducer,
  GetStoreEmployee: GetStoreEmployeeReducer,
  DeleteCalendar: DeleteCalendarReducer,
  CopyCalendar: CopyCalendarReducer,
  EditCalendar: EditCalendarReducer,
  ShareCalendar: ShareCalendarReducer,
  EditTodo: EditTodoReducer,

  Friend: FriendReducer,
  FriendRequest: FriendRequestReducer,
  myFriendList: MyFriendListReducer,
  AliasFriend: AliasFriendReducer,
  RemoveFriend : RemoveFriendReducer,
  changePassword : ChangePasswordReducer,
  TalkReducer : TalkReducer
});

const rootReducer = (state, action) => {
  if (action.type === LOGOUT_USER_SUCCESS) {
    state = undefined;
  }

  return appReducer(state, action)
}

export default rootReducer;
