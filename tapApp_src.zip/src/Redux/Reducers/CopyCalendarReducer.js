import {
    COPYCALENDAR_FAIL,
    COPYCALENDAR_SUCCESS,
} from '@Types/CalendarTab'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case COPYCALENDAR_SUCCESS:
            return { copySuccess: true, data: action.payload };

        case COPYCALENDAR_FAIL:
            return { copyFail: true, error: action.payload };

        default:
            return state;
    };
};
