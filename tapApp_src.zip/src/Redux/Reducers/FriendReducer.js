import {
    SEARCH_LIST_FAIL,
    SEARCH_LIST_SUCCESS,
    ADD_FRIEND_FAIL,
    ADD_FRIEND_SUCCESS,
 
} from '@Types/FriendTypes'



const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case SEARCH_LIST_SUCCESS:
            return {  searchListSuccess: true, data: action.payload };

        case SEARCH_LIST_FAIL:
            return { searchListFail: true, error: action.payload };

        case ADD_FRIEND_SUCCESS:
            return {  addFriendSuccess: true, data: action.payload };

        case ADD_FRIEND_FAIL:
            return {  addFriendFail: true, error: action.payload };


        default:
            return state;
    };

};