import {
    GET_FRIEND_LIST_SUCCESS,
    GET_FRIEND_LIST_FAIL,
} from '@Types/FriendTypes'



const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case GET_FRIEND_LIST_SUCCESS:
            return { getFriendListSuccess: true, data: action.payload };

        case GET_FRIEND_LIST_FAIL:
            return { getFriendListFail: true, error: action.payload };
        default:
            return state;
    };
};