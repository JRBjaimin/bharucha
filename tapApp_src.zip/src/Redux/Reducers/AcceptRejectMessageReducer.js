import {
    ACCEPTREJECTMESSAGE_FAIL,
    ACCEPTREJECTMESSAGE_SUCCESS
} from '@Types/AcceptRejectMessageType'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case ACCEPTREJECTMESSAGE_SUCCESS:
            return { acceptRejectMessageSuccess: true, data: action.payload };

        case ACCEPTREJECTMESSAGE_FAIL:
            return { acceptRejectMessageFail: true, error: action.payload };

        default:
            return state;
    };
};

