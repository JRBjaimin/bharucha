import {
    GETEMPLOYEESTORE_SUCCESS,
    GETEMPLOYEESTORE_FAIL,
} from '@Types/MessageTab'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case GETEMPLOYEESTORE_SUCCESS:
            return { getemployeeStoreSuccess: true, data: action.payload };

        case GETEMPLOYEESTORE_FAIL:
            return { getemployeeStoreFail: true, error: action.payload };

        default:
            return state;
    };
};
