import {
    ENCRYPT_TOKEN_FAIL,
    ENCRYPT_TOKEN_SUCCESS,
} from '@Types/AuthTypes'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case ENCRYPT_TOKEN_SUCCESS:
            return { encryptSuccess: true, data: action.payload };

        case ENCRYPT_TOKEN_FAIL:
            return { encryptTokenFail: true, error: action.payload };

        default:
            return state;
    }
}