import {
    LISTOFALLMESSAGEANDTODO_SUCCESS,
    LISTOFALLMESSAGEANDTODO_FAIL,
} from '@Types/ScheduleTypes'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case LISTOFALLMESSAGEANDTODO_SUCCESS:
            return { allTodoMessageListSuccess: true, data: action.payload };

        case LISTOFALLMESSAGEANDTODO_FAIL:
            return { allTodoMessageListFail: true, error: action.payload };

        default:
            return state;
    };
};
