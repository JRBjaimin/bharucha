import {
    ADD_MEDIA_FAIL,
    ADD_MEDIA_SUCCESS
} from '@Types/TalkTypes'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case ADD_MEDIA_SUCCESS:
            return { addMediaSuccess: true, data: action.payload };

        case ADD_MEDIA_FAIL:
            return { addMediaFail: true, error: action.payload };

        default:
            return state;
    };
};
