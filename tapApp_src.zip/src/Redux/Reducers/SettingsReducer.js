import {
    CHANGE_PROFILE_PICTURE_FAIL,
    CHANGE_PROFILE_PICTURE_SUCCESS,
    CHANGE_USERNAME_FAIL,
    CHANGE_USERNAME_SUCCESS,
    CHANGE_PASSWORD_FAIL,
    CHANGE_PASSWORD_SUCCESS

} from '@Types/SettingsTypes'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case CHANGE_PROFILE_PICTURE_SUCCESS:
            return { changeProfileSuccess: true, data: action.payload };

        case CHANGE_PROFILE_PICTURE_FAIL:
            return { changeProfileFail: true, error: action.payload };

        case CHANGE_USERNAME_SUCCESS:
            return { changeUserNameSuccess: true, data: action.payload };

        case CHANGE_USERNAME_FAIL:
            return { changeUserNameFail: true, error: action.payload };

        case CHANGE_PASSWORD_SUCCESS:
            return { changePasswordSuccess: true, data: action.payload };

        case CHANGE_PASSWORD_FAIL:
            return { changePasswordFail: true, error: action.payload };

        default:
            return state;
    };
};