import {
    ALLCALENDARLIST_SUCCESS,
    ALLCALENDARLIST_FAIL,
} from '@Types/ScheduleTypes'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case ALLCALENDARLIST_SUCCESS:
            return { calendarListSuccess: true, data: action.payload };

        case ALLCALENDARLIST_FAIL:
            return { calendarListFail: true, error: action.payload };
    
        default:
            return state;
    };
};
