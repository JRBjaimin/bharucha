import {    
    CREATEMESSAGE_SUCCESS,
    CREATEMESSAGE_FAIL,
} from '@Types/MessageTab'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case CREATEMESSAGE_SUCCESS:
            return { createMessageSuccess: true, data: action.payload };

        case CREATEMESSAGE_FAIL:
            return { creataMessageFail: true, error: action.payload };

        default:
            return state;
    };
};