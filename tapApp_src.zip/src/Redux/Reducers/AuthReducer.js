import {
    PHONE_VERIFICATION_FAIL,
    PHONE_VERIFICATION_SUCCESS,
    CHECK_OTP__FAIL,
    CHECK_OTP__SUCCESS,
    LOGIN_USER_SUCCESS,
    LOGIN_USER_FAIL,
    FORGOT_PASSWORD_FAIL,
    FORGOT_PASSWORD_SUCCESS,
    GET_REFRESH_TOKEN_FAIL,
    GET_REFRESH_TOKEN_SUCCESS,
    REGISTER_USER_FAIL,
    REGISTER_USER_SUCCESS,
    PHONE_NUMBER_CHECK_FAIL,
    PHONE_NUMBER_CHECK_SUCCESS
} from '@Types/AuthTypes'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case GET_REFRESH_TOKEN_SUCCESS:
            return { refreshTokenSuccess: true, data: action.payload };

        case GET_REFRESH_TOKEN_FAIL:
            return { refreshTokenFail: true, error: action.payload };

        case PHONE_VERIFICATION_SUCCESS:
            return { verificationSuccess: true, data: action.payload };

        case PHONE_VERIFICATION_FAIL:
            return { verificationFail: true, error: action.payload };

        case CHECK_OTP__SUCCESS:
            return { OTPSuccess: true, data: action.payload };

        case CHECK_OTP__FAIL:
            return { OTPFail: true, error: action.payload };

        case LOGIN_USER_SUCCESS:
            return { loginSuccess: true, data: action.payload };

        case LOGIN_USER_FAIL:
            return { loginFail: true, error: action.payload };

        case REGISTER_USER_SUCCESS:
            return { registerSuccess: true, data: action.payload };

        case REGISTER_USER_FAIL:
            return { registerFail: true, error: action.payload };

        case FORGOT_PASSWORD_SUCCESS:
            return { forgotPasswordSuccess: true, data: action.payload };

        case FORGOT_PASSWORD_FAIL:
            return { forgotPasswordFail: true, error: action.payload };

        case PHONE_NUMBER_CHECK_SUCCESS:
            return { phoneNumberCheckSuccess: true, data: action.payload };

        case PHONE_NUMBER_CHECK_FAIL:
            return { phoneNumberCheckFail: true, error: action.payload };
        

        default:
            return state;
    };
};