import {
    CREATETODO_SUCCESS,
    CREATETODO_FAIL,
} from '@Types/PlanTab'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case CREATETODO_SUCCESS:
            return { createTodoSuccess: true, data: action.payload };

        case CREATETODO_FAIL:
            return { createTodoFail: true, error: action.payload };

        default:
            return state;
    };
};
