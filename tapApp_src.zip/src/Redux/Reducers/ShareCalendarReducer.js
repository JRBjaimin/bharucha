import {
    SHARECALENDAR_FAIL,
    SHARECALENDAR_SUCCESS,
} from '@Types/CalendarTab'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case SHARECALENDAR_SUCCESS:
            return { shareSuccess: true, data: action.payload };

        case SHARECALENDAR_FAIL:
            return { shareFail: true, error: action.payload };

        default:
            return state;
    };
};
