import {
    CREATECALENDAR_FAIL,
    CREATECALENDAR_SUCCESS
} from '@Types/CalendarTab'

const INITIAL_STATE = {};

export default (state = INITIAL_STATE, action) => {
    console.log('*****************REDUCER')
    switch (action.type) {

        case CREATECALENDAR_SUCCESS:
            return { calendarSuccess: true, data: action.payload };

        case CREATECALENDAR_FAIL:
            return { calendarFail: true, error: action.payload };

        default:
            return state;
    };
};