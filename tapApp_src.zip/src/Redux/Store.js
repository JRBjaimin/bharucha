
//LIBRARIES
import { applyMiddleware, createStore, compose } from 'redux';
import createSagaMiddleware from 'redux-saga';
import logger from 'redux-logger'
import { persistStore, persistReducer } from 'redux-persist'
import storage from 'redux-persist/lib/storage'
//ASSETS
import rootSaga from './Sagas';
import rootReducer from './Reducers'


const persistConfig = {
    key: 'root',
    storage,
  }

// Middleware
const sagaMiddleware = createSagaMiddleware();

const middleware = [sagaMiddleware, logger];


const persistedReducer = persistReducer(persistConfig, rootReducer)

  export const Store =  createStore(
    persistedReducer,
    compose(
        (applyMiddleware(...middleware))
    ));


export const Persistor =  persistStore(Store)
 sagaMiddleware.run(rootSaga);