//LIBRARIES
import { put, call, all, takeEvery } from 'redux-saga/effects';
import AsyncStorage from '@react-native-community/async-storage';

//ASSETS
import {
    PHONE_VERIFICATION_REQUESTING,
    PHONE_VERIFICATION_FAIL,
    PHONE_VERIFICATION_SUCCESS,
    CHECK_OTP_REQUESTING,
    CHECK_OTP__FAIL,
    CHECK_OTP__SUCCESS,
    LOGIN_USER_SUCCESS,
    LOGIN_USER_REQUESTING,
    LOGIN_USER_FAIL,
    FORGOT_PASSWORD_REQUESTING,
    FORGOT_PASSWORD_FAIL,
    LOGOUT_USER_REQUESTING,
    LOGOUT_USER_FAIL,
    LOGOUT_USER_SUCCESS,
    FORGOT_PASSWORD_SUCCESS,
    GET_REFRESH_TOKEN_FAIL,
    GET_REFRESH_TOKEN_SUCCESS,
    GET_REFRESH_TOKEN_REQUESTING,
    REGISTER_USER_REQUESTING,
    REGISTER_USER_FAIL,
    REGISTER_USER_SUCCESS,
    ENCRYPT_TOKEN_FAIL,
    ENCRYPT_TOKEN_SUCCESS,
    ENCRYPT_TOKEN_REQUESTING,
    PHONE_NUMBER_CHECK_REQUESTING,
    PHONE_NUMBER_CHECK_FAIL,
    PHONE_NUMBER_CHECK_SUCCESS

} from '@Types/AuthTypes'


// import Api from '../../Config/Api';
import Api from '../../Config/Api'


/************************ getRefresh Token Saga ****************************/

export const watchrefreshTokenAsync = function* watchrefreshTokenAsync({ params }) {
    console.log(params, 'saga for verification')
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.getRefreshToken, params)
        console.log(response, 'refreshTok====')
        yield put({ type: GET_REFRESH_TOKEN_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: GET_REFRESH_TOKEN_FAIL, payload: e });
    }
}


/************************ Encrypt Token Saga ****************************/

export const watchEncryptTokenAsync = function* watchEncryptTokenAsync({ params }) {
    console.log(params, 'saga for encrypt')
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.encryptToken, params)
        console.log(response)
        yield put({ type: ENCRYPT_TOKEN_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: ENCRYPT_TOKEN_FAIL, payload: e });
    }
}



/************************ Phone Number Verification function ****************************/

export const watchPhoneVerificationAsync = function* watchPhoneVerificationAsync({ params }) {
    console.log(params, 'saga for verification')
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.registerPhoneNumber, params)
        console.log(response)
        yield put({ type: PHONE_VERIFICATION_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: PHONE_VERIFICATION_FAIL, payload: e });
    }
}


/************************ Check if Phone Number already exists function ****************************/

export const watchPhoneNumberCheckAsync = function* watchPhoneNumberCheckAsync({ params }) {
    console.log(params, 'saga for verification')
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.phoneNumberCheck, params)
        console.log(response)
        yield put({ type: PHONE_NUMBER_CHECK_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: PHONE_NUMBER_CHECK_FAIL, payload: e });
    }
}



/************************ OTP Verification function ****************************/

export const watchOTPVerificationAsync = function* watchOTPVerificationAsync({ params }) {
    console.log(params, 'saga for OTP')
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.verifyOTPNumber, params)
        console.log(response)
        yield put({ type: CHECK_OTP__SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: CHECK_OTP__FAIL, payload: e });
    }
}

/************************ Login function ****************************/

export const watchLoginAsync = function* watchLoginAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.userLogin, params)
        console.log(response)
        yield put({ type: LOGIN_USER_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: LOGIN_USER_FAIL, payload: e });
    }
}



/************************ Registration function ****************************/

export const watchRegisterAsync = function* watchRegisterAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.userRegister, params)
        console.log(response)
        yield put({ type: REGISTER_USER_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: REGISTER_USER_FAIL, payload: e });
    }
}

/************************ Forgot Password function ****************************/

export const forgotPasswordAsync = function* forgotPasswordAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.forgotPassword, params)
        console.log(response)
        yield put({ type: FORGOT_PASSWORD_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: FORGOT_PASSWORD_FAIL, payload: e });
    }
}


/************************ Logout Function ****************************/

export const logoutAsync = function* logoutAsync({ params }) {
    console.log(params, 'LOGOUT REQUEST PARAMS------------------_>>>>>>>>>>')
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.logoutUser, params)
        console.log(response)
        yield AsyncStorage.removeItem('persist: Auth')
        yield AsyncStorage.clear()
        yield put({ type: LOGOUT_USER_SUCCESS, payload: response });

    }
    catch (e) {
        yield put({ type: LOGOUT_USER_FAIL, payload: e });
    }
}



const watchAuth = function* watchAuth() { 
    yield takeEvery(ENCRYPT_TOKEN_REQUESTING, watchEncryptTokenAsync),
        yield takeEvery(REGISTER_USER_REQUESTING, watchRegisterAsync),
        yield takeEvery(GET_REFRESH_TOKEN_REQUESTING, watchrefreshTokenAsync),
        yield takeEvery(PHONE_NUMBER_CHECK_REQUESTING, watchPhoneNumberCheckAsync),
        yield takeEvery(PHONE_VERIFICATION_REQUESTING, watchPhoneVerificationAsync),
        yield takeEvery(CHECK_OTP_REQUESTING, watchOTPVerificationAsync),
        yield takeEvery(LOGIN_USER_REQUESTING, watchLoginAsync),
        yield takeEvery(FORGOT_PASSWORD_REQUESTING, forgotPasswordAsync),
        yield takeEvery(LOGOUT_USER_REQUESTING, logoutAsync)
}

export default watchAuth;