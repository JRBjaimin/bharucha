//LIBRARIES
import { put, call, takeEvery } from 'redux-saga/effects';

//ASSETS
import {
    ACCEPTREJECTMESSAGE_REQUESTING,
    ACCEPTREJECTMESSAGE_SUCCESS,
    ACCEPTREJECTMESSAGE_FAIL,
    
    TASKAPPROVALMANAGER_REQUESTING,
    TASKAPPROVALMANAGER_SUCCESS,
    TASKAPPROVALMANAGER_FAIL,
    
    LISTREQUESTEDUSER_REQUESTING,
    LISTREQUESTEDUSER_SUCCESS,
    LISTREQUESTEDUSER_FAIL,
} from '@Types/AcceptRejectMessageType'

import Api from '../../Config/Api';


/************************ Create AcceptRejectMessage function ****************************/

export const watchAcceptRejectMessageAsync = function* watchAcceptRejectMessageAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------AcceptRejectMessage SAGA CALLING')
        const response = yield call(Api.AcceptRejectMessage, params)
        console.log(response)
        yield put({ type: ACCEPTREJECTMESSAGE_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: ACCEPTREJECTMESSAGE_FAIL, payload: e });
    }
}

/************************ Task Approval Manager function ****************************/

export const watchTaskApprovalManagerAsync = function* watchTaskApprovalManagerAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------TaskApprovalManager SAGA CALLING')
        const response = yield call(Api.TaskApprovalManager, params)
        console.log(response)
        yield put({ type: TASKAPPROVALMANAGER_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: TASKAPPROVALMANAGER_FAIL, payload: e });
    }
}

/************************ List of Requested user  function ****************************/

export const watchListRequestedUserAsync = function* watchListRequestedUserAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------ListRequestedUser SAGA CALLING')
        const response = yield call(Api.ListRequestedUser, params)
        console.log(response)
        yield put({ type: LISTREQUESTEDUSER_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: LISTREQUESTEDUSER_FAIL, payload: e });
    }
}

const watchwatchAcceptRejectMessage = function* watchwatchAcceptRejectMessage() {
    yield takeEvery(ACCEPTREJECTMESSAGE_REQUESTING, watchAcceptRejectMessageAsync);
    yield takeEvery(TASKAPPROVALMANAGER_REQUESTING, watchTaskApprovalManagerAsync);
    yield takeEvery(LISTREQUESTEDUSER_REQUESTING, watchListRequestedUserAsync);
}

export default watchwatchAcceptRejectMessage;