//LIBRARIES
import { put, call, takeEvery } from 'redux-saga/effects';

//ASSETS
import {
    ALLCALENDARLIST_REQUESTING,
    ALLCALENDARLIST_SUCCESS,
    ALLCALENDARLIST_FAIL,

    LISTOFMESSAGE_REQUESTING,
    LISTOFMESSAGE_SUCCESS,
    LISTOFMESSAGE_FAIL,

    LISTOFTODO_REQUESTING,
    LISTOFTODO_SUCCESS,
    LISTOFTODO_FAIL,

    LISTOFALLMESSAGEANDTODO_REQUESTING,
    LISTOFALLMESSAGEANDTODO_SUCCESS,
    LISTOFALLMESSAGEANDTODO_FAIL,
} from '@Types/ScheduleTypes'
import Api from '../../Config/Api';


/************************ All Calendar List function ****************************/

export const watchAllCalendarListAsync = function* watchAllCalendarListAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------GetAllCalender SAGA CALLING')
        const response = yield call(Api.GetAllCalender, params)
        console.log(response)
        yield put({ type: ALLCALENDARLIST_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: ALLCALENDARLIST_FAIL, payload: e });
    }
}

/************************ List of Message function ****************************/

export const watchListOfMessageAsync = function* watchListOfMessageAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------ListOfMessages SAGA CALLING')
        const response = yield call(Api.ListOfMessages, params)
        console.log(response)
        yield put({ type: LISTOFMESSAGE_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: LISTOFMESSAGE_FAIL, payload: e });
    }
}

/************************ List of Todo function ****************************/
export const watchListOfTodoAsync = function* watchListOfTodoAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------ListOfTodoList SAGA CALLING')
        const response = yield call(Api.ListOfTodoList, params)
        console.log(response)
        yield put({ type: LISTOFTODO_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: LISTOFTODO_FAIL, payload: e });
    }
}

/************************ List Of Todo Message function ****************************/
export const watchListOfTodoMessageListAsync = function* watchListOfTodoMessageListAsync({ params }) {
    console.log(params)
    try { 
        console.log('---------------ListOfTodoMessageList SAGA CALLING')
        const response = yield call(Api.ListOfTodoMessageList, params)
        console.log(response)
        yield put({ type: LISTOFALLMESSAGEANDTODO_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: LISTOFALLMESSAGEANDTODO_FAIL, payload: e });
    }
}

const watchSchedule = function* watchSchedule() {
    yield takeEvery(ALLCALENDARLIST_REQUESTING, watchAllCalendarListAsync);
    yield takeEvery(LISTOFMESSAGE_REQUESTING, watchListOfMessageAsync);
    yield takeEvery(LISTOFTODO_REQUESTING, watchListOfTodoAsync);
    yield takeEvery(LISTOFALLMESSAGEANDTODO_REQUESTING, watchListOfTodoMessageListAsync);
}

export default watchSchedule;

