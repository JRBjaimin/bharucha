//LIBRARIES
import { put, call, takeEvery } from 'redux-saga/effects';

//ASSETS
import {
    CREATECALENDAR_REQUESTING,
    CREATECALENDAR_SUCCESS,
    CREATECALENDAR_FAIL,

    DELETECALENDAR_REQUESTING,
    DELETECALENDAR_SUCCESS,
    DELETECALENDAR_FAIL,

    COPYCALENDAR_REQUESTING,
    COPYCALENDAR_SUCCESS,
    COPYCALENDAR_FAIL,

    EDITCALENDAR_REQUESTING,
    EDITCALENDAR_SUCCESS,
    EDITCALENDAR_FAIL,

    SHARECALENDAR_REQUESTING,
    SHARECALENDAR_SUCCESS,
    SHARECALENDAR_FAIL,
} from '@Types/CalendarTab'

import Api from '../../Config/Api';

/************************ Create Calendar function ****************************/

export const watchCreateCalendarAsync = function* watchCreateCalendarAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------CreateCalender SAGA CALLING')
        const response = yield call(Api.CreateCalender, params)
        console.log(response)
        yield put({ type: CREATECALENDAR_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: CREATECALENDAR_FAIL, payload: e });
    }
}

/************************ Delete Calendar function ****************************/
export const watchDeleteCalendarAsync = function* watchDeleteCalendarAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------watchDeleteCalendarAsync SAGA CALLING')
        const response = yield call(Api.DeleteCalender, params)
        console.log(response)
        yield put({ type: DELETECALENDAR_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: DELETECALENDAR_FAIL, payload: e });
    }
}

/************************ Copy Calendar function ****************************/
export const watchCopyCalenderAsync = function* watchCopyCalenderAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------CopyCalender SAGA CALLING')
        const response = yield call(Api.CopyCalender, params)
        console.log(response)
        yield put({ type: COPYCALENDAR_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: COPYCALENDAR_FAIL, payload: e });
    }
}

/************************ Edit Calendar function ****************************/
export const watchEditCalenderAsync = function* watchEditCalenderAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------EditCalender SAGA CALLING')
        const response = yield call(Api.EditCalender, params)
        console.log(response)
        yield put({ type: EDITCALENDAR_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: EDITCALENDAR_FAIL, payload: e });
    }
}

/************************ Share Calendar function ****************************/
export const watchShareCalenderAsync = function* watchShareCalenderAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------ShareCalender SAGA CALLING')
        const response = yield call(Api.ShareCalender, params)
        console.log(response)
        yield put({ type: SHARECALENDAR_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: SHARECALENDAR_FAIL, payload: e });
    }
}


const watchCalendarTab = function* watchCalendarTab() {
    yield takeEvery(CREATECALENDAR_REQUESTING, watchCreateCalendarAsync);
    yield takeEvery(DELETECALENDAR_REQUESTING, watchDeleteCalendarAsync);
    yield takeEvery(COPYCALENDAR_REQUESTING, watchCopyCalenderAsync);
    yield takeEvery(EDITCALENDAR_REQUESTING, watchEditCalenderAsync);
    yield takeEvery(SHARECALENDAR_REQUESTING, watchShareCalenderAsync);
}

export default watchCalendarTab;