//LIBRARIES
import { put, call, takeEvery } from 'redux-saga/effects';

//ASSETS
import {
    CREATETODO_REQUESTING,
    CREATETODO_SUCCESS,
    CREATETODO_FAIL,

    EDITTODO_REQUESTING,
    EDITTODO_SUCCESS,
    EDITTODO_FAIL,
} from '@Types/PlanTab'

import Api from '../../Config/Api';

/************************ Create Todo function ****************************/
export const watchCreateTodoAsync = function* watchCreateTodoAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------CreateTodoListForStore SAGA CALLING')
        const response = yield call(Api.CreateTodoListForStore, params)
        console.log(response)
        yield put({ type: CREATETODO_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: CREATETODO_FAIL, payload: e });
    }
}

/************************ Edit Todo function ****************************/
export const watchEditTodoAsync = function* watchEditTodoAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------EditTodoList SAGA CALLING')
        const response = yield call(Api.EditTodoList, params)
        console.log(response)
        yield put({ type: EDITTODO_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: EDITTODO_FAIL, payload: e });
    }
}

const watchPlanTab = function* watchPlanTab() {
    yield takeEvery(CREATETODO_REQUESTING, watchCreateTodoAsync);
    yield takeEvery(EDITTODO_REQUESTING, watchEditTodoAsync);
}

export default watchPlanTab;