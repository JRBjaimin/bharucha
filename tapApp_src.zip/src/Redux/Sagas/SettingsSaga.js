//LIBRARIES
import { put, call, all, takeEvery } from 'redux-saga/effects';

//ASSETS
import {
    CHANGE_PROFILE_PICTURE_FAIL,
    CHANGE_PROFILE_PICTURE_SUCCESS,
    CHANGE_PROFILE_PICTURE_REQUESTING,
    CHANGE_USERNAME_REQUESTING,
    CHANGE_USERNAME_FAIL,
    CHANGE_USERNAME_SUCCESS,
    CHANGE_PASSWORD_REQUESTING,
    CHANGE_PASSWORD_FAIL,
    CHANGE_PASSWORD_SUCCESS
} from '@Types/SettingsTypes'

import Api from '../../Config/Api';


/************************ Change profile function ****************************/

export const watchChangeProfileListAsync = function* watchChangeProfileListAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.changeProfilePic, params)
        console.log(response)
        yield put({ type: CHANGE_PROFILE_PICTURE_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: CHANGE_PROFILE_PICTURE_FAIL, payload: e });
    }
}

/************************ change UserName function ****************************/

export const watchChangeUserNameAsync = function* watchChangeUserNameAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.changeUserName, params)
        console.log(response)
        yield put({ type: CHANGE_USERNAME_SUCCESS, payload: response });
    }
    catch (e) {
        // alert(e)
        yield put({ type: CHANGE_USERNAME_FAIL, payload: e });
    }
}


/************************ change UserName function ****************************/

export const watchChangePasswordAsync = function* watchChangePasswordAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.changePassword, params)
        console.log(response)
        yield put({ type: CHANGE_PASSWORD_SUCCESS, payload: response });
    }
    catch (e) {
        // alert(e)
        yield put({ type: CHANGE_PASSWORD_FAIL, payload: e });
    }
}


const watchSettings = function* watchSettings() {
    yield takeEvery(CHANGE_PROFILE_PICTURE_REQUESTING, watchChangeProfileListAsync)
    yield takeEvery(CHANGE_USERNAME_REQUESTING, watchChangeUserNameAsync)
    yield takeEvery(CHANGE_PASSWORD_REQUESTING, watchChangePasswordAsync)

}


export default watchSettings;