//LIBRARIES
import { put, call, takeEvery } from 'redux-saga/effects';

//ASSETS
import {
    SEARCH_LIST_REQUESTING,
    SEARCH_LIST_FAIL,
    SEARCH_LIST_SUCCESS,
    ADD_FRIEND_REQUESTING,
    ADD_FRIEND_FAIL,
    ADD_FRIEND_SUCCESS,
    GET_FRIEND_LIST_SUCCESS,
    GET_FRIEND_LIST_FAIL,
    GET_FRIEND_LIST_REQUESTING,
    CHANGE_USER_ALIAS_REQUESTING,
    CHANGE_USER_ALIAS_FAIL,
    CHANGE_USER_ALIAS_SUCCESS,
    REMOVE_FRIEND_REQUESTING,
    REMOVE_FRIEND_FAIL,
    REMOVE_FRIEND_SUCCESS
} from '@Types/FriendTypes'

import Api from '../../Config/Api';


/************************ Search Employee List function ****************************/

export const watchSearchListAsync = function* watchSearchListAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.searchUsers, params)
        console.log(response)
        yield put({ type: SEARCH_LIST_SUCCESS, payload: response });
    }
    catch (e) {
        // alert(e)
        yield put({ type: SEARCH_LIST_FAIL, payload: e });
    }
}

/************************ Add Friend function ****************************/

export const watchAddFriendAsync = function* watchAddFriendAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.addFriend, params)
        console.log(response)
        yield put({ type: ADD_FRIEND_SUCCESS, payload: response });
    }
    catch (e) {
        // alert(e)
        yield put({ type: ADD_FRIEND_FAIL, payload: e });
    }
}

/************************ Add Friend function ****************************/

export const watchGetFriendListAsync = function* watchGetFriendListAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.getFriendList, params)
        console.log(response)
        yield put({ type: GET_FRIEND_LIST_SUCCESS, payload: response });
    }
    catch (e) {
        // alert(e)
        yield put({ type: GET_FRIEND_LIST_FAIL, payload: e });
    }
}

/************************ Change Friend Alias function ****************************/

export const watchChangeUserAliasAsync = function* watchChangeUserAliasAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.createFriendAlias, params)
        console.log(response)
        yield put({ type: CHANGE_USER_ALIAS_SUCCESS, payload: response });
    }
    catch (e) {
        // alert(e)
        yield put({ type: CHANGE_USER_ALIAS_FAIL, payload: e });
    }
}


/************************ Remove Single Friend function ****************************/

export const removeSingleFriendAsync = function* removeSingleFriendAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.removeSingleFriend, params)
        console.log(response)
        yield put({ type: REMOVE_FRIEND_SUCCESS, payload: response });
    }
    catch (e) {
        // alert(e)
        yield put({ type: REMOVE_FRIEND_FAIL, payload: e });
    }
}

const watchFriend = function* watchFriend() {
    yield takeEvery(SEARCH_LIST_REQUESTING, watchSearchListAsync);
    yield takeEvery(ADD_FRIEND_REQUESTING, watchAddFriendAsync);
    yield takeEvery(GET_FRIEND_LIST_REQUESTING, watchGetFriendListAsync);
    yield takeEvery(CHANGE_USER_ALIAS_REQUESTING, watchChangeUserAliasAsync);
    yield takeEvery(REMOVE_FRIEND_REQUESTING, removeSingleFriendAsync);
}

export default watchFriend;