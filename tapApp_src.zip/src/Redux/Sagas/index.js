import { all } from 'redux-saga/effects';
//Assets

import watchAuth from './AuthSaga';
import watchSettings from './SettingsSaga'
// by j......
import watchCalendarTab from './CalendarTabSaga'
import watchSchedule from './ScheduleSage'
import watchPlanTab from './PlanTabSaga'
import watchFriend from './FriendSaga';
import watchwatchAcceptRejectMessage from './AcceptRejectMessageSaga';
import watchMessageTab from './MessageTabSaga';
import watchTalk from './TalkSaga'

//Main Root Saga
const rootSaga = function* rootSaga() {
    yield all([
        watchAuth(),
        watchSettings(),
        watchCalendarTab(),
        watchSchedule(),
        watchPlanTab(),
        watchFriend(),
        watchwatchAcceptRejectMessage(),
        watchMessageTab(),
        watchTalk()
    ])
};

export default rootSaga;
