//LIBRARIES
import { put, call, all, takeEvery } from 'redux-saga/effects';

//ASSETS
import {
    ADD_MEDIA_REQUESTING,
    ADD_MEDIA_FAIL,
    ADD_MEDIA_SUCCESS
} from '@Types/TalkTypes'

import Api from '../../Config/Api';


/************************ Add Media Request ****************************/

export const watchAddMediaAsync = function* watchAddMediaAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------SAGA CALLING')
        const response = yield call(Api.addMedia, params)
        console.log(response)
        yield put({ type: ADD_MEDIA_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: ADD_MEDIA_FAIL, payload: e });
    }
}




const watchTalk = function* watchTalk() {
    yield takeEvery(ADD_MEDIA_REQUESTING, watchAddMediaAsync)
}


export default watchTalk;