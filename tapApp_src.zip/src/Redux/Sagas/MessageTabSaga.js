//LIBRARIES
import { put, call, takeEvery } from 'redux-saga/effects';

//ASSETS
import {
    CREATEMESSAGE_REQUESTING,
    CREATEMESSAGE_SUCCESS,
    CREATEMESSAGE_FAIL,

    GETEMPLOYEESTORE_REQUESTING,
    GETEMPLOYEESTORE_SUCCESS,
    GETEMPLOYEESTORE_FAIL,

    GETSTOREEMPLOYEE_REQUESTING,
    GETSTOREEMPLOYEE_SUCCESS,
    GETSTOREEMPLOYEE_FAIL
} from '@Types/MessageTab'

import Api from '../../Config/Api';

/************************ Create Todo function ****************************/
export const watchCreateMessageAsync = function* watchCreateMessageAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------CreateMessageForStore SAGA CALLING')
        const response = yield call(Api.CreateMessageForStore, params)
        console.log(response)
        yield put({ type: CREATEMESSAGE_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: CREATEMESSAGE_FAIL, payload: e });
    }
}

/************************ Get Employee Store function ****************************/
export const watchGetEmployeeStoreAsync = function* watchGetEmployeeStoreAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------GetEmployeeStores SAGA CALLING')
        const response = yield call(Api.GetEmployeeStores, params)
        console.log(response)
        yield put({ type: GETEMPLOYEESTORE_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: GETEMPLOYEESTORE_FAIL, payload: e });
    }
}


/************************ Get Store Employee function ****************************/
export const watchGetStoreEmployeeAsync = function* watchGetStoreEmployeeAsync({ params }) {
    console.log(params)
    try {
        console.log('---------------GetStoreEmployee SAGA CALLING')
        const response = yield call(Api.GetStoreEmployee, params)
        console.log(response)
        yield put({ type: GETSTOREEMPLOYEE_SUCCESS, payload: response });
    }
    catch (e) {
        yield put({ type: GETSTOREEMPLOYEE_FAIL, payload: e });
    }
}

const watchMessageTab = function* watchMessageTab() {
    yield takeEvery(CREATEMESSAGE_REQUESTING, watchCreateMessageAsync);
    yield takeEvery(GETEMPLOYEESTORE_REQUESTING, watchGetEmployeeStoreAsync);
    yield takeEvery(GETSTOREEMPLOYEE_REQUESTING,watchGetStoreEmployeeAsync)
}

export default watchMessageTab;