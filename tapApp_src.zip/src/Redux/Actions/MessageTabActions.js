import {
    CREATEMESSAGE_REQUESTING,
    GETEMPLOYEESTORE_REQUESTING,
    GETSTOREEMPLOYEE_REQUESTING,
} from '@Types/MessageTab';

//--->>Function to Create Todo----->>>>>

export const createMessage = (params) => {
    console.log('hig----------------------------------------Action for creating new message')
    return {
        type: CREATEMESSAGE_REQUESTING,
        params
    };
}
  
//--->>Function to Get Employee Store----->>>>>

export const getEmployeeStore = (params) => {
    return {
        type: GETEMPLOYEESTORE_REQUESTING,
        params
    };
}

//--->>Function to Get Store Employee----->>>>>
export const getStorEemployee = (params) => {
    return {
        type: GETSTOREEMPLOYEE_REQUESTING,
        params
    };
}
   