import {
    ALLCALENDARLIST_REQUESTING,
    LISTOFMESSAGE_REQUESTING,
    LISTOFTODO_REQUESTING,
    LISTOFALLMESSAGEANDTODO_REQUESTING
} from '@Types/ScheduleTypes';

//--->>Function to All Calendar List----->>>>>

export const allCalendarList = (params) => {
    return {
        type: ALLCALENDARLIST_REQUESTING,
        params
    };
}
//--->>Function of List of Message----->>>>>

export const listOfMessage = (params) => {
    return {
        type: LISTOFMESSAGE_REQUESTING,
        params
    };
}

//--->>Function of List of Todo----->>>>>

export const listOfTodoList = (params) => {
    return {
        type: LISTOFTODO_REQUESTING,
        params
    };
}

//--->>Function of List Of Todo Message List----->>>>>

export const listOfTodoMessageList = (params) => {
    return {
        type: LISTOFALLMESSAGEANDTODO_REQUESTING,
        params
    };
}