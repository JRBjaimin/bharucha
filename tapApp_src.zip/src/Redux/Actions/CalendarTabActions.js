import {
    CREATECALENDAR_REQUESTING,
    DELETECALENDAR_REQUESTING,
    COPYCALENDAR_REQUESTING,
    EDITCALENDAR_REQUESTING,
    SHARECALENDAR_REQUESTING,
} from '@Types/CalendarTab';

//--->>Function to Create Calendar----->>>>>

export const createCalendar = (params) => {
    return {
        type: CREATECALENDAR_REQUESTING,
        params
    };
}

//--->>Function to Delete Calendar----->>>>>
export const deleteCalendar = (params) => {
    return {
        type: DELETECALENDAR_REQUESTING,
        params
    };
}

//--->>Function to Copy Calendar----->>>>>
export const copyCalendar = (params) => {
    return {
        type: COPYCALENDAR_REQUESTING,
        params
    };
}

//--->>Function to Edit Calendar----->>>>>
export const editCalendar = (params) => {
    return {
        type: EDITCALENDAR_REQUESTING,
        params
    };
}

// --->>Function to Share Calendar----->>>>>
export const shareCalendar = (params) => {
    return {
        type: SHARECALENDAR_REQUESTING,
        params
    };
}
