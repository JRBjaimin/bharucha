import {
    CREATETODO_REQUESTING,
    EDITTODO_REQUESTING
} from '@Types/PlanTab';

//--->>Function to Create Todo----->>>>>

export const createTodo = (params) => {
    return {
        type: CREATETODO_REQUESTING,
        params
    };
}

//--->>Function to Create Todo----->>>>>

export const editTodo = (params) => {
    return {
        type: EDITTODO_REQUESTING,
        params
    };
}