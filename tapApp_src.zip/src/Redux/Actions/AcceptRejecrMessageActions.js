import {
    ACCEPTREJECTMESSAGE_REQUESTING,
    TASKAPPROVALMANAGER_REQUESTING,
    LISTREQUESTEDUSER_REQUESTING,

} from '@Types/AcceptRejectMessageType';

//--->>Function to ACCEPT REJECT MESSAGE----->>>>>
export const createAcceptRejectMessage = (params) => {
    return {
        type: ACCEPTREJECTMESSAGE_REQUESTING,
        params
    };
}

//--->>Function to Task Approval Mangar ----->>>>>
export const taskApprovalManager = (params) => {
    return {
        type: TASKAPPROVALMANAGER_REQUESTING,
        params
    };
}

//--->>Function to List of Req. user----->>>>>
export const listRequestedUser = (params) => {
    return {
        type: LISTREQUESTEDUSER_REQUESTING,
        params
    };
}
