import {
    GET_REFRESH_TOKEN_REQUESTING,
    PHONE_VERIFICATION_REQUESTING,
    CHECK_OTP_REQUESTING,
    LOGIN_USER_REQUESTING,
    REGISTER_USER_REQUESTING,
    LOGOUT_USER_REQUESTING,
    FORGOT_PASSWORD_REQUESTING,
    ENCRYPT_TOKEN_REQUESTING,
    PHONE_NUMBER_CHECK_REQUESTING
} from '@Types/AuthTypes';



//--->>Request Refresh Token----->>>>>

export const getRefreshTokenRequest = (params) => {
    console.log('Action for refresh token', params)
    return {
        type: GET_REFRESH_TOKEN_REQUESTING,
        params
    };
}

//--->>Request Encrypt Token----->>>>>

export const encryptTokenRequest = (params) => {
    console.log('Action for refresh token', params)
    return {
        type: ENCRYPT_TOKEN_REQUESTING,
        params
    };
}

//--->>Phone Number Check request----->>>>>

export const checkPhoneNumberRequest = (params) => {
    console.log('Action for phone number', params)
    return {
        type: PHONE_NUMBER_CHECK_REQUESTING,
        params
    };
}


//--->>Request Phone Number Verification----->>>>>

export const phoneNumberRequest = (params) => {
    console.log('Action for phone number request', params)
    return {
        type: PHONE_VERIFICATION_REQUESTING,
        params
    };
}

//--->>Check for OTP received on Phone----->>>>>

export const checkOTPRequest = (params) => {
    console.log('Action for OTP request', params)
    return {
        type: CHECK_OTP_REQUESTING,
        params
    };
}


//--->>Function to request User Login----->>>>>

export const loginRequest = (params) => {
    return {
        type: LOGIN_USER_REQUESTING,
        params
    };
}


//--->>Function to request User Registration----->>>>>

export const registerUserRequest = (params) => {
    console.log(params, 'action for user registration')
    return {
        type: REGISTER_USER_REQUESTING,
        params
    };
}


//--->>Function to Logout User----->>>>>
export const logOutRequest = (params) => {
    console.log(params, 'LOgout request=========>>>>>>>>>>>')
    return {
        type: LOGOUT_USER_REQUESTING,
        params
    };
}


//--->>Function to Forgot Password----->>>>>

export const forgotPasswordRequest = (params) => {
    console.log(params)
    return {
        type: FORGOT_PASSWORD_REQUESTING,
        params
    };
}
