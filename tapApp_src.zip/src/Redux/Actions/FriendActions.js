//ASSETS

import {
    SEARCH_LIST_REQUESTING,
    ADD_FRIEND_REQUESTING,
    GET_FRIEND_LIST_REQUESTING,
    CHANGE_USER_ALIAS_REQUESTING,
    REMOVE_FRIEND_REQUESTING
} from '@Types/FriendTypes';


//--->>Action to request Search data----->>>>>

export const searchEmployeeRequest = (params) => {
    return {
        type: SEARCH_LIST_REQUESTING,
        params
    };
}

// //--->>Action to request Search data ----->>>>>

export const addFriendRequest = (params) => {
    return {
        type: ADD_FRIEND_REQUESTING,
        params
    };
}
 //--->>Action to request Friends list ----->>>>>

export const getFriendListRequest = (params) => {
    return {
        type: GET_FRIEND_LIST_REQUESTING,
        params
    };
}


 //--->>Action to create alias name  ----->>>>>

 export const createFriendAliasRequest = (params) => {
    return {
        type: CHANGE_USER_ALIAS_REQUESTING,
        params
    };
}

 //--->>Action to remove single friend----->>>>>

 export const removeSingleFriendRequest = (params) => {
    return {
        type: REMOVE_FRIEND_REQUESTING,
        params
    };
}




