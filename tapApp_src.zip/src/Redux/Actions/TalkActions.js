import {
    ADD_MEDIA_REQUESTING
} from '@Types/TalkTypes';

//--->>Function to add media to chat----->>>>>

export const addMediaRequest = (params) => {
    console.log(params, 'ACTIONSSSSSSS')
    return {
        type: ADD_MEDIA_REQUESTING,
        params
    };
}
