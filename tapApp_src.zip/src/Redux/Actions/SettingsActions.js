import {
    CHANGE_PROFILE_PICTURE_REQUESTING,
    CHANGE_USERNAME_REQUESTING,
    CHANGE_PASSWORD_REQUESTING
} from '@Types/SettingsTypes';

//--->>Function to request edit prof----->>>>>

export const changeProfileRequest = (params) => {
    return {
        type: CHANGE_PROFILE_PICTURE_REQUESTING,
        params
    };
}



//--->>Function to request change username ----->>>>>

export const changeUserNameRequest = (params) => {
    console.log(params)
    console.log('*****************Settings ACTIONS')
    return {
        type: CHANGE_USERNAME_REQUESTING,
        params
    };
};

//--->>Function to request change password----->>>>>

export const changePasswordRequest = (params) => {
    console.log(params)
    console.log('*****************Settings ACTIONS')
    return {
        type: CHANGE_PASSWORD_REQUESTING,
        params
    };
};

