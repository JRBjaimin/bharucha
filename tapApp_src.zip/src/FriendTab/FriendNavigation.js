//Libraries
import { createStackNavigator } from 'react-navigation'

//Screens Import
import Friend from './Friend'
import ScanQRCode from './ScanQRCode'
import SearchID from './SearchID'
import InviteFriend from './InviteFriend'
import EditFriend from './EditFriend'
import ChangeTeam from './ChangeTeam'
import EditFriendList from './EditFriendList'


const FriendNavigator = createStackNavigator({

    Friend : { screen : Friend },
    ScanQRCode: { screen : ScanQRCode },
    SearchID: { screen : SearchID },
    InviteFriend: { screen : InviteFriend },
    EditFriend : { screen : EditFriend },
    ChangeTeam : { screen : ChangeTeam },
    EditFriendList : { screen : EditFriendList }
})

export default FriendNavigator;
