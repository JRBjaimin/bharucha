//Libraries
import React from 'react'
import { View, Text, Image, TouchableOpacity, Alert, StyleSheet, Platform, FlatList } from 'react-native';
import { connect } from 'react-redux'
import AsyncStorage from '@react-native-community/async-storage';
import { StackActions, NavigationActions } from 'react-navigation';
import SearchBar from 'react-native-material-design-searchbar';


//Assets
import { Colors, Images, Matrics } from '@Assets'
import { HeaderBackButton, LoadWheel } from '../Components';
import language from '../Assets/Languages/Language'
import { getFriendListRequest } from '@Redux/Actions/FriendActions'
import { logOutRequest, getRefreshTokenRequest } from '@Redux/Actions/AuthActions'
import { MASTER_ACCESS_KEY } from '../Config/Constants';

let deviceType = Platform.OS == 'ios' ? 1 : 0;

//MAIN CLASS
class EditFriendList extends React.Component {
    //---------->>>NAVIGATION OPTIONS FOR HEADER---------->
    static navigationOptions = ({ navigation }) => ({
        swipeEnabled: false,
        headerTitle: language.friend.MyFriendsHeader,
        headerTitleStyle: { flex: 1, textAlign: 'center' },
        headerLeft: <HeaderBackButton
            onBackPress={() => navigation.goBack()}
        />,
        headerRight: <View />
    })
    //---------->>>STATE DECLARATION---------->
    state = {
        friendListData: [],
        isLoading: true,
        logoutFlag: true,
        noFriendsFlag: false
    }

    //---------->>>LIFE CYCLE METHODS---------->
    componentDidMount() {
        //TO DO - change device token to dynamic one
        this.props.getFriendListRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            device_type: deviceType,
            device_token: "12345678",
            self_user_id: this.props.userInfo.id,
            is_testdata: "1"
        })
    }

    async componentWillReceiveProps(nextProps) {
        console.log(nextProps, '===================>>>>>>>>>>>>>>')
        //if friend list fetched successfully
        if (nextProps.myFriendList.getFriendListSuccess && nextProps.myFriendList.data.status == "1" && this.state.isLoading) {
            this.setState({ isLoading: false })
            let len = nextProps.myFriendList.data.data.user_listing.length;
            console.log(nextProps.myFriendList.data.data.user_listing.length, nextProps.myFriendList.data.data.user_listing, '++++++++++++++++++++++++++++++++++++++')
            if (len > 0) {
                await this.setState({
                    friendListData: nextProps.myFriendList.data.data.user_listing,
                    friendListDataBackup: nextProps.myFriendList.data.data.user_listing
                });
            }
            else {
                this.setState({
                    noFriendsFlag: true
                })
            }
        }

        else if (nextProps.myFriendList.getFriendListFail && this.state.isLoading) {
            this.setState({ isLoading: false })
        }

        //if no friend found
        else if (nextProps.myFriendList.getFriendListSuccess && nextProps.myFriendList.data.status == "0" && this.state.isLoading) {
            this.setState({ isLoading: false });
            alert(language.friend.AddFriendMainText)
        }

        //if user already logged in when searching
        else if (nextProps.myFriendList.getFriendListSuccess && nextProps.myFriendList.data.status == "3" && this.state.logoutFlag && this.state.isLoading) {
            await this.setState({ logoutFlag: false, isLoading: false })
            console.log('gya--------------', this.state.logoutFlag)
            this.LogoutAlert()
        }

        //logout success
        else if (nextProps.logout.logoutSuccess && nextProps.logout.data.status == "1" && !this.state.logoutFlag) {
            console.log('logout func =============', this.state.logoutFlag)
            // await AsyncStorage.removeItem('persist: Auth')
            await AsyncStorage.getAllKeys().then(AsyncStorage.multiRemove)
            await AsyncStorage.removeItem('refreshtoken')

            this.getRefreshToken()
        }
        //if refresh token success 
        if (nextProps.auth.refreshTokenSuccess && nextProps.auth.data.status == "1") {

            const resetAction = StackActions.reset({
                index: 0,
                actions: [NavigationActions.navigate({ routeName: 'Auth' })],
            });
            await this.props.navigation.dispatch(resetAction);
        }
    }
    //---------->>>FUNCTIONS DECLARATION---------->



    getRefreshToken() {
        this.props.getRefreshTokenRequest({ access_key: MASTER_ACCESS_KEY })
    }

    async onLogoutPress() {

        // TO DO - add dynamic device token
        await this.props.logOutRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            user_id: this.props.userInfo.id,
            device_token: "123456",
            device_type: deviceType,
            "is_testdata": "1"
        })
    }

    LogoutAlert() {
        Alert.alert(
            'Alert',
            language.common.LogoutText,
            [
                {
                    text: language.common.Logout,
                    onPress: () => this.onLogoutPress(),
                },
            ],
        );
    }



    onFriendPress(item) {
        this.props.navigation.navigate('EditFriend', { friendData: item })
    }


    renderFriendData = ({ item }) => {
        console.log(item, 'on edit friend list')
        return (
            <TouchableOpacity onPress={() => this.onFriendPress(item)}>
                <View style={styles.usersItemView}>
                    <Image defaultSource={Images.ProfilePlaceHolder} source={item.image ? { uri: item.image } : Images.ProfilePlaceHolder} style={styles.usersImage} />
                    <View style={styles.contentView}>
                        <Text style={styles.userNameText}>{item.alias_name ? item.alias_name : item.firstname}</Text>
                    </View>
                </View>
            </TouchableOpacity>
        )
    }

    //on searcing with search text
    onSearchFriend = (searchText) => {
        if (searchText == '') {
            this.setState({ friendListData: [...this.state.friendListDataBackup], searchtext: searchText });
        }
        else {
            let temp = [];
            let data = this.state.friendListData;
            console.log(data, 'hiiiii=======')
            for (let i = 0; i < data.length; i++) {
                var searchString = (data[i].firstname + data[i].search_id).toLowerCase()
                if (searchString.trim().search(searchText.trim().toLowerCase()) > -1) {
                    console.log(data[i], '&&&&&&&&&&&&&&&&&&&&&&&')
                    temp.push(data[i]);
                }
            }
            this.setState({ friendListData: [...temp], searchtext: searchText });
        }
    }


    //---------->>>Render Method---------->

    render() {
        const { QuickSearch, NofriendFoundText } = language.friend
        return (
            <View style={styles.container}>
                <SearchBar
                    onSearchChange={searchText => {
                        this.onSearchFriend(searchText);
                        this.setState({ searchText })
                    }}
                    height={Platform.OS == "android" ? 40 : 40}
                    onFocus={() => this.setState({ showFriendFlag: false })}
                    onBlur={() => console.log("On Blur")}
                    placeholder={QuickSearch}
                    autoCorrect={false}
                    padding={5}
                    inputStyle={{ borderRadius: 4, marginTop: Matrics.Scale(5), backgroundColor: Colors.LIGHTER_GREY, borderColor: 'transparent' }}
                    returnKeyType={"search"}
                />
                {!this.state.noFriendsFlag ? <FlatList
                    data={this.state.friendListData}
                    extraData={this.state}
                    // onEndReachedThreshold={0.5}
                    // onEndReached={() => this.loadMoreData()}
                    renderItem={this.renderFriendData}
                    // contentContainerStyle={styles.FlatListStyle}
                    ItemSeparatorComponent={() => (
                        <View style={styles.ItemSeparatorComponent} />
                    )}
                /> :
                    <View style={styles.NoFriendsView}>
                        <Text style={styles.NoFriendsText}>
                            {NofriendFoundText}
                        </Text>
                    </View>
                }
                <LoadWheel isVisible={this.state.isLoading} />
            </View>
        )
    }
}



//Props Connection
const mapStateToProps = (state) => {
    console.log(state, 'state on profile')
    return {
        auth: state.Auth,
        userInfo: state.Auth.data && state.Auth.data.data ? state.Auth.data.data.User : undefined,
        logout: state.Logout,
        encryptedToken: state.Encrypt.data ? state.Encrypt.data.encrypted_value : undefined,
        settings: state.Settings,
        updatedUserInfo: state.Settings.data && state.Settings.data.data ? state.Settings.data.data.User : undefined,
        friend: state.Friend,
        friendRequest: state.FriendRequest,
        myFriendList: state.myFriendList
    };
}
//Redux Connection  
export default connect(mapStateToProps, { getFriendListRequest, logOutRequest, getRefreshTokenRequest })(EditFriendList);


const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    usersItemView: {
        marginHorizontal: Matrics.Scale(10),
        marginVertical: Matrics.Scale(5),
        // justifyContent:'center',
        flexDirection: 'row'
    },
    usersImage: {
        height: Matrics.Scale(50),
        width: Matrics.Scale(50),
        borderWidth: Matrics.Scale(1),
        borderRadius: Matrics.Scale(25),

    },
    contentView: {
        marginHorizontal: Matrics.Scale(10),
        marginVertical: Matrics.Scale(5),
    },
    userNameText: {
        marginBottom: Matrics.Scale(5),
    },
    ItemSeparatorComponent: {
        borderBottomWidth: Matrics.Scale(1),
        marginTop: Matrics.Scale(1),
        borderColor: Colors.GREY
    },
    NoFriendsView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        marginHorizontal: Matrics.Scale(10)
    },
    NoFriendsText: {
        fontSize: Matrics.Scale(18),
        color: Colors.GREY
    }
})