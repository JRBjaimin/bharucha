//Libraries
import React from 'react'
import { View, Text, Image, StyleSheet } from 'react-native';
import Communications from 'react-native-communications';
import Modal from "react-native-modal";
//Assets
import { InviteFriendAlert } from '../Components'
import { Colors, Images, Matrics } from '@Assets'
import { ListCell } from './Templates/ListCell'
import language from '../Assets/Languages/Language'

//MAIN CLASS
class Friend extends React.Component {


    //---------------->>>>NAVIGATION OPTIONS FOR HEADER---------->>>
    static navigationOptions = ({ navigation }) => ({
        swipeEnabled: false,
        headerTitle: language.friend.header,
        headerTitleStyle: { flex: 1, textAlign: 'center' },
    })


    state = {
        isInviteModalVisible: false
    }
    //send an email to users
    emailUser() {
        Communications.email(['emailAddress1', 'emailAddress2'], null, null, 'My Subject', 'My body text')
    }
    //send an sms to user    
    SMSUser() {
        Communications.textWithoutEncoding('1234567890', 'body')
    }


    //---------------->>>>RENDER METHOD---------->>>
    render() {
        const { IDSearch, InviteFriend, QRCode, FriendListText } = language.friend
        return (
            <View style={styles.container}>
                <ListCell
                    Name={FriendListText}
                    IconSource={Images.edit_friend}
                    onPress={() => this.props.navigation.navigate('EditFriendList')}
                />
                <ListCell
                    Name={IDSearch}
                    IconSource={Images.find_Id_icon}
                    onPress={() => this.props.navigation.navigate('SearchID')}
                    imageStyle={{ height: Matrics.Scale(37) }}
                />
                <ListCell
                    Name={QRCode}
                    IconSource={Images.QR_icon}
                    onPress={() => this.props.navigation.navigate('ScanQRCode')}
                />
                <ListCell
                    Name={InviteFriend}
                    IconSource={Images.friend_Req}
                    onPress={() => this.setState({ isInviteModalVisible: true })}
                />
                <InviteFriendAlert
                    isVisible={this.state.isInviteModalVisible}
                    onCancelPress={() => this.setState({ isInviteModalVisible: false })}
                    onSMSPress={() => { this.SMSUser(); this.setState({ isInviteModalVisible: false }) }}
                    onEmailPress={() => { this.emailUser(); this.setState({ isInviteModalVisible: false }) }}
                />

            </View>
        )
    }
}

export default Friend



//STYELS DECLARATION
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
});