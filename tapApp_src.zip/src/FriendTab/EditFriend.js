//Libraries
import React from 'react'
import { View, Text, Image, StyleSheet, ImageBackground, Alert, Dimensions, TextInput, TouchableOpacity, Platform } from 'react-native';
import { connect } from 'react-redux'
import AsyncStorage from '@react-native-community/async-storage';
import { StackActions, NavigationActions } from 'react-navigation';
//Assets
import { Colors, Images, Matrics } from '@Assets'
import { HeaderBackButton, ConfirmAlert, LoadWheel } from '../Components';
import { ListCell } from './Templates/ListCell'
import language from '../Assets/Languages/Language'
import { logOutRequest, getRefreshTokenRequest } from '@Redux/Actions/AuthActions'
import { createFriendAliasRequest, removeSingleFriendRequest } from '@Redux/Actions/FriendActions'
import { MASTER_ACCESS_KEY } from '../Config/Constants';


const { height, width } = Dimensions.get('window')
let deviceType = Platform.OS == 'ios' ? 1 : 0;


//MAIN CLASS
class EditFriend extends React.Component {
    //---------->>>NAVIGATION OPTIONS FOR HEADER---------->
    static navigationOptions = ({ navigation }) => ({
        swipeEnabled: false,
        headerTitle: language.friend.EditFriendHeader,
        headerTitleStyle: { flex: 1, textAlign: 'center' },
        headerLeft: <HeaderBackButton
            onBackPress={() => navigation.goBack()}
        />,
        headerRight: <View />
    })

    //---------->>>STATE DECLARATION---------->

    state = {
        friendNameAlias: this.props && this.props.alias_name ? this.props.alias_name : this.props.navigation.state.params.friendData.firstname,
        isLoading1: false,
        isLoading2: false,
        logoutFlag: true,
    }

    //---------->>>LIFE CYCLE METHODS---------->

    componentDidMount() {
        console.log(this.props.navigation.state.params.friendData.id, '=================>>>>>>>>>')
    }

    async componentWillReceiveProps(nextProps) {

        console.log(nextProps, '--------------------__--------__----_-__-_-----__-')
        //if remove friend success
        if (nextProps.removeFriend.removeFriendSuccess && nextProps.removeFriend.data.status == "1" && this.state.isLoading1) {
            this.setState({ isLoading1: false })
            this.onRemoveFriendSuccessAlert()
        }
        //if remove friend fail
        else if (nextProps.removeFriend.removeFriendFail && this.state.isLoading1) {
            this.setState({ isLoading1: false })
            alert(language.auth.SomethingWentWrong1)
        }

        else if (nextProps.aliasFriend.changeFriendAliasSuccess && nextProps.aliasFriend.data.status == "1" && this.state.isLoading2) {
            alert(language.friend.AliasNameSuccess)
            console.log(nextProps.aliasFriend.data.data.alias_name, '*************------*****++')
            this.setState({ friendNameAlias: nextProps.aliasFriend.data.data.alias_name, isLoading2: false })
        }

        //if user already logged in when searching
        else if (nextProps.removeFriend.removeFriendSuccess && nextProps.removeFriend.data.status == "3" && this.state.logoutFlag && this.state.isLoading1) {
            await this.setState({ logoutFlag: false, isLoading1: false })
            console.log('gya--------------', this.state.logoutFlag)
            this.LogoutAlert()
        }

        //logout success
        else if (nextProps.logout.logoutSuccess && nextProps.logout.data.status == "1" && !this.state.logoutFlag) {
            console.log('logout func =============', this.state.logoutFlag)
            // await AsyncStorage.removeItem('persist: Auth')
            await AsyncStorage.getAllKeys().then(AsyncStorage.multiRemove)
            await AsyncStorage.removeItem('refreshtoken')
            this.getRefreshToken()
        }

        //if refresh token success 
        if (nextProps.auth.refreshTokenSuccess && nextProps.auth.data.status == "1") {

            const resetAction = StackActions.reset({
                index: 0,
                actions: [NavigationActions.navigate({ routeName: 'Auth' })],
            });
            await this.props.navigation.dispatch(resetAction);
        }
    }
    //---------->>>FUNCTIONS DECLARATION---------->


    getRefreshToken() {
        this.props.getRefreshTokenRequest({ access_key: MASTER_ACCESS_KEY })
    }

    async onLogoutPress() {

        // TO DO - add dynamic device token
        await this.props.logOutRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            user_id: this.props.userInfo.id,
            device_token: "123456",
            device_type: deviceType,
            "is_testdata": "1"
        })
    }

    LogoutAlert() {
        Alert.alert(
            'Alert',
            language.common.LogoutText,
            [
                {
                    text: language.common.Logout,
                    onPress: () => this.onLogoutPress(),
                },
            ],
        );
    }

    ConfirmRemoveFriend(id) {
        Alert.alert(
            'Alert',
            language.common.LogoutText,
            [
                {
                    text: language.yes,
                    onPress: () => this.onRemoveFriendPress(id),
                },
                {
                    text: language.no,
                    // onPress: () => this.onLogoutPress(),
                    style: 'cancel',
                },
            ],
        );
    }


    onRemoveFriendSuccessAlert() {
        Alert.alert(
            language.auth.SuccessText,
            language.friend.FriendRemoveText,
            [
                {
                    text: 'Ok',
                    onPress: () => this.props.navigation.navigate('Friend'),
                },
            ],
        );
    }

    onChangePress() {
        this.setState({ isLoading2: true })
        //TO DO - change device token to dynamic one
        this.props.createFriendAliasRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            device_type: deviceType,
            device_token: "12345678",
            user_id: this.props.navigation.state.params.friendData.id,
            self_user_id: this.props.userInfo.id,
            alias_name: this.state.friendNameAlias,
            is_testdata: "1"
        })
    }


    onRemoveFriendPress(FriendId) {
        this.setState({ isLoading1: true })
        this.props.removeSingleFriendRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            device_token: "12345678",
            device_type: deviceType,
            self_user_id: this.props.userInfo.id,
            other_user_id: FriendId,
            is_testdata: "1"
        })
    }


    //---------->>>Render Method---------->
    render() {
        const { friendData } = this.props.navigation.state.params
        console.log(friendData, 'thisprops------')
        const { UserName, ChangeTeam, DeleteFriend } = language.friend
        const { ChangeText } = language.other
        return (
            <View style={styles.container}>
                <ImageBackground style={styles.ImageBackgroundContainer} source={Images.ProfileBG}>
                    <Image defaultSource={Images.ProfilePlaceHolder} source={friendData.image ? { uri: friendData.image } : Images.ProfilePlaceHolder} style={styles.profilePic} />
                </ImageBackground>

                <View style={{ flex: 1 }}>
                    <View>
                        <View style={styles.ListContainer}>
                            <Image source={Images.editNameIcon} style={styles.ListIcon} />
                            <View style={styles.subListView}>
                                <View style={styles.inputView}>
                                    <TextInput
                                        value={this.state.friendNameAlias}
                                        onChangeText={(text) => this.setState({ friendNameAlias: text })}
                                        style={styles.listName}
                                    />
                                    <TouchableOpacity onPress={() => this.onChangePress()}>
                                        <Text style={styles.changeText}>{ChangeText}</Text>
                                    </TouchableOpacity>
                                </View>
                                <View style={styles.listBorderView} />
                            </View>
                        </View>
                    </View>
                    <ListCell
                        Name={ChangeTeam}
                        IconSource={Images.changeTeam}
                        onPress={() => this.props.navigation.navigate('ChangeTeam')}
                        imageStyle={{ height: Matrics.Scale(38), width: Matrics.Scale(50) }}
                    />
                    <ListCell
                        Name={DeleteFriend}
                        IconSource={Images.deleteFriend}
                        imageStyle={{ height: Matrics.Scale(50), width: Matrics.Scale(45), marginLeft: Matrics.Scale(30) }}
                        onPress={() => this.ConfirmRemoveFriend(friendData.id)}
                    />
                </View>
                <ConfirmAlert
                    isVisible={false}
                />
                <LoadWheel isVisible={this.state.isLoading1 && this.state.isLoading2} />
            </View>
        )
    }
}
//Props Connection
const mapStateToProps = (state) => {
    console.log(state, 'state on profile')
    return {
        auth: state.Auth,
        userInfo: state.Auth.data && state.Auth.data.data ? state.Auth.data.data.User : undefined,
        logout: state.Logout,
        encryptedToken: state.Encrypt.data ? state.Encrypt.data.encrypted_value : undefined,
        settings: state.Settings,
        updatedUserInfo: state.Settings.data && state.Settings.data.data ? state.Settings.data.data.User : undefined,
        friend: state.Friend,
        friendRequest: state.FriendRequest,
        myFriendList: state.myFriendList,
        aliasFriend: state.AliasFriend,
        removeFriend: state.RemoveFriend,
        alias_name: state.AliasFriend && state.AliasFriend.data && state.AliasFriend.data.data && state.AliasFriend.data.data.alias_name
    };
}
//Redux Connection  
export default connect(mapStateToProps, { logOutRequest, removeSingleFriendRequest, getRefreshTokenRequest, createFriendAliasRequest })(EditFriend);




//STYELS DECLARATION
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    profilePic: {
        height: Matrics.Scale(70),
        width: Matrics.Scale(70),
        borderRadius: Matrics.Scale(35.5)
    },
    ImageBackgroundContainer: {
        // flex: 1,
        height: height / 4.8,
        justifyContent: 'center',
        alignItems: 'center'
    },
    ListContainer: {
        alignItems: 'center',
        flexDirection: 'row',
        marginVertical: Matrics.Scale(20)
    },
    ListIcon: {
        marginLeft: Matrics.Scale(25),
        height: Matrics.Scale(30),
        width: Matrics.Scale(50)
    },
    subListView: { flex: 1 },
    listName: {
        marginLeft: Matrics.Scale(35),
        flex: 1,
        // fontSize: Matrics.Scale(15),
        borderWidth: 1,
        paddingVertical: Matrics.Scale(5)
    },
    listBorderView: {
        borderColor: Colors.GREY,
        marginTop: Matrics.Scale(13),
        borderWidth: 1,
        marginLeft: Matrics.Scale(35)
    },
    inputView: { flexDirection: 'row' },
    changeText: {
        marginRight: Matrics.Scale(15),
        borderWidth: 1,
        marginLeft: Matrics.Scale(9),
        alignSelf: 'center',
        padding: Matrics.Scale(5),
        marginTop: Platform.OS == 'android' ? 5 : 0
    }
});