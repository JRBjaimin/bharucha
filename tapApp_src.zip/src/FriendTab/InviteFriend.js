//Libraries
import React from 'react'
import { View, Text, Image } from 'react-native';


//Assets
import { Colors, Images, Matrics } from '@Assets'
import { HeaderBackButton } from '../Components';
import language from '../Assets/Languages/Language'


//MAIN CLASS
class InviteFriend extends React.Component {
    //NAVGATION OPTIONS FOR HEADER
    static navigationOptions = ({ navigation }) => ({
        swipeEnabled: false,
        headerTitle: language.friend.InviteFriend,
        headerTitleStyle :{ flex:1, textAlign :'center' },
        headerLeft: <HeaderBackButton
            onBackPress={() => navigation.goBack()}
        />,
        headerRight: <View />
    })

    //RENDER METHOD
    render() {
        return (
            <View>

               
            </View>
        )
    }
}

export default InviteFriend