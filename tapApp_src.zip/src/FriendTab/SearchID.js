//Libraries
import React from 'react'
import { View, Text, Image, TouchableOpacity, Alert, StyleSheet, Platform, FlatList } from 'react-native';
import SearchBar from 'react-native-material-design-searchbar';
import { connect } from 'react-redux'
import AsyncStorage from '@react-native-community/async-storage';
import { StackActions, NavigationActions } from 'react-navigation';

//Assets
import { Colors, Images, Matrics } from '@Assets'
import { HeaderBackButton, LoadWheel } from '../Components';
import language from '../Assets/Languages/Language'
import { searchEmployeeRequest, addFriendRequest } from '@Redux/Actions/FriendActions'
import { logOutRequest, getRefreshTokenRequest } from '@Redux/Actions/AuthActions'
import { MASTER_ACCESS_KEY } from '../Config/Constants';

let deviceType = Platform.OS == 'ios' ? 1 : 0;

//MAIN CLASS
class SearchID extends React.Component {
    //---------->>>NAVIGATION OPTIONS FOR HEADER---------->
    static navigationOptions = ({ navigation }) => ({
        swipeEnabled: false,
        headerTitle: language.friend.IDSearch,
        headerTitleStyle: { flex: 1, textAlign: 'center' },
        headerLeft: <HeaderBackButton
            onBackPress={() => navigation.goBack()}
        />,
        headerRight: <View />
    })
    //---------->>>STATE DECLARATION---------->
    state = {
        searchText: '',
        offsetCount: "0",
        EmployeeDataList: [],
        logoutFlag: true,
        isLoading: false,
        showFriendFlag: false,
        friendName: '',
        friendID: 0,
    }

    //---------->>>LIFE CYCLE METHODS---------->
    async componentWillReceiveProps(nextProps) {
        //if user list found
        if (nextProps.friend.searchListSuccess && nextProps.friend.data.status == "1" && this.state.isLoading) {
            this.setState({ isLoading: false });
            let len = nextProps.friend.data.data.user_listing.length;
            if (len > 0) {
                await this.setState({
                    EmployeeDataList: [...nextProps.friend.data.data.user_listing]
                });
            }
        }
        //if no user found
        else if (nextProps.friend.searchListSuccess && nextProps.friend.data.status == "0" && this.state.isLoading) {
            this.setState({ isLoading: false, EmployeeDataList: [] });
            alert(nextProps.friend.data.message)
        }
        //if user already logged in when searching
        else if (nextProps.friend.searchListSuccess && nextProps.friend.data.status == "3" && this.state.logoutFlag && this.state.isLoading) {
            await this.setState({ logoutFlag: false, isLoading: false })
            console.log('gya--------------', this.state.logoutFlag)
            this.LogoutAlert()
        }

        //logout success
        else if (nextProps.logout.logoutSuccess && nextProps.logout.data.status == "1" && !this.state.logoutFlag) {
            console.log('logout func =============', this.state.logoutFlag)
            // await AsyncStorage.removeItem('persist: Auth')
            await AsyncStorage.getAllKeys().then(AsyncStorage.multiRemove)
            await AsyncStorage.removeItem('refreshtoken')
            this.getRefreshToken()
        }
        //if refresh token success 
        if (nextProps.auth.refreshTokenSuccess && nextProps.auth.data.status == "1") {
            const resetAction = StackActions.reset({
                index: 0,
                actions: [NavigationActions.navigate({ routeName: 'Auth' })],
            });
            await this.props.navigation.dispatch(resetAction);
        }

        //if searching list not fetched from service
        else if (nextProps.friend.searchListFail) {
            alert('something went wrong.Please try again.')
        }
        //if friend followed successfully
        else if (nextProps.friendRequest.addFriendSuccess && nextProps.friendRequest.data.status == "1" && this.state.isLoading) {
            this.setState({ isLoading: false });
            this.friendAddSuccessAlert()
        }
        //if user already exists when sending friend request
        else if (nextProps.friendRequest.addFriendSuccess && nextProps.friendRequest.data.status == "3" && this.state.logoutFlag && this.state.isLoading) {
            await this.setState({ logoutFlag: false, isLoading: false })
            console.log('gya--------------', this.state.logoutFlag)
            this.LogoutAlert()
        }

        else if (nextProps.friendRequest.addFriendFail && this.state.isLoading) {
            this.setState({ isLoading: false });
            alert('Something went wrong. please try again later.')
        }
    }

    //---------->>>FUNCTIONS DECLARATION---------->

    getRefreshToken() {
        this.props.getRefreshTokenRequest({ access_key: MASTER_ACCESS_KEY })
    }

    //on searcing with search text
    onSearchEmployee = (searchText) => {
        this.setState({ isLoading: true })
        //TO DO - change device token to dynamic one
        this.props.searchEmployeeRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            device_token: "12345678",
            device_type: deviceType,
            user_id: this.props.userInfo.id,
            offset: "0",
            serach_txt: searchText,
            is_testdata: "1",
            isFollow: 0
        });
    }

    //List Item for Flatlist
    renderEmployeeData = ({ item }) => {
        console.log(item, 'items--------->>>>')
        return (
            <TouchableOpacity onPress={() => this.getFriendDetails(item.firstname, item.id, item.isFollow)}>
                <View style={styles.usersItemView}>
                    <Image defaultSource={Images.ProfilePlaceHolder} source={item.image ? { uri: item.image } : Images.ProfilePlaceHolder} style={styles.usersImage} />
                    <View style={styles.contentView}>
                        <Text style={styles.userNameText}>{item.firstname}</Text>
                    </View>
                </View>
            </TouchableOpacity>
        )
    };

    //When clicked on specific record
    getFriendDetails(firstname, friendID, isFollow) {
        this.setState({ showFriendFlag: true, friendID: friendID, friendName: firstname, isFollow: isFollow })
        console.log(firstname, friendID, 'username0------========')
    }
    //Add friend by sending request
    addFriend() {
        this.setState({ isLoading: true })
        //TO DO - change device token to dynamic one
        this.props.addFriendRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            device_token: "12345678",
            device_type: deviceType,
            self_user_id: this.props.userInfo.id,
            other_user_id: this.state.friendID,
            is_testdata: "1"
        })
    }

    loadMoreData() {
        if (this.props.friend.data.load_more) {
            this.setState(
                {
                    offsetCount: Number(this.state.offsetCount) + 1,
                },
                () => {
                    this.props.searchEmployeeRequest({
                        secret_key: this.props.auth.data.userToken,
                        access_key: this.props.encryptedToken,
                        device_token: "12345678",
                        device_type: deviceType,
                        user_id: this.props.userInfo.id,
                        offset: this.state.offsetCount.toString(),
                        serach_txt: this.state.searchText,
                        is_testdata: "1"
                    });
                }
            );
        }
    }

    async onLogoutPress() {

        // TO DO - add dynamic device token
        await this.props.logOutRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            user_id: this.props.userInfo.id,
            device_token: "123456",
            device_type: deviceType,
            "is_testdata": "1"
        })
    }

    LogoutAlert() {
        Alert.alert(
            'Alert',
            'There is login detected for this user in another device. so, please logout and login again',
            [
                {
                    text: 'Logout',
                    onPress: () => this.onLogoutPress(),
                },
            ],
        );
    }

    friendAddSuccessAlert() {
        Alert.alert(
            'Alert',
            'You are now friends with ' + this.state.friendName,
            [
                {
                    text: 'Ok',
                    onPress: () => this.props.navigation.navigate('Friend'),
                },
            ],
        );
    }

    //------------>>>>RENDER METHOD------------->>>>>
    render() {
        return (
            <View style={styles.container}>
                <SearchBar
                    onSearchChange={searchText => {
                        this.onSearchEmployee(searchText);
                        this.setState({ searchText })
                    }}
                    height={Platform.OS == "android" ? 40 : 40}
                    onFocus={() => this.setState({ showFriendFlag: false })}
                    onBlur={() => console.log("On Blur")}
                    placeholder={"Quick Search..."}
                    autoCorrect={false}
                    padding={5}
                    inputStyle={{ borderRadius: 4, marginTop: Matrics.Scale(5), backgroundColor: Colors.LIGHTER_GREY, borderColor: 'transparent' }}
                    returnKeyType={"search"}
                />

                {!this.state.showFriendFlag ?
                    <FlatList
                        data={this.state.EmployeeDataList}
                        extraData={this.state}
                        onEndReachedThreshold={0.5}
                        onEndReached={() => this.loadMoreData()}
                        renderItem={this.renderEmployeeData}
                        // contentContainerStyle={styles.FlatListStyle}
                        ItemSeparatorComponent={() => (
                            <View style={styles.ItemSeparatorComponent} />
                        )}
                    /> :
                    <View>
                        <View style={{ marginTop: Matrics.Scale(50), justifyContent: 'center', alignItems: 'center' }}>
                            <Image source={Images.ProfilePlaceHolder} style={{ height: Matrics.Scale(130), width: Matrics.Scale(130), borderRadius: Matrics.Scale(65) }} />
                            <Text style={{ marginTop: Matrics.Scale(20), fontSize: Matrics.Scale(25) }}>{this.state.friendName}</Text>
                            {this.state.isFollow == 0 ?
                                <TouchableOpacity onPress={() => this.addFriend()}>
                                    <View style={{ marginTop: Matrics.Scale(20), borderRadius: Matrics.Scale(3), justifyContent: 'center', alignItems: 'center', height: Matrics.Scale(40), width: Matrics.Scale(150), backgroundColor: Colors.TEXT }}>
                                        <Text style={{ color: Colors.WHITE }}>Add Friend</Text>
                                    </View>
                                </TouchableOpacity>
                                :
                                <View style={{ marginTop: Matrics.Scale(20), borderRadius: Matrics.Scale(3), justifyContent: 'center', alignItems: 'center', height: Matrics.Scale(40), width: Matrics.Scale(300), backgroundColor: Colors.TEXT }}>
                                    <Text style={{ color: Colors.WHITE, fontSize: 18 }}>{this.state.friendName} is already a friend.</Text>
                                </View>
                            }
                        </View>
                    </View>}
                <LoadWheel isVisible={this.state.isLoading} />
            </View>
        )
    }
}

//Props Connection
const mapStateToProps = (state) => {
    console.log(state, 'state on profile')
    return {
        auth: state.Auth,
        userInfo: state.Auth.data && state.Auth.data.data ? state.Auth.data.data.User : undefined,
        logout: state.Logout,
        encryptedToken: state.Encrypt.data ? state.Encrypt.data.encrypted_value : undefined,
        friend: state.Friend,
        friendRequest: state.FriendRequest
    };
}
//Redux Connection  
export default connect(mapStateToProps, { logOutRequest, searchEmployeeRequest, getRefreshTokenRequest, addFriendRequest })(SearchID);

//======STYLES DECLARATION======//

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    searchView: {
        flexDirection: 'row',
        backgroundColor: Colors.LIGHT_GREY,
        padding: Matrics.Scale(10),
        borderRadius: Matrics.Scale(5),
        marginHorizontal: Matrics.Scale(10),
        marginVertical: Matrics.Scale(10),
    },
    SearchIconStyle: {
        marginHorizontal: Matrics.Scale(5),
        height: Matrics.Scale(19),
        width: Matrics.Scale(15),

    },
    usersItemView: {
        marginHorizontal: Matrics.Scale(10),
        marginVertical: Matrics.Scale(5),
        // justifyContent:'center',
        flexDirection: 'row'
    },
    usersImage: {
        height: Matrics.Scale(50),
        width: Matrics.Scale(50),
        borderWidth: Matrics.Scale(1),
        borderRadius: Matrics.Scale(25),

    },
    contentView: {
        marginHorizontal: Matrics.Scale(10),
        marginVertical: Matrics.Scale(5),
    },
    userNameText: {
        marginBottom: Matrics.Scale(5),
    },
    ItemSeparatorComponent: {
        borderBottomWidth: Matrics.Scale(1),
        marginTop: Matrics.Scale(1),
        borderColor: Colors.GREY
    },
})