//Libraries
import React from 'react'
import { View, Text, Image, StyleSheet, FlatList, TouchableOpacity, TextInput } from 'react-native';


//Assets
import { Colors, Images, Matrics } from '@Assets'
import { HeaderBackButton, Button } from '../Components';
import language from '../Assets/Languages/Language'



//MAIN CLASS
class ChangeTeam extends React.Component {

    //------------->>>NAVGATION OPTIONS FOR HEADER------------>>>>
    static navigationOptions = ({ navigation }) => ({
        swipeEnabled: false,
        headerTitle: language.friend.ManageTeamHeader,
        headerTitleStyle :{ flex:1, textAlign :'center' },
        headerLeft: <HeaderBackButton
            onBackPress={() => navigation.goBack()}
        />,
        headerRight : <View />
    })


    //-----------STATE------------>>>>>>>
    state = {
        newTeamName: ''
    }

    //------------->>>Controllers/Functions------------>>>>


    renderTeamData = ({ item }) => {
        // console.log(item.thumbnail_url)
        return (
            <TouchableOpacity>
                <View style={styles.teamItemView}>

                    <Text>THis is a text</Text>
                </View>
            </TouchableOpacity>
        )
    }

    //------------->>>RENDER METHOD------------>>>>
    render() {
        const  { AddNewTeam, EnterTeamName } = language.friend
        return (
            <View style={styles.container}>
                <FlatList
                    data={[1, 2, 3, 4, 5, 6]}
                    extraData={this.state}
                    renderItem={this.renderTeamData}
                />
                <View style={styles.contentContainer}>
                    <Button
                        onPress={() => this.props.navigation.navigate('EditFriend')}
                    />

                    <View style={styles.addNewTeamView}>
                        <Text style={styles.addNewTeamText}>{AddNewTeam}</Text>
                        <View style={styles.newTeamTextView}>
                            <TextInput
                                style={{ flex: 1 }}
                                placeholder={EnterTeamName}
                                value={this.state.newTeamName}
                                onChangeText={(text) => this.setState({ newTeamName: text })}
                            />

                            <TouchableOpacity>
                                <View style={styles.okStyle}>
                                    <Text>OK</Text>
                                </View>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </View>

        )
    }
}

export default ChangeTeam



//STYELS DECLARATION
const styles = StyleSheet.create({
    container: {
        // flex: 1,
    },

    teamItemView: {
        borderWidth: 1,
        borderRadius: Matrics.Scale(2),
        borderColor: Colors.GREY,
        marginHorizontal: Matrics.Scale(10),
        marginTop: Matrics.Scale(5),
        padding: Matrics.Scale(10)
    },
    addNewTeamView: {
        marginVertical: Matrics.Scale(30)
    },
    contentContainer: {
        marginVertical: Matrics.Scale(20)
    },
    newTeamTextView: {
        borderRadius: Matrics.Scale(2.5),
        borderWidth: 1,
        borderColor: Colors.GREY,
        marginHorizontal: Matrics.Scale(10),
        padding: Matrics.Scale(10),
        flexDirection: 'row'
    },
    okStyle: {
        borderRadius: Matrics.Scale(2),
        borderWidth: 1,
        borderColor: Colors.GREY,
        padding: Matrics.Scale(5),
        justifyContent: 'flex-end',
        paddingHorizontal: Matrics.Scale(7)
    },
    addNewTeamText: {
        marginVertical: Matrics.Scale(10),
        marginHorizontal: Matrics.Scale(10),
    }
});