//Libraries
import React from 'react'
import { View, Text, Image, StyleSheet, TouchableOpacity, Alert, Platform } from 'react-native';
import { RNCamera } from 'react-native-camera';
import BarcodeMask from 'react-native-barcode-mask';
import { connect } from 'react-redux'
import { StackActions, NavigationActions } from 'react-navigation';

//Assets
import { Colors, Images, Matrics } from '@Assets'
import { searchEmployeeRequest, addFriendRequest } from '@Redux/Actions/FriendActions'
import { logOutRequest, getRefreshTokenRequest } from '@Redux/Actions/AuthActions'
import { MASTER_ACCESS_KEY } from '../Config/Constants';
import { HeaderBackButton, LoadWheel } from '../Components';
import language from '../Assets/Languages/Language'

let deviceType = Platform.OS == 'ios' ? 1 : 0;

//MAIN CLASS
class ScanQRCode extends React.Component {
    //NAVGATION OPTIONS FOR HEADER
    static navigationOptions = ({ navigation }) => ({
        swipeEnabled: false,
        headerTitle: language.friend.QRCode,
        headerTitleStyle: { flex: 1, textAlign: 'center' },
        headerLeft: <HeaderBackButton
            onBackPress={() => navigation.goBack()}
        />,
        headerRight: <View />
    })

    state = {
        barcodeValue: [],
        datafound: false,
        dataforFriend: [],
        isLoading: false,
        isAddingFriend: false,
        isFollow: 0,
    }


    async componentWillReceiveProps(nextProps) {
        console.log(nextProps, 'nextProps on scan qr code **************************')
        //if friend followed successfully
        if (nextProps.friendRequest.addFriendSuccess && nextProps.friendRequest.data.status == "1" && this.state.isLoading && this.state.isAddingFriend) {
            this.setState({ isLoading: false, isAddingFriend: false });
            this.friendAddSuccessAlert()
        }


        //if user already exists when sending friend request
        else if (nextProps.friendRequest.addFriendSuccess && nextProps.friendRequest.data.status == "3" && this.state.logoutFlag && this.state.isLoading) {
            await this.setState({ logoutFlag: false, isLoading: false })
            console.log('gya--------------', this.state.logoutFlag)
            this.LogoutAlert()
        }

        //if user friend search success
        else if (nextProps.friend.searchListSuccess && nextProps.friend.data.status == "1" && this.state.isLoading) {
            this.setState({ isLoading: false, isFollow: nextProps.friend.data.data.user_listing[0].isFollow });
           
        }


        else if (nextProps.friendRequest.addFriendFail && this.state.isLoading) {
            this.setState({ isLoading: false });
            alert(language.auth.SomethingWentWrong1)
        }

        //logout success
        else if (nextProps.logout.logoutSuccess && nextProps.logout.data.status == "1" && !this.state.logoutFlag) {
            console.log('logout func =============', this.state.logoutFlag)
            await AsyncStorage.getAllKeys().then(AsyncStorage.multiRemove)
            await AsyncStorage.removeItem('refreshtoken')
            this.getRefreshToken()
        }

        //if refresh token success 
        if (nextProps.auth.refreshTokenSuccess && nextProps.auth.data.status == "1") {

            const resetAction = StackActions.reset({
                index: 0,
                actions: [NavigationActions.navigate({ routeName: 'Auth' })],
            });
            await this.props.navigation.dispatch(resetAction);
        }
    }


    getRefreshToken() {
        this.props.getRefreshTokenRequest({ access_key: MASTER_ACCESS_KEY })
    }

    async onLogoutPress() {

        // TO DO - add dynamic device token
        await this.props.logOutRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            user_id: this.props.userInfo.id,
            device_token: "123456",
            device_type: deviceType,
            "is_testdata": "1"
        })
    }

    LogoutAlert() {
        Alert.alert(
            'Alert',
            language.common.LogoutText,
            [
                {
                    text: language.common.Logout,
                    onPress: () => this.onLogoutPress(),
                },
            ],
        );
    }

    friendAddSuccessAlert() {
        Alert.alert(
            'Alert',
            language.other.FriendSuccAlert + this.state.barcodeValue.name,
            [
                {
                    text: 'Ok',
                    onPress: () => this.props.navigation.navigate('Friend'),
                },
            ],
        );
    }

    onBarCodeRead = async (e) => {
        const data = await e.data
        console.log(data, '************************//////////*********///////////////*****')
        await this.setState({ barcodeValue: JSON.parse(data), datafound: true })
        this.onSearchEmployee(this.state.barcodeValue.name)
    }



    //Add friend by sending request
    addFriend() {
        this.setState({ isLoading: true, isAddingFriend: true })
        //TO DO - change device token to dynamic one
        this.props.addFriendRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            device_token: "12345678",
            device_type: deviceType,
            self_user_id: this.props.userInfo.id,
            other_user_id: this.state.barcodeValue.id,
            is_testdata: "1"
        })
    }

    //on searching with search text
    onSearchEmployee = (searchText) => {
        this.setState({ isLoading: true })
        //TO DO - change device token to dynamic one
        this.props.searchEmployeeRequest({
            secret_key: this.props.auth.data.userToken,
            access_key: this.props.encryptedToken,
            device_token: "12345678",
            device_type: deviceType,
            user_id: this.props.userInfo.id,
            offset: "0",
            serach_txt: searchText,
            is_testdata: "1",
            isFollow: 0
        });
    }

    //RENDER METHOD
    render() {
        return (
            <View style={{ flex: 1 }} >
                {!this.state.datafound ? <RNCamera
                    ref={ref => {
                        this.camera = ref;
                    }}
                    style={styles.preview}
                    type={RNCamera.Constants.Type.back}
                    // flashMode={RNCamera.Constants.FlashMode.on}
                    androidCameraPermissionOptions={{
                        title: 'Permission to use camera',
                        message: 'We need your permission to use your camera',
                        buttonPositive: 'Ok',
                        buttonNegative: 'Cancel',
                    }}
                    androidRecordAudioPermissionOptions={{
                        title: 'Permission to use audio recording',
                        message: 'We need your permission to use your audio',
                        buttonPositive: 'Ok',
                        buttonNegative: 'Cancel',
                    }}
                    onBarCodeRead={this.onBarCodeRead}
                >
                    <BarcodeMask
                        edgeColor={Colors.TEXT}
                        animatedLineColor={Colors.TEXT}
                    />
                </RNCamera> :
                    <View>
                        <View style={{ marginTop: Matrics.Scale(50), justifyContent: 'center', alignItems: 'center' }}>
                            <Image defaultSource={Images.ProfilePlaceHolder} source={this.state.barcodeValue.image ? { uri: this.state.barcodeValue.image } : Images.ProfilePlaceHolder} style={{ height: Matrics.Scale(130), width: Matrics.Scale(130), borderRadius: Matrics.Scale(65) }} />
                            <Text style={{ marginTop: Matrics.Scale(20), fontSize: Matrics.Scale(25) }}>{this.state.barcodeValue.name}</Text>
                            {this.state.isFollow == 0 ?
                                <TouchableOpacity onPress={() => this.addFriend()}>
                                    <View style={{ marginTop: Matrics.Scale(20), borderRadius: Matrics.Scale(3), justifyContent: 'center', alignItems: 'center', height: Matrics.Scale(40), width: Matrics.Scale(150), backgroundColor: Colors.TEXT }}>
                                        <Text style={{ color: Colors.WHITE }}>Add Friend</Text>
                                    </View>
                                </TouchableOpacity> :
                                <View style={{ marginTop: Matrics.Scale(20), borderRadius: Matrics.Scale(3), justifyContent: 'center', alignItems: 'center', height: Matrics.Scale(40), width: Matrics.Scale(300), backgroundColor: Colors.TEXT }}>
                                    <Text style={{ color: Colors.WHITE, fontSize: 18 }}>{this.state.barcodeValue.name} is already a friend.</Text>
                                </View>
                            }
                        </View>
                    </View>
                }
                <LoadWheel isVisible={this.state.isLoading} />
            </View>
        )
    }
}


//Props Connection
const mapStateToProps = (state) => {
    console.log(state, 'state on profile')
    return {
        auth: state.Auth,
        userInfo: state.Auth.data && state.Auth.data.data ? state.Auth.data.data.User : undefined,
        logout: state.Logout,
        encryptedToken: state.Encrypt.data ? state.Encrypt.data.encrypted_value : undefined,
        friend: state.Friend,
        friendRequest: state.FriendRequest
    };
}
//Redux Connection  
export default connect(mapStateToProps, { logOutRequest, searchEmployeeRequest, getRefreshTokenRequest, addFriendRequest })(ScanQRCode);


//STYELS DECLARATION
const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: 'column',
        backgroundColor: 'black',
    },
    preview: {
        flex: 1,
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    capture: {
        flex: 0,
        backgroundColor: '#fff',
        borderRadius: 5,
        padding: 15,
        paddingHorizontal: 20,
        alignSelf: 'center',
        margin: 20,
    },
});