//Libraries
import React from 'react'
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';


//Assets
import { Colors, Matrics } from '@Assets'


export const ListCell = ({ onPress, IconSource, Name,titleStyle, imageStyle, children ,borderStyle}) => {
    return (
        <View>
            <TouchableOpacity onPress={onPress}>
                <View style={styles.containerView}>
                    <Image source={IconSource} style={[styles.iconImage, imageStyle]} />
                    <View style={styles.subContainer}>
                        <Text style={[styles.nameStyle, titleStyle]}>{Name}</Text>
                        <View style={[styles.borderView, borderStyle]} />
                    </View>
                    {children}
                </View>
            </TouchableOpacity>
           
        </View>
    )
}

const styles = StyleSheet.create({
    containerView : { 
        alignItems: 'center', 
        flexDirection: 'row', 
        marginVertical: Matrics.Scale(20),
    },
    iconImage : { 
        marginLeft: Matrics.Scale(25), 
        height: Matrics.Scale(30), 
        width: Matrics.Scale(30) 
    },
    subContainer : { 
        flex: 1 
    },
    nameStyle: { 
        marginHorizontal: Matrics.Scale(35), 
        fontSize: Matrics.Scale(15) 
    },
    borderView :{ 
        borderColor: Colors.GREY, 
        marginTop: Matrics.Scale(17), 
        borderWidth: 1, 
        marginLeft: Matrics.Scale(35) 
    }
})