//Libraries
import React from 'react'
import { View, Text, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import Modal from "react-native-modal";
import Icon from 'react-native-vector-icons/Feather'
//Assets
import { Images, Matrics, Colors } from '@Assets'
const { height, width } = Dimensions.get('window')
import language from '../../Assets/Languages/Language'


export const ConfirmAlert = ({ onPress, isVisible }) => {
    return (
        <View>
            <Modal isVisible={isVisible}>
                <View style={styles.confirmView}>
                    <View style={styles.subcontentView}>
                        <View style={styles.headerView}>
                            <Icon name={'alert-circle'} size={20} color={Colors.TEXT} />
                            <Text style={styles.headerText}>{language.friend.DeleteAlertText}</Text>
                        </View>
                        <View style={styles.yesView} >
                            <TouchableOpacity>
                                <View style={styles.yesSubContentView} >
                                    <Text style={styles.yesText}>{language.yes}</Text>
                                </View>
                            </TouchableOpacity>

                            <TouchableOpacity>
                                <View style={styles.noView} >
                                    <Text style={styles.noText}>{language.no}</Text>
                                </View>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>
        </View>
    )
}




export const InviteFriendAlert = ({ onSMSPress, isVisible, onEmailPress, onCancelPress }) => {
    return (
        <View>
            <Modal animationOut={"slideOutDown"} isVisible={isVisible}>
                <View style={{ alignSelf: 'center', justifyContent: 'flex-end', flex: 1, }}>

                    <TouchableOpacity onPress={onSMSPress}>
                        <View style={{ borderBottomWidth: 1, borderBottomColor: Colors.LIGHTER_GREY, alignItems: 'center', justifyContent: 'center', height: Matrics.Scale(50), borderTopLeftRadius: Matrics.Scale(5), borderTopRightRadius: Matrics.Scale(5), width: width - Matrics.Scale(20), backgroundColor: Colors.WHITE }}>
                            <Text style={{ fontSize: Matrics.Scale(20), color: Colors.TEXT }}>SMS</Text>
                        </View>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={onEmailPress}>
                        <View style={{ borderBottomLeftRadius: Matrics.Scale(5), borderBottomRightRadius: Matrics.Scale(5), alignItems: 'center', justifyContent: 'center', height: Matrics.Scale(50), width: width - Matrics.Scale(20), backgroundColor: Colors.WHITE }}>
                            <Text style={{ fontSize: Matrics.Scale(20), color: Colors.TEXT }}>{language.email}</Text>
                        </View>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={onCancelPress}>
                        <View style={{ marginTop: Matrics.Scale(20), borderRadius: Matrics.Scale(5), alignItems: 'center', justifyContent: 'center', height: Matrics.Scale(50), width: width - Matrics.Scale(20), backgroundColor: Colors.WHITE }}>
                            <Text style={{ fontSize: Matrics.Scale(20), color: Colors.TEXT }}>{language.other.CancelText}</Text>
                        </View>
                    </TouchableOpacity>
                </View>
            </Modal>
        </View>
    )
}




const styles = StyleSheet.create({
    confirmView: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center'
    },
    subcontentView: {
        borderRadius: Matrics.Scale(3),
        backgroundColor: Colors.WHITE,
        width: width - 15,
        padding: Matrics.Scale(15),
        marginHorizontal: Matrics.Scale(5)
    },
    headerView: {
        flexDirection: 'row',
        marginVertical: Matrics.Scale(20)
    },
    headerText: {
        marginHorizontal: Matrics.Scale(2),
        marginTop: Matrics.Scale(2)
    },
    yesView: {
        flexDirection: 'row',
        justifyContent: 'space-around'
    },
    yesSubContentView: {
        backgroundColor: Colors.TEXT,
        borderWidth: 1,
        borderRadius: Matrics.Scale(3),
        borderColor: Colors.GREY,
        paddingHorizontal: Matrics.Scale(65),
        paddingVertical: Matrics.Scale(10)
    },
    yesText: {
        color: Colors.WHITE
    },
    noView: {
        backgroundColor: Colors.CONFIRMBUTTON,
        borderWidth: 1,
        borderRadius: Matrics.Scale(3),
        borderColor: Colors.GREY,
        paddingHorizontal: Matrics.Scale(65),
        paddingVertical: Matrics.Scale(10)
    },
    noText: {
        color: Colors.WHITE
    }
})

