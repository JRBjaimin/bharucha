//Libraries
import React from 'react'
import { View, Text, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import language from '../../Assets/Languages/Language'

//Assets
import { Images, Matrics, Colors } from '@Assets'
const { height, width } = Dimensions.get('window')


export const Button = ({ onPress }) => {
    return (
        <TouchableOpacity onPress={onPress}>
            <View style={styles.mainView}>
                <Text style={styles.buttonText}>{language.save}</Text>
            </View>
        </TouchableOpacity>
    )
}


export const MainButton = ({ onPress, Title, contentContainer }) => {
    return (
        <TouchableOpacity style={[styles.button1View, contentContainer]} onPress={onPress}>
            <Text style={styles.buttonText1}>{Title}</Text>
        </TouchableOpacity>
    )
}


const styles = StyleSheet.create({
    mainView: { borderWidth: 1, borderRadius: Matrics.Scale(2), borderColor: Colors.TEXT, padding: Matrics.Scale(10), width: width / 2, justifyContent: 'center', alignItems: 'center', alignSelf: 'center' },
    buttonText: { color: Colors.TEXT, fontSize: Matrics.Scale(15) },
    button1View: {
        borderRadius: Matrics.Scale(3),
        borderColor: 'transparent',
        marginHorizontal: Matrics.Scale(15),
        marginTop: Matrics.Scale(30),
        borderWidth: Matrics.Scale(1),
        width: width - Matrics.Scale(20),
        alignItems: "center",
        padding: Matrics.Scale(15),
        backgroundColor: Colors.TEXT
    },

    buttonText1: {
        color: Colors.WHITE,
        fontSize: Matrics.Scale(16)
    }
})

