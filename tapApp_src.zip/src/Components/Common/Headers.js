//Libraries
import React from 'react'
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';


//Assets
import { Images, Matrics, Colors } from '@Assets'
import language from '../../Assets/Languages/Language'


export const HeaderBackButton = ({ onBackPress }) => {
    return (
        <TouchableOpacity onPress={onBackPress}>
            <View style={styles.headerBackView}>
                <Text style={styles.headerBackText}>{language.back}</Text>
            </View>
        </TouchableOpacity>
    )
}

export const HeaderEditButton = ({ onEditPress }) => {
    return (
        <TouchableOpacity onPress={onEditPress}>
            <View style={styles.headerEditView}>
                <Text style={styles.headerEditText}>{language.edit}</Text>
            </View>
        </TouchableOpacity>
    )
}

// by j.....
export const HeaderEditLeftButton = ({ onEditLeftPress }) => {
    return (
        <TouchableOpacity onPress={onEditLeftPress}>
            <View style={styles.headerEditLeftView}>
                <Text style={styles.headerEditText}>{language.edit}</Text>
            </View>
        </TouchableOpacity>
    )
}



//======STYLES DECLARATION======//

const styles = StyleSheet.create({
    headerBackView: { borderWidth: 1, marginLeft: Matrics.Scale(13), borderRadius: Matrics.Scale(2), borderColor: Colors.GREY },
    headerBackText: { color: Colors.TEXT, paddingHorizontal: Matrics.Scale(10), paddingVertical: Matrics.Scale(5) },
    headerEditView: { borderWidth: 1, marginRight: Matrics.Scale(15), borderRadius: Matrics.Scale(2), borderColor: Colors.GREY },
    headerEditText: { color: Colors.TEXT, paddingHorizontal: Matrics.Scale(10), paddingVertical: Matrics.Scale(5) },
    // by j....
    headerEditLeftView: { borderWidth: 1, marginLeft: Matrics.Scale(15), borderRadius: Matrics.Scale(2), borderColor: Colors.GREY },

})
