 export default (UserInfo = {});
 export const MyQrCodePath="http://clientapp.narola.online/pg/EmployeeManagementApp/API/qr_image/";
 export const profilePath="http://clientapp.narola.online/pg/EmployeeManagementApp/API/profile_image/";
