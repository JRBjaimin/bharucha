//LIBRARIES
import React from "react";
import {
    Text,
    View,
    Image,
    TouchableOpacity,
    Dimensions,
    StyleSheet,
    Alert
} from "react-native";
import { connect } from 'react-redux'
import AsyncStorage from "@react-native-community/async-storage";
//ASSETS
import { Matrics, Colors, Images } from '@Assets'
import { MainButton, LoadWheel } from '../Components'
import { MASTER_ACCESS_KEY } from '../Config/Constants'
import { getRefreshTokenRequest } from '@Redux/Actions/AuthActions'
import language from '../Assets/Languages/Language'


const { height, width } = Dimensions.get('window')

//------CLASS DECLARATION--------->>>>
class InitialScreen extends React.Component {

    static navigationOptions = ({ navigation }) => ({
        swipeEnabled: false,
        header: null,
        gestureEnabled: false,
        lang :'japanese'
    })


    //------LIFE CYCLE METHODS--------->>>>
    async componentDidMount() {
      
        this.getRefreshToken()
    }


    
    async componentWillReceiveProps(nextProps) {
        // this.getRefreshToken()
        // this.props.getRefreshTokenRequest({ access_key: MASTER_ACCESS_KEY })
        console.log(nextProps, 'hi')
        console.log(nextProps, 'initialScreen')

        if (nextProps.auth.refreshTokenSuccess && nextProps.auth.data.status == "1") {
            await AsyncStorage.setItem('refreshtoken', JSON.stringify(nextProps.auth.data.tempToken))
        }

        // else if (nextProps.logout.logoutSuccess && nextProps.logout.data.status == "1" && nextProps.auth.data && nextProps.auth.data.data && nextProps.auth.data.data.User == undefined) {
        //     console.log('gyaaaaaaaaaaaaa')
        //     await AsyncStorage.getAllKeys().then(res => {
        //         console.log(res, 'keys----------')
        //     })
        //     // await AsyncStorage.clear('persist: Logout')
        //     // this.getRefreshToken()

        // }
        //if didn't get refresh token in first attempt
        else if (nextProps.auth.refreshTokenFail) {
            alert('Something went wrong here, please try opening the app again.')
        }
    }

    //------Controller Functions--------->>>>


    //Get refresh token when entered into app for first time
    getRefreshToken() {
        console.log('In2');

        this.props.getRefreshTokenRequest({ access_key: MASTER_ACCESS_KEY })
    }

    onLoginPress() {
        this.props.navigation.navigate('Login')
    }


    onRegisterPress() {
        this.props.navigation.navigate('Register')
    }


    async setLanguage(lan) {
        await this.setState({ lang: lan })
        console.log('setLanguage')
        // this.setState({ languageModal: false })
        AsyncStorage.setItem('lan', this.state.lang)
        //  language.setLanguage(this.state.lang);
         language.setLanguage(lan)
         this.forceUpdate()
    }

    languageSelectAlert() {

        Alert.alert(
            language.other.ChooseLanguageTitle,
            language.other.SelectLangaugeTitle,
            [
              {text: 'English', onPress: () =>this.setLanguage('english')},
              
              {text: '日本人', onPress: () => this.setLanguage('japanese')},
              {
                text: language.other.CancelText,
                onPress: () => console.log('Cancel Pressed'),
                style: 'cancel',
              },
            ],
            {cancelable: false},
          );
    }
    //------RENDER METHOD--------->>>>
    render() {
        const { TopHeaderText, LoginButtonText,RegisterText, } = language.auth

        return (
            <View style={styles.container}>
                <View style={styles.titleView}>
                    <Text style={styles.titleText}>{TopHeaderText}</Text>
                    <Image source={Images.Tape} style={styles.titleImage} />
                </View>
                <View style={styles.buttonContainer}>

                    <MainButton
                        onPress={() => this.onLoginPress()}
                        Title={LoginButtonText}
                    />


                    <TouchableOpacity onPress={() => this.onRegisterPress()}>
                        <View style={styles.button2View}>
                            <Text style={styles.buttonText}>{RegisterText}</Text>
                        </View>
                    </TouchableOpacity>


                    <TouchableOpacity onPress={() => this.languageSelectAlert()}>
                        <View style={styles.button2View}>
                            <Text style={styles.buttonText}>{language.other.ChangeLanguage}</Text>
                        </View>
                    </TouchableOpacity>

                </View>

            </View>
        )
    }
}

//Props Connection
const mapStateToProps = (state) => {
    return {
        auth: state.Auth,
        logout: state.Logout
    };
}
//Redux Connection  
export default connect(mapStateToProps, { getRefreshTokenRequest })(InitialScreen);


//------STYLES DECLARATION--------->>>>

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center'
    },
    titleView: {
        alignItems: 'center',
        marginTop: Matrics.Scale(180)
    },
    titleText: {
        fontSize: Matrics.Scale(20),
        color: Colors.GREY,
        marginBottom: Matrics.Scale(20)
    },
    titleImage: {
        resizeMode: 'stretch',
        marginBottom: Matrics.Scale(30),
        height: Matrics.Scale(46),
        width: Matrics.Scale(150)
    },
    button1View: {
        borderRadius: Matrics.Scale(3),
        borderColor: 'transparent',
        marginHorizontal: Matrics.Scale(15),
        marginTop: Matrics.Scale(15),
        borderWidth: Matrics.Scale(1),
        width: width - Matrics.Scale(20),
        alignItems: "center",
        padding: Matrics.Scale(15),
        backgroundColor: Colors.TEXT
    },
    button2View: {
        borderColor: 'transparent',
        borderRadius: Matrics.Scale(3),
        marginHorizontal: Matrics.Scale(15),
        marginTop: Matrics.Scale(15),
        borderWidth: Matrics.Scale(1),
        width: width - Matrics.Scale(20),
        alignItems: "center",
        padding: Matrics.Scale(15),
        backgroundColor: Colors.GREY
    },
    buttonContainer: {
        marginTop: Matrics.Scale(20)
    },
    buttonText: {
        color: Colors.WHITE,
        fontSize: Matrics.Scale(16)
    }
});
