//LIBRARIES
import React from 'react';
import { View, Text, Alert, TextInput, Platform, TouchableWithoutFeedback, Keyboard, StyleSheet } from 'react-native';
import CountryPicker from 'react-native-country-picker-modal'
import Icon from 'react-native-vector-icons/FontAwesome'
import { connect } from 'react-redux'
import AsyncStorage from '@react-native-community/async-storage';

//ASSETS
import { Matrics, Colors } from '@Assets'
import { HeaderBackButton, MainButton, LoadWheel } from '../Components'
import { phoneNumberRequest, checkPhoneNumberRequest } from '@Redux/Actions/AuthActions'
import { MASTER_ACCESS_KEY } from '../Config/Constants';
import language from '../Assets/Languages/Language'



//------CLASS DECLARATION--------->>>>
class Register extends React.Component {


    //NAVGATION OPTIONS FOR HEADER
    static navigationOptions = ({ navigation }) => ({
        headerTitle: language.auth.RegisterText,
        headerTitleStyle: { flex: 1, textAlign: 'center' },
        headerLeft: <HeaderBackButton
            onBackPress={() => navigation.goBack()}
        />,
        headerRight: <View />
    })

    state = {
        cca2: 'JP',
        callingCode: '81',
        countryName: 'Japan',
        phoneNumber: '',
        isLoading: false,
        refresh_token: ''
    }


    //------LIFE CYCLE METHODS--------->>>>

    async componentWillReceiveProps(nextProps) {
        console.log(nextProps, 'console next props')

        //for success case navigate to OTP verify screen
        if (nextProps.auth.verificationSuccess && nextProps.auth.data.success && this.state.isLoading) {
            await this.setState({ isLoading: false })
            this.props.navigation.navigate('Verification', { callingCode: this.state.callingCode, phoneNumber: this.state.phoneNumber })
        }

        else if (nextProps.auth.phoneNumberCheckSuccess && nextProps.auth.data.status == "1" && this.state.isLoading) {
            this.setState({ isLoading: false })
            this.showAlert()
        }
        //if phone number already exists in database
        else if (nextProps.auth.phoneNumberCheckSuccess && nextProps.auth.data.status == "0" && this.state.isLoading) {
            this.setState({ isLoading: false })
            alert(language.auth.PhoneNumberAlreadyRegistered)
        }

        //phone number and country code doesn't matches or entered more than once
        else if (nextProps.auth.verificationSuccess && nextProps.auth.data.error_code == "60033" && !nextProps.auth.data.success && this.state.isLoading) {
            await this.setState({ isLoading: false })
            alert(nextProps.auth.data.message)
        }
        //if landline number
        else if (nextProps.auth.verificationSuccess && nextProps.auth.data.error_code == "60082" && !nextProps.auth.data.success && this.state.isLoading) {
            await this.setState({ isLoading: false })
            alert(nextProps.auth.data.message)
        }

        //Too many attempts
        else if (nextProps.auth.verificationSuccess && nextProps.auth.data.error_code == "60003" && !nextProps.auth.data.success && this.state.isLoading) {
            await this.setState({ isLoading: false })
            alert(nextProps.auth.data.message)
        }

        else if (nextProps.auth.verificationFail && this.state.isLoading) {
            await this.setState({ isLoading: false })
            alert(language.auth.SomethingWentWrong1)
        }
    }



    //------FUNCTIONS DECLARATION--------->>>>


    onOkPressed() {
        this.setState({ isLoading: true })
        //TO DO - change locale in request to respective country.
        this.props.phoneNumberRequest({ phone_number: this.state.phoneNumber, country_code: this.state.callingCode, locale: "en", via: "sms" })
    }



    //confirmation alert for users
    showAlert() {
        if (this.state.phoneNumber == '') {
            alert(language.auth.PhoneNumberBlankText)
        }
        else {
            Alert.alert(
                ('+' + this.state.callingCode + this.state.phoneNumber),
                language.auth.VerifyAlertText,
                [
                    {
                        text: 'Cancel',
                        onPress: () => console.log('Cancel Pressed'),
                        style: 'cancel',
                    },
                    { text: 'OK', onPress: () => this.onOkPressed() },
                ],
                { cancelable: false },
            );
        }
    }

    async checkPhoneNumber() {
        let deviceType = await Platform.OS == 'ios' ? 1 : 0;

        await AsyncStorage.getItem('refreshtoken').then(async data => {
            await this.setState({ refresh_token: JSON.parse(data) })
        })
        if (this.state.phoneNumber == '') {
            alert(language.auth.PhoneNumberBlankText)
        }
        else {
            this.setState({ isLoading: true })
            this.props.checkPhoneNumberRequest({
                secret_key: this.state.refresh_token,
                access_key: MASTER_ACCESS_KEY,
                device_token: "12345678",
                device_type: deviceType,
                is_testdata: "1",
                // is_otp_verified: "1",
                via: "sms",
                country_code: this.state.callingCode,
                phone_number: this.state.phoneNumber
            })

        }
    }

    //------RENDER METHOD--------->>>>
    render() {

        const {
            TelephoneNumberText,
            RegisterDetailText,
            VerifyNumberText,
        } = language.auth

        return (
            <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
                <View style={styles.container}>
                    <View style={{ flex: 1 }}>
                        <CountryPicker
                            onChange={value => {
                                console.log(value, 'this value')
                                Keyboard.dismiss()
                                this.setState({ cca2: value.cca2, callingCode: value.callingCode, countryName: value.name })
                            }}
                            transparent={true}
                            closeable={true}
                            filterPlaceholder={'Search Country'}
                            filterable={true}
                            showCallingCode={true}
                            cca2={this.state.cca2}
                            translation="eng"
                        >
                            <View style={styles.countryPickerView}>
                                <Text style={styles.callingCode}>+{this.state.callingCode}</Text>
                                <Text style={styles.countryName}>({this.state.countryName})</Text>
                                <Icon name={'caret-down'} size={25} style={styles.Icon} />
                            </View>
                        </CountryPicker>

                        <View style={styles.numberInputView}>
                            <TextInput
                                value={this.state.phoneNumber}
                                placeholderTextColor={Colors.GREY}
                                onChangeText={text => this.setState({ phoneNumber: text })}
                                placeholder={TelephoneNumberText}
                                style={styles.inputContainer}
                                keyboardType={'phone-pad'}
                                onBlur={() => Keyboard.dismiss()}
                            />
                        </View>

                        <View style={styles.contentContainer}>
                            <Text style={styles.contentText}>{RegisterDetailText}</Text>
                        </View>
                    </View>
                    <View style={styles.buttonContainer}>
                        <MainButton
                            onPress={() => this.checkPhoneNumber()}
                            Title={VerifyNumberText}
                        />
                    </View>
                    <LoadWheel isVisible={this.state.isLoading} />

                </View>
            </TouchableWithoutFeedback>

        )
    }
}


//Props Connection
const mapStateToProps = (state) => {
    return {
        auth: state.Auth,
    };
}
//Redux Connection  
export default connect(mapStateToProps, { phoneNumberRequest, checkPhoneNumberRequest })(Register);




//STYLES
const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    callingCode: {
        fontSize: 17,
        marginHorizontal: Matrics.Scale(2)
    },
    countryName: {
        fontSize: 17,
        marginHorizontal: Matrics.Scale(2)
    },
    Icon: {
        marginLeft: Matrics.Scale(2)
    },
    countryPickerView: {

        marginHorizontal: Matrics.Scale(10),
        flexDirection: 'row',
        marginTop: Matrics.Scale(20)
    },
    numberInputView: {
        marginVertical: Matrics.Scale(10),
        marginHorizontal: Matrics.Scale(15),
        borderBottomWidth: 1,
        borderBottomColor: Colors.GREY,
    },
    inputContainer: {
        paddingVertical: Matrics.Scale(10),
        fontSize: Matrics.Scale(20)
    },
    buttonContainer: {
        marginBottom: Matrics.Scale(30),
        alignItems: 'center'
    },
    contentContainer: {
        marginVertical: Matrics.Scale(10),
        justifyContent: 'center',
        alignItems: 'center',
        marginHorizontal: Matrics.Scale(15),

    },
    contentText: {
        letterSpacing: Matrics.Scale(1)
    }
});
