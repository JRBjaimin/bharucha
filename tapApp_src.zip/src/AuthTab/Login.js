//LIBRARIES
import React from 'react';
import { View, Text, Image, Dimensions, TouchableOpacity, TextInput, Platform, StyleSheet } from 'react-native';
import { connect } from 'react-redux'
import AsyncStorage from '@react-native-community/async-storage';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import { StackActions, NavigationActions } from 'react-navigation';
import Prompt from 'react-native-prompt';

//ASSETS
import { Matrics, Colors, Images } from '@Assets'
import { MainButton, LoadWheel } from '../Components'
import { loginRequest, encryptTokenRequest, forgotPasswordRequest } from '@Redux/Actions/AuthActions'
import { MASTER_ACCESS_KEY } from '../Config/Constants';
import language from '../Assets/Languages/Language'


let deviceType = Platform.OS == 'ios' ? 1 : 0;

const { height, width } = Dimensions.get('window')
//MAIN CLASS DECLARATION
class Login extends React.Component {


    //NAVGATION OPTIONS FOR HEADER
    static navigationOptions = ({ navigation }) => ({
        swipeEnabled: false,
        header: null
    })

    //INITIAL STATE DECLARATION
    state = {
        email: "",
        password: "",
        showLoader: false,
        isLoading: false,
        refresh_token: '',
        forgotModal: false,
        forgotPassEmail: '',
        lang: 'japenese'
    };

    //------LIFE CYCLE METHODS--------->>>>
    async componentWillReceiveProps(nextProps) {
        if (nextProps.auth.loginSuccess && nextProps.auth.data.status == "1" && this.state.isLoading) {
            //Request for encrypt token to use with other api's
            await this.props.encryptTokenRequest({ guid: nextProps.auth.data.data.User.guid })

            if (nextProps.encrypt.data.encrypted_value) {
                this.setState({ isLoading: false })
                const resetAction = StackActions.reset({
                    index: 0,
                    actions: [NavigationActions.navigate({ routeName: 'Main' })],
                });
                await this.props.navigation.dispatch(resetAction);
            }
            else {
                this.setState({ isLoading: false })
                alert(language.auth.SomethingWentWrongText)
            }
        }
        else if (nextProps.auth.loginSuccess && nextProps.auth.data.status == "0" && this.state.isLoading) {
            this.setState({ isLoading: false })
            alert(nextProps.auth.data.message)
        }
        //if forgot password success
        else if (nextProps.auth.forgotPasswordSuccess && nextProps.auth.data.status == "1" && this.state.isLoading) {
            this.setState({ isLoading: false })
            alert(nextProps.auth.data.message)
        }
        else if (nextProps.auth.forgotPasswordSuccess && nextProps.auth.data.status == "0" && this.state.isLoading) {
            this.setState({ isLoading: false })
            alert(language.auth.ValidEmailIdText)
        }

        else if (nextProps.auth.forgotPasswordSuccess && nextProps.auth.data.status == "failed" && this.state.isLoading) {
            this.setState({ isLoading: false })
            alert(language.auth.ValidEmailIdText)
        }
        //if forgot password fail
        else if (nextProps.auth.forgotPasswordFail && this.state.isLoading) {
            this.setState({ isLoading: false })
            alert(language.auth.PasswordSendErrorText)
        }

        //if api doesn't get called
        else if (nextProps.auth.loginFail) {
            this.setState({ isLoading: false })
            alert(language.auth.SomethingWentWrong1)
        }
    }
    async componentDidMount() {
       
        // this.forgotPasswordModal()
    }

    //------FUNCTIONS DECLARATION--------->>>>

    async onLoginPress() {
        if (this.state.email.trim() == "") {
            alert(language.auth.EmailBlankAlert);
        }
        else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,5}$/i.test(this.state.email)) {
            alert(language.auth.ValidEmailIdAlert);
        } else if (this.state.password.trim() == "") {
            alert(language.auth.PasswordBlankAlert);
        }
        else {
            this.setState({ isLoading: true })

            //TO DO - change device token to the notifications token we are getting from firebase.
            //TO DO - ask for is_testdata if necessary in production?

            await AsyncStorage.getItem('refreshtoken').then(async data => {
                await this.setState({ refresh_token: JSON.parse(data) })
            })

            this.props.loginRequest({
                secret_key: this.state.refresh_token,
                access_key: MASTER_ACCESS_KEY,
                email_id: this.state.email.toLowerCase(),
                password: this.state.password,
                device_token: "123456",
                device_type: deviceType,
                is_testdata: "1"
            })
        }
    }


    async onForgotPasswordPress() {

        //TO DO - change device token to the notifications token we are getting from firebase.
        //TO DO - ask for is_testdata if necessary in production?
        await AsyncStorage.getItem('refreshtoken').then(async data => {
            await this.setState({ refresh_token: JSON.parse(data) })
        })

        this.setState({ isLoading: true })
        this.props.forgotPasswordRequest({
            secret_key: this.state.refresh_token,
            access_key: MASTER_ACCESS_KEY,
            email_id: this.state.forgotPassEmail,
            device_token: "123456",
            device_type: deviceType,
            is_testdata: "1"
        })

    }



    render() {
        const {
            TopHeaderText,
            LoginButtonText,
            AboutTape,
            EmailPlaceHolder,
            PasswordPlaceHolder,
            ForgotPasswordText,
            EnterEmailText
        } = language.auth

        return (
            <View style={{ flex: 1 }}>
                <KeyboardAwareScrollView enableOnAndroid={true}>

                    <View style={{ alignItems: 'center', marginTop: Matrics.Scale(170) }}>
                        <Text style={{ fontSize: 20, color: Colors.GREY }}>{TopHeaderText}</Text>
                    </View>

                    <View style={Styles.ImageContainer}>
                        <Image
                            resizeMode='stretch'
                            source={Images.Tape}
                            style={{
                                marginBottom: Matrics.Scale(40),
                                height: Matrics.Scale(46),
                                width: Matrics.Scale(150)
                            }}
                        />
                    </View>
 
                    {/* ================================================= */}

                    <View style={{ flexDirection: "row" }}>
                        <View style={[Styles.lableContainer, { alignItems: "center" }]}>
                            <View style={Styles.inputContainer}>

                                <View style={{ flex: 1 }}>
                                    <TextInput
                                        clearButtonMode={'while-editing'}
                                        style={Styles.inputBoxContainer}
                                        value={this.state.email}
                                        keyboardType={'email-address'}
                                        placeholderTextColor={"#ccc"}
                                        onChangeText={text => this.setState({ email: text })}
                                        placeholder={EmailPlaceHolder}
                                    />

                                </View>
                            </View>

                            <View style={Styles.inputContainer}>

                                <View style={{ flex: 1 }}>
                                    <TextInput
                                        clearButtonMode={'while-editing'}
                                        style={Styles.inputBoxContainer}
                                        secureTextEntry={true}
                                        value={this.state.password}
                                        placeholderTextColor={"#ccc"}
                                        onChangeText={text => this.setState({ password: text })}
                                        placeholder={PasswordPlaceHolder}
                                    />
                                </View>
                            </View>
                            <TouchableOpacity onPress={() => this.setState({ forgotModal: true })}>
                                <Text style={{ marginTop: Matrics.Scale(15), color: 'gray' }}>{ForgotPasswordText}</Text>
                            </TouchableOpacity>
                            <MainButton 
                                onPress={() => this.onLoginPress()}
                                Title={LoginButtonText}
                            />

                            <TouchableOpacity>
                                <View style={{
                                    alignItems: 'center', borderColor: 'gray',
                                    borderBottomWidth: 1,
                                    marginTop: Matrics.Scale(20)
                                }}>
                                    <Text style={{
                                        fontSize: Matrics.Scale(17), color: 'gray'
                                    }}>{AboutTape}
                                    </Text>
                                </View>
                            </TouchableOpacity>

                            <View style={{
                                alignItems: 'center',
                                marginTop: Matrics.Scale(20)
                            }}>
                                <Text style={{ fontSize: Matrics.Scale(12), color: 'gray' }}>
                                    @2019 TAPE Inc.All Rights Reserved
                                </Text>
                            </View>
                        </View>
                        <View>
                            <Prompt title={EnterEmailText}
                                placeholder={EmailPlaceHolder}
                                onSubmit={
                                    async (value) => { await this.setState({ forgotPassEmail: value.toLowerCase(), forgotModal: false }); this.onForgotPasswordPress() }
                                }
                                onCancel={() => this.setState(
                                    { forgotModal: false }
                                )}
                                visible={this.state.forgotModal}
                            // textInputProps={{ borderWidth: 5, borderColor: 'red' }}
                            />
                        </View>
                    </View>

                </KeyboardAwareScrollView>
                <LoadWheel isVisible={this.state.isLoading} />

            </View>
        )
    }
}


//Props Connection
const mapStateToProps = (state) => {
    return {
        auth: state.Auth,
        encrypt: state.Encrypt
    };
}
//Redux Connection
export default connect(mapStateToProps, { loginRequest, encryptTokenRequest, forgotPasswordRequest })(Login);



//STYLES
const Styles = StyleSheet.create({

    ImageContainer: {
        justifyContent: "center",
        alignContent: "center",
        alignSelf: "center",
        marginTop: Matrics.Scale(20)
    },

    lableContainer: {
        flex: 1,
        justifyContent: "center",
        alignContent: "center",
        alignSelf: "center"
    },

    inputContainer: {
        marginTop: Matrics.Scale(20),
        marginBottom: Matrics.Scale(5),
        height: Matrics.Scale(35),
        borderWidth: 1,
        flexDirection: "row",
        borderColor: "white",
        alignItems: "center",
        alignContent: "center",
        width: width - Matrics.Scale(20),
        borderRadius: Matrics.Scale(40)
    },

    inputBoxContainer: {
        height: Matrics.Scale(50),
        backgroundColor: '#F3F3F3',
        fontSize: Matrics.Scale(18),
        paddingLeft: Matrics.Scale(10)
    },

    button1View: {
        borderRadius: Matrics.Scale(3),
        borderColor: 'transparent',
        marginHorizontal: Matrics.Scale(15),
        marginTop: Matrics.Scale(30),
        borderWidth: Matrics.Scale(1),
        width: width - Matrics.Scale(20),
        alignItems: "center",
        padding: Matrics.Scale(15),
        backgroundColor: Colors.TEXT
    },
    buttonText: {
        color: Colors.WHITE,
        fontSize: Matrics.Scale(16)
    }
});





