import { createStackNavigator, createAppContainer } from 'react-navigation'
import Login from './Login';
import InitialScreen from './InitialScreen';
import Register from './Register';
import Verification from './Verification'
import Details from './Details'


const LoginNavigator = createStackNavigator({

  InitialScreen: {
    screen: InitialScreen,
    navigationOptions: () => ({
      header: null
    })
  },
  Login: { screen: Login },
  Register: { screen: Register },
  Details: { screen: Details },
  Verification: { screen: Verification },
})
 

export default LoginNavigator;
