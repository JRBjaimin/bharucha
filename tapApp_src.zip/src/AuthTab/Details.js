//LIBRARIES
import React from 'react';
import { View, Text, Image, TextInput, Dimensions, StyleSheet, Alert, Platform, TouchableOpacity, Linking } from 'react-native';
import { connect } from 'react-redux'
import Icon from 'react-native-vector-icons/Feather'
import ImagePicker from 'react-native-image-crop-picker';

import AsyncStorage from '@react-native-community/async-storage';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import { StackActions, NavigationActions } from 'react-navigation';

//ASSETS
import { Matrics, Colors, Images } from '@Assets'
import { HeaderBackButton, MainButton, LoadWheel } from '../Components'
import { registerUserRequest, encryptTokenRequest } from '@Redux/Actions/AuthActions'
import { MASTER_ACCESS_KEY } from '../Config/Constants';
import language from '../Assets/Languages/Language'


const { height, width } = Dimensions.get('window')

//------CLASS DECLARATION--------->>>>
class Details extends React.Component {


    //------NAVGATION OPTIONS FOR HEADER--------->>>>

    static navigationOptions = ({ navigation }) => ({
        headerTitle: language.auth.RegisterText,
        headerTitleStyle: { flex: 1, textAlign: 'center' },
        headerLeft: <HeaderBackButton
            onBackPress={() => navigation.goBack()}
        />,
        headerRight: <View />
    })

    //------STATE DECLARATION--------->>>>
    state = {
        username: '',
        email: '',
        password: '',
        confirmPassword: '',
        profileImage: {},
        checkBox: false,
        isLoading: false,
        refresh_token: ''
    }
    //------LIFE CYCLE METHODS--------->>>>

    async componentWillReceiveProps(nextProps) {
        console.log(nextProps, 'Details screen registration')
        if (nextProps.auth.registerSuccess && nextProps.auth.data.status == "1" && this.state.isLoading) {
            //Request for encrypt token to use with other api's
            await this.props.encryptTokenRequest({ guid: nextProps.auth.data.data.User.guid })

            if (nextProps.encrypt.data.encrypted_value) {
                this.setState({ isLoading: false })
                this.showSuccessAlert()
            }
            else {
                this.setState({ isLoading: false })
                alert(language.auth.SomethingWentWrong1)
            }

        }
        //phone number alredy exists case
        else if (nextProps.auth.registerSuccess && nextProps.auth.data.status == "0" && this.state.isLoading) {
            this.setState({ isLoading: false })
            alert(nextProps.auth.data.message)
        }

    }

    //------FUNCTIONS DECLARATIONS--------->>>>


    //On register press function 
    async onRegister(callingCode, phoneNumber, OTPCode) {

        //TO DO - change device token to the notifications token we are getting from firebase.
        //TO DO - ask for is_testdata if necessary in production?    
        //INFO - first name is the user name 
        //if otp verifiaction success then set otp_verification_flag to 1


        let deviceType = await Platform.OS == 'ios' ? 1 : 0;

        await AsyncStorage.getItem('refreshtoken').then(async data => {
            await this.setState({ refresh_token: JSON.parse(data) })
        })

        console.log(this.props.navigation.state.params, 'console on Details screen')

        if (this.state.username.trim() == "") {
            alert(language.auth.UserNameValidationText);
        }
        else if (this.state.email.trim() == "") {
            alert(language.auth.EmailBlankAlert);
        }
        else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,5}$/i.test(this.state.email)) {
            alert(ValidEmailIdText);
        } else if (this.state.password.trim() == "") {
            alert(language.auth.PasswordBlankAlert);
        }
        else if (this.state.password.trim() != this.state.confirmPassword.trim()) {
            alert(language.auth.PasswordMatchText);
        }
        else if (!this.state.checkBox) {
            alert(language.auth.AgreeToTermsText)
        }
        else {
            this.setState({ isLoading: true })
            //Request to register user with app
            this.props.registerUserRequest({
                secret_key: this.state.refresh_token,
                access_key: MASTER_ACCESS_KEY,
                device_token: "12345678",
                device_type: deviceType,
                first_name: this.state.username,
                email_id: this.state.email.toLowerCase(),
                password: this.state.password,
                is_testdata: "1",
                is_otp_verified: "1",
                // verification_code: "345ty",
                verification_code: OTPCode,
                role: "2",
                profile_image: this.state.profileImage.data,
                // country_code: "91",
                country_code: callingCode,
                // phone_number: "1478897287",
                phone_number: phoneNumber,
            })
        }
    }



    //choose profile photo from gallery
    choosePhoto() {
        ImagePicker.openPicker({
            compressImageQuality: 0.5,
            includeBase64: true
        }).then(async image => {
            console.log(image, 'consoleImage')
            let imgdata = { uri: image.path, type: image.mime, name: image.filename == null ? 'IMG1.jpg' : image.filename, data: image.data }
            //console.log(`data:${imgdata.mime};base64,${(new Buffer(imgdata.data)).toString('base64')}`)
            this.setState({ profileImage: imgdata })
        });
    }

    //take a photo from camera
    takePhoto() {
        ImagePicker.openCamera({
            // width: 300,
            // height: 300,
            cropping: true,
            compressImageQuality: 0.5,
            includeBase64: true

        }).then(async image => {
            let imgdata = { uri: image.path, type: image.mime, name: image.filename == null ? 'IMG.jpg' : image.filename }
            console.log(imgdata, 'imageData')
            this.setState({ profileImage: imgdata })
        });
    }


    //alert for camera or gallery
    choosePhotoAlert() {

        Alert.alert(
            language.auth.ProfilePhotoText,
            language.auth.ChoosePhotoText,
            [
                {
                    text: language.auth.CameraText,
                    onPress: () => this.takePhoto(),
                },
                { text: language.auth.GalleryText, onPress: () => this.choosePhoto() },
            ],
            // { cancelable: false },
        );
    }

    async onRegisterSuccess() {
        const resetAction = StackActions.reset({
            index: 0,
            actions: [NavigationActions.navigate({ routeName: 'Main' })],
        });
        await this.props.navigation.dispatch(resetAction);
    }

    showSuccessAlert() {
        Alert.alert(
            language.auth.SuccessText,
            language.auth.SuccessAlertText,
            [
                { text: 'OK', onPress: () => this.onRegisterSuccess() },
            ],
        );
    }


    render() {
        const {
            UsernamePlaceholder,
            PasswordPlaceHolder,
            EmailPlaceHolder,
            ConfirmPasswordPlaceholder,
            RegisterText1,
            AndText,
            TermsOfAgreement,
            PrivacyPolicyText,
            RegisterText,
            AlreadyAccountText
        } = language.auth
        const { callingCode, phoneNumber, OTPCode } = this.props.navigation.state.params
        return (
            <View style={styles.container}>
                <KeyboardAwareScrollView enableOnAndroid={true}>
                    <View style={{ flex: 1 }}>
                        <TouchableOpacity style={styles.ProfileView} onPress={() => this.choosePhotoAlert()}>
                            <View>
                                {Object.keys(this.state.profileImage).length == 0 ?
                                    <Icon size={50} name={'plus'} style={styles.plusIcon} /> :
                                    <Image source={{ uri: this.state.profileImage.uri }} style={styles.profileImage} />
                                }
                            </View>
                        </TouchableOpacity>
                        <View style={[styles.lableContainer, { alignItems: "center" }]}>
                            <View style={styles.inputContainer}>
                                <View style={{ flex: 1 }}>
                                    <TextInput
                                        clearButtonMode={'while-editing'}
                                        style={styles.inputBoxContainer}
                                        value={this.state.username}
                                        placeholderTextColor={"#ccc"}
                                        keyboardType={'email-address'}
                                        onChangeText={text => this.setState({ username: text })}
                                        placeholder={UsernamePlaceholder}
                                    />
                                </View>
                            </View>


                            <View style={styles.inputContainer}>
                                <View style={{ flex: 1 }}>
                                    <TextInput
                                        clearButtonMode={'while-editing'}
                                        style={styles.inputBoxContainer}
                                        value={this.state.email}
                                        keyboardType={'email-address'}
                                        placeholderTextColor={"#ccc"}
                                        onChangeText={text => this.setState({ email: text })}
                                        placeholder={EmailPlaceHolder}
                                    />
                                </View>
                            </View>


                            <View style={styles.inputContainer}>
                                <View style={{ flex: 1 }}>
                                    <TextInput
                                        clearButtonMode={'while-editing'}
                                        style={styles.inputBoxContainer}
                                        secureTextEntry={true}
                                        value={this.state.password}
                                        placeholderTextColor={"#ccc"}
                                        onChangeText={text => this.setState({ password: text })}
                                        placeholder={PasswordPlaceHolder}
                                    />
                                </View>
                            </View>
                            <View style={styles.inputContainer}>
                                <View style={{ flex: 1 }}>
                                    <TextInput
                                        clearButtonMode={'while-editing'}
                                        style={styles.inputBoxContainer}
                                        secureTextEntry={true}
                                        value={this.state.confirmPassword}
                                        placeholderTextColor={"#ccc"}
                                        onChangeText={text => this.setState({ confirmPassword: text })}
                                        placeholder={ConfirmPasswordPlaceholder}
                                    />

                                </View>
                            </View>
                            <View style={styles.registerView}>
                                <TouchableOpacity onPress={() => { this.setState({ checkBox: !this.state.checkBox }) }}>
                                    <Image resizeMode='stretch' source={this.state.checkBox ? Images.checkBoxCheck : Images.checkBoxUncheck}
                                        style={styles.checkBoxImage} />
                                </TouchableOpacity>
                                <View style={{ flexDirection: 'column' }}>
                                    <Text style={styles.registerText}>{RegisterText1} <Text style={{ color: Colors.TEXT }} onPress={() => Linking.openURL('https://policies.google.com/terms?hl=en-US')}>{TermsOfAgreement}</Text> </Text>
                                    <Text style={styles.registerText}> {AndText}  <Text style={{ color: Colors.TEXT }} onPress={() => Linking.openURL('https://policies.google.com/terms?hl=en-US')}>{PrivacyPolicyText}</Text></Text>
                                </View>
                            </View>
                        </View>
                        <View style={styles.buttonContainer}>
                            <MainButton
                                onPress={() => this.onRegister(callingCode, phoneNumber, OTPCode)}
                                Title={RegisterText}
                            />
                        </View>
                        <View style={styles.loginView}>
                            <Text style={styles.loginText}>{AlreadyAccountText}</Text>
                        </View>
                    </View>
                    <LoadWheel isVisible={this.state.isLoading} />
                </KeyboardAwareScrollView>

            </View>
        )
    }
}

//Props Connection
const mapStateToProps = (state) => {
    console.log(state, 'state')
    return {
        auth: state.Auth,
        encrypt: state.Encrypt
    };
}

//Redux Connection  
export default connect(mapStateToProps, { registerUserRequest, encryptTokenRequest })(Details);


//styles declaration
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    ProfileView: {
        marginTop: Matrics.Scale(20),
        marginBottom: Matrics.Scale(10),
        width: Matrics.Scale(120),
        height: Matrics.Scale(120),
        backgroundColor: Colors.LIGHTER_GREY,
        borderWidth: Matrics.Scale(1),
        borderRadius: Matrics.Scale(60),
        borderColor: 'transparent',
        alignSelf: 'center',
        justifyContent: 'center'
    },
    buttonContainer: {
        marginBottom: Matrics.Scale(30),
        alignItems: 'center'
    },
    lableContainer: {
        // flex: 1,
        // justifyContent: "center",
        // alignContent: "center",
        // alignSelf: "center"
    },
    inputContainer: {
        marginTop: Matrics.Scale(30),
        marginBottom: Matrics.Scale(5),
        height: Matrics.Scale(35),
        borderWidth: 1,
        flexDirection: "row",
        borderColor: "white",
        alignItems: "center",
        alignContent: "center",
        width: width - Matrics.Scale(20),
        borderRadius: Matrics.Scale(40)
    },
    inputBoxContainer: {
        height: Matrics.Scale(50),
        backgroundColor: Colors.LIGHTER_GREY,
        fontSize: Matrics.Scale(18),
        paddingLeft: Matrics.Scale(10)
    },
    registerView: {
        // borderWidth: 1,
        flexDirection: 'row',

        // marginHorizontal: Matrics.Scale(10),
        marginTop: Matrics.Scale(30)
    },
    loginView: {
        marginTop: Matrics.Scale(10),
        marginBottom: Matrics.Scale(10),
        alignItems: 'center'
    },
    registerText: {
        color: Colors.GREY,
        paddingHorizontal: Matrics.Scale(3)
        // marginRight: Matrics.Scale(10),
    },
    loginText: {
        color: Colors.GREY,
    },
    plusIcon: {
        alignSelf: 'center',
        color: Colors.GREY
    },
    profileImage: {
        width: Matrics.Scale(120),
        height: Matrics.Scale(120),
        borderRadius: Matrics.Scale(60),
    },
    checkBoxImage: {
        marginLeft: Matrics.Scale(15),
        marginRight: Matrics.Scale(5),
        height: Matrics.Scale(20),
        width: Matrics.Scale(20)
    }
});
