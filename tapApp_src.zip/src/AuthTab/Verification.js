//LIBRARIES
import React from 'react';
import { View, Text, TouchableWithoutFeedback, Keyboard, StyleSheet, Platform, TouchableOpacity } from 'react-native';
import OTPInputView from '@twotalltotems/react-native-otp-input'
import { connect } from 'react-redux'

//ASSETS
import { Matrics, Colors, Images } from '@Assets'
import { HeaderBackButton, MainButton, LoadWheel } from '../Components'
import { checkOTPRequest, phoneNumberRequest } from '@Redux/Actions/AuthActions'
import language from '../Assets/Languages/Language'




//------CLASS DECLARATION--------->>>>
class Verification extends React.Component {


    //NAVGATION OPTIONS FOR HEADER
    static navigationOptions = ({ navigation }) => ({
        headerTitle: language.auth.Verify,
        headerTitleStyle: { flex: 1, textAlign: 'center' },
        headerLeft: <HeaderBackButton
            onBackPress={() => navigation.goBack()}
        />,
        headerRight: <View />
    })


    //------INITIAL STATE DECLARATION--------->>>>
    state = {
        code: '',
        isLoading: false
    }


    //------LIFE CYCLE METHODS--------->>>>

    async componentWillReceiveProps(nextProps) {
        console.log(nextProps, 'consoling next props')

        //for success case navigate to OTP verify screen
        if (nextProps.auth.OTPSuccess && nextProps.auth.data.success && this.state.isLoading) {
            this.setState({ isLoading: false })
            alert(nextProps.auth.data.message)
            this.props.navigation.navigate('Details', { callingCode: nextProps.navigation.state.params.callingCode, phoneNumber: nextProps.navigation.state.params.phoneNumber, OTPCode: this.state.code })
        }

        //OTP not correct case
        else if (nextProps.auth.OTPSuccess && nextProps.auth.data.error_code == "60022" && !nextProps.auth.data.success && this.state.isLoading) {
            this.setState({ isLoading: false })
            alert(nextProps.auth.data.message)
        }
        //Account suspended case
        else if (nextProps.auth.OTPSuccess && nextProps.auth.data.error_code == "60003" && !nextProps.auth.data.success && this.state.isLoading) {
            this.setState({ isLoading: false })
            alert(nextProps.auth.data.message)
        }

        else if (nextProps.auth.OTPFail && this.state.isLoading) {
            this.setState({ isLoading: false })
            alert(language.auth.SomethingWentWrong1)
        }
    }


    //------FUNCTIONS DECLARATION--------->>>>

    //Resend verification code
    onResendPress(callingCode, phoneNumber) {
        
        this.props.phoneNumberRequest({
            phone_number: phoneNumber,
            country_code: callingCode,
            locale: "en",
            via: "sms"
        })
    }

    // check for otp
    onNextPress(callingCode, phoneNumber) {
        
        console.log(this.state.code, 'verification code')
        if (this.state.code == '') {
            alert(language.auth.ValidText)
        }
        else {
            this.setState({ isLoading: true })
            this.props.checkOTPRequest({ phone_number: phoneNumber, country_code: callingCode, verification_code: this.state.code })
        }
    }



    //------RENDER METHOD--------->>>>
    render() {

        const {
            VerificationCodeDetailsText,
            ResendCodeText,
            NextText,
        } = language.auth

        const { phoneNumber, callingCode } = this.props.navigation.state.params
        return (
            <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
                <View style={styles.container}>
                    <View style={{ flex: 1 }}>

                        <View style={styles.pinVerifyView}>
                            <OTPInputView
                                style={{ width: '80%', height: Matrics.Scale(200), alignItems: 'center', justifyContent: 'center' }}
                                pinCount={4}
                                code=""
                                autoFocusOnLoad={true}
                                codeInputFieldStyle={styles.borderStyleBase}
                                codeInputHighlightStyle={styles.borderStyleHighLighted}
                                codeInputFieldStyle={styles.underlineStyleBase}
                                codeInputHighlightStyle={styles.underlineStyleHighLighted}
                                onCodeFilled={(code => {
                                    this.setState({ code: code })
                                    console.log(`Code is ${code}, you are good to go!`)
                                })}
                            />
                        </View>
                        <View style={styles.numberView}>
                            <Text style={styles.numberText}>+{callingCode + phoneNumber}</Text>
                        </View>
                        <View style={styles.contentContainer}>
                            <Text style={styles.contentText}>{VerificationCodeDetailsText}</Text>
                        </View>
                        <TouchableOpacity onPress={() => this.onResendPress(callingCode, phoneNumber)}>
                            <View style={styles.resendView}>
                                <Text style={styles.resendText}>{ResendCodeText}</Text>
                            </View>
                        </TouchableOpacity>

                    </View>
                    <View style={styles.buttonContainer}>
                        <MainButton
                            onPress={() => this.onNextPress(callingCode, phoneNumber)}
                            Title={NextText}
                        />
                    </View>
                    <LoadWheel isVisible={this.state.isLoading} />
                </View>
            </TouchableWithoutFeedback>
        )
    }
}


//Props Connection
const mapStateToProps = (state) => {
    return {
        auth: state.Auth,
    };
}
//Redux Connection  
export default connect(mapStateToProps, { checkOTPRequest, phoneNumberRequest })(Verification);


const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    pinVerifyView: {
        marginTop: Matrics.Scale(50),
        height: Matrics.Scale(50),
        alignItems: 'center',
        justifyContent: 'center'
    },
    borderStyleBase: {

        width: Matrics.Scale(30),
        height: Matrics.Scale(45)
    },

    borderStyleHighLighted: {

        borderColor: Colors.TEXT,
    },

    underlineStyleBase: {

        fontSize: Platform.OS == 'ios' ? Matrics.Scale(40) : Matrics.Scale(20),
        width: Matrics.Scale(45),
        height: Matrics.Scale(45),
        borderWidth: 0,
        borderBottomWidth: 1,
    },

    underlineStyleHighLighted: {

        borderColor: Colors.TEXT,
    },
    numberView: {
        marginVertical: Matrics.Scale(15),
        alignItems: 'center',
        justifyContent: 'center'
    },
    numberText: {
        fontSize: Matrics.Scale(17),
        color: Colors.TEXT
    },
    contentText: {
        color: Colors.GREY
    },
    contentContainer: {
        marginVertical: Matrics.Scale(10),
        marginHorizontal: Matrics.Scale(15)
    },
    resendView: {
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: Matrics.Scale(10),

    },
    resendText: {
        color: Colors.GREY,
        fontSize: Matrics.Scale(20),
        borderBottomWidth: 1
    },
    buttonContainer: {
        marginBottom: Matrics.Scale(30),
        alignItems: 'center'
    },
})