// React
import React from 'react'
// import { View, StatusBar, Text, TouchableOpacity } from 'react-native'
 import AppNavigator from './AppNavigationConfiguration'

//Main AppNavigation Class
export default class AppNavigation extends React.Component {
    
    render() {
        return (
                <AppNavigator />
        )
    }
}


